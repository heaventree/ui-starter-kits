<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class DemoController extends AbstractController
{
    public function notFound(): Response
    {
        return $this->render('/home/error404.html.twig');
    }
    
    #[Route('/', name:'home')]
    public function index(): Response
    {
        return $this->render('/demo/index.html.twig');
    }

    #[Route('/demo/index2', name:'index2')]
    public function index2(): Response
    {
        return $this->render('/demo/index2.html.twig');
    }
    #[Route('/demo/index3', name:'index3')]
    public function index3(): Response
    {
        return $this->render('/demo/index3.html.twig');
    }

    #[Route('/demo/index4', name:'index4')]
    public function index4(): Response
    {
        return $this->render('/demo/index4.html.twig');
    }

    #[Route('/demo/index5', name:'index5')]
    public function index5(): Response
    {
        return $this->render('/demo/index5.html.twig');
    }

    #[Route('/demo/index6', name:'index6')]
    public function index6(): Response
    {
        return $this->render('/demo/index6.html.twig');
    }

    #[Route('/demo/index7', name:'index7')]
    public function index7(): Response
    {
        return $this->render('/demo/index7.html.twig');
    }
            
    #[Route('/demo/index8', name:'index8')]
    public function index8(): Response
    {
        return $this->render('/demo/index8.html.twig',[
            'bgColor'=>'bg-[#FDFBF9]',
            ]);
    }
            
    #[Route('/demo/index9', name:'index9')]
    public function index9(): Response
    {
        return $this->render('/demo/index9.html.twig',[
            'bgColor'=>'bg-ColorAlmond',
            ]);
    }
                
    #[Route('/demo/index10', name:'index10')]
    public function index10(): Response
    {
        return $this->render('/demo/index10.html.twig',[
            'bgColor'=>'bg-ColorEggSour',
        ]);
    }

    #[Route('/demo/index11', name:'index11')]
    public function index11(): Response
    {
        return $this->render('/demo/index11.html.twig');
    }

    #[Route('/demo/index12', name:'index12')]
    public function index12(): Response
    {
        return $this->render('/demo/index12.html.twig',[
                'bgColor'=>'bg-[#FEF7E6]',
            ]);
    }

    #[Route('/demo/index13', name:'index13')]
    public function index13(): Response
    {
        return $this->render('/demo/index13.html.twig',[
                'bgColor'=>'bg-[#F6F9F0]',
            ]);
    }

    #[Route('/demo/index14', name:'index14')]
    public function index14(): Response
    {
        return $this->render('/demo/index14.html.twig');
    }

    #[Route('/demo/index15', name:'index15')]
    public function index15(): Response
    {
        return $this->render('/demo/index15.html.twig');
    }
}
