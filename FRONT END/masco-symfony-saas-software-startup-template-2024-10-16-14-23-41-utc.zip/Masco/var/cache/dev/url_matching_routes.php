<?php

/**
 * This file has been auto-generated
 * by the Symfony Routing Component.
 */

return [
    false, // $matchHost
    [ // $staticRoutes
        '/' => [[['_route' => 'home', '_controller' => 'App\\Controller\\DemoController::index'], null, null, null, false, false, null]],
        '/demo/index2' => [[['_route' => 'index2', '_controller' => 'App\\Controller\\DemoController::index2'], null, null, null, false, false, null]],
        '/demo/index3' => [[['_route' => 'index3', '_controller' => 'App\\Controller\\DemoController::index3'], null, null, null, false, false, null]],
        '/demo/index4' => [[['_route' => 'index4', '_controller' => 'App\\Controller\\DemoController::index4'], null, null, null, false, false, null]],
        '/demo/index5' => [[['_route' => 'index5', '_controller' => 'App\\Controller\\DemoController::index5'], null, null, null, false, false, null]],
        '/demo/index6' => [[['_route' => 'index6', '_controller' => 'App\\Controller\\DemoController::index6'], null, null, null, false, false, null]],
        '/demo/index7' => [[['_route' => 'index7', '_controller' => 'App\\Controller\\DemoController::index7'], null, null, null, false, false, null]],
        '/demo/index8' => [[['_route' => 'index8', '_controller' => 'App\\Controller\\DemoController::index8'], null, null, null, false, false, null]],
        '/demo/index9' => [[['_route' => 'index9', '_controller' => 'App\\Controller\\DemoController::index9'], null, null, null, false, false, null]],
        '/demo/index10' => [[['_route' => 'index10', '_controller' => 'App\\Controller\\DemoController::index10'], null, null, null, false, false, null]],
        '/demo/index11' => [[['_route' => 'index11', '_controller' => 'App\\Controller\\DemoController::index11'], null, null, null, false, false, null]],
        '/demo/index12' => [[['_route' => 'index12', '_controller' => 'App\\Controller\\DemoController::index12'], null, null, null, false, false, null]],
        '/demo/index13' => [[['_route' => 'index13', '_controller' => 'App\\Controller\\DemoController::index13'], null, null, null, false, false, null]],
        '/demo/index14' => [[['_route' => 'index14', '_controller' => 'App\\Controller\\DemoController::index14'], null, null, null, false, false, null]],
        '/demo/index15' => [[['_route' => 'index15', '_controller' => 'App\\Controller\\DemoController::index15'], null, null, null, false, false, null]],
        '/home/about' => [[['_route' => 'about', '_controller' => 'App\\Controller\\HomeController::about'], null, null, null, false, false, null]],
        '/home/blog' => [[['_route' => 'blog', '_controller' => 'App\\Controller\\HomeController::blog'], null, null, null, false, false, null]],
        '/home/blog-details' => [[['_route' => 'blogDetails', '_controller' => 'App\\Controller\\HomeController::blogDetails'], null, null, null, false, false, null]],
        '/home/career-details' => [[['_route' => 'careerDetails', '_controller' => 'App\\Controller\\HomeController::careerDetails'], null, null, null, false, false, null]],
        '/home/careers' => [[['_route' => 'careers', '_controller' => 'App\\Controller\\HomeController::careers'], null, null, null, false, false, null]],
        '/home/comingsoon' => [[['_route' => 'comingsoon', '_controller' => 'App\\Controller\\HomeController::comingsoon'], null, null, null, false, false, null]],
        '/home/contact' => [[['_route' => 'contact', '_controller' => 'App\\Controller\\HomeController::contact'], null, null, null, false, false, null]],
        '/home/contact2' => [[['_route' => 'contact2', '_controller' => 'App\\Controller\\HomeController::contact2'], null, null, null, false, false, null]],
        '/home/contact3' => [[['_route' => 'contact3', '_controller' => 'App\\Controller\\HomeController::contact3'], null, null, null, false, false, null]],
        '/home/error404' => [[['_route' => 'error404', '_controller' => 'App\\Controller\\HomeController::error404'], null, null, null, false, false, null]],
        '/home/faq' => [[['_route' => 'faq', '_controller' => 'App\\Controller\\HomeController::faq'], null, null, null, false, false, null]],
        '/home/faq2' => [[['_route' => 'faq2', '_controller' => 'App\\Controller\\HomeController::faq2'], null, null, null, false, false, null]],
        '/home/faq3' => [[['_route' => 'faq3', '_controller' => 'App\\Controller\\HomeController::faq3'], null, null, null, false, false, null]],
        '/home/faq4' => [[['_route' => 'faq4', '_controller' => 'App\\Controller\\HomeController::faq4'], null, null, null, false, false, null]],
        '/home/login' => [[['_route' => 'login', '_controller' => 'App\\Controller\\HomeController::login'], null, null, null, false, false, null]],
        '/home/portfolio' => [[['_route' => 'portfolio', '_controller' => 'App\\Controller\\HomeController::portfolio'], null, null, null, false, false, null]],
        '/home/portfolio2' => [[['_route' => 'portfolio2', '_controller' => 'App\\Controller\\HomeController::portfolio2'], null, null, null, false, false, null]],
        '/home/portfolio3' => [[['_route' => 'portfolio3', '_controller' => 'App\\Controller\\HomeController::portfolio3'], null, null, null, false, false, null]],
        '/home/portfolio4' => [[['_route' => 'portfolio4', '_controller' => 'App\\Controller\\HomeController::portfolio4'], null, null, null, false, false, null]],
        '/home/portfolio-details' => [[['_route' => 'portfolioDetails', '_controller' => 'App\\Controller\\HomeController::portfolioDetails'], null, null, null, false, false, null]],
        '/home/pricing' => [[['_route' => 'pricing', '_controller' => 'App\\Controller\\HomeController::pricing'], null, null, null, false, false, null]],
        '/home/pricing2' => [[['_route' => 'pricing2', '_controller' => 'App\\Controller\\HomeController::pricing2'], null, null, null, false, false, null]],
        '/home/reset-password' => [[['_route' => 'resetPassword', '_controller' => 'App\\Controller\\HomeController::resetPassword'], null, null, null, false, false, null]],
        '/home/service-details' => [[['_route' => 'serviceDetails', '_controller' => 'App\\Controller\\HomeController::serviceDetails'], null, null, null, false, false, null]],
        '/home/services' => [[['_route' => 'services', '_controller' => 'App\\Controller\\HomeController::services'], null, null, null, false, false, null]],
        '/home/signup' => [[['_route' => 'signup', '_controller' => 'App\\Controller\\HomeController::signup'], null, null, null, false, false, null]],
        '/home/teams' => [[['_route' => 'teams', '_controller' => 'App\\Controller\\HomeController::teams'], null, null, null, false, false, null]],
        '/onepage/index' => [[['_route' => 'indexOnePage1', '_controller' => 'App\\Controller\\OnePageController::index'], null, null, null, false, false, null]],
        '/onepage/index2' => [[['_route' => 'indexOnePage2', '_controller' => 'App\\Controller\\OnePageController::index2'], null, null, null, false, false, null]],
        '/onepage/index3' => [[['_route' => 'indexOnePage3', '_controller' => 'App\\Controller\\OnePageController::index3'], null, null, null, false, false, null]],
        '/onepage/index4' => [[['_route' => 'indexOnePage4', '_controller' => 'App\\Controller\\OnePageController::index4'], null, null, null, false, false, null]],
        '/onepage/index5' => [[['_route' => 'indexOnePage5', '_controller' => 'App\\Controller\\OnePageController::index5'], null, null, null, false, false, null]],
        '/onepage/index6' => [[['_route' => 'indexOnePage6', '_controller' => 'App\\Controller\\OnePageController::index6'], null, null, null, false, false, null]],
        '/onepage/index7' => [[['_route' => 'indexOnePage7', '_controller' => 'App\\Controller\\OnePageController::index7'], null, null, null, false, false, null]],
        '/onepage/index8' => [[['_route' => 'indexOnePage8', '_controller' => 'App\\Controller\\OnePageController::index8'], null, null, null, false, false, null]],
        '/onepage/index9' => [[['_route' => 'indexOnePage9', '_controller' => 'App\\Controller\\OnePageController::index9'], null, null, null, false, false, null]],
        '/onepage/index10' => [[['_route' => 'indexOnePage10', '_controller' => 'App\\Controller\\OnePageController::index10'], null, null, null, false, false, null]],
        '/onepage/index11' => [[['_route' => 'indexOnePage11', '_controller' => 'App\\Controller\\OnePageController::index11'], null, null, null, false, false, null]],
        '/onepage/index12' => [[['_route' => 'indexOnePage12', '_controller' => 'App\\Controller\\OnePageController::index12'], null, null, null, false, false, null]],
        '/onepage/index13' => [[['_route' => 'indexOnePage13', '_controller' => 'App\\Controller\\OnePageController::index13'], null, null, null, false, false, null]],
        '/onepage/index14' => [[['_route' => 'indexOnePage14', '_controller' => 'App\\Controller\\OnePageController::index14'], null, null, null, false, false, null]],
        '/onepage/index15' => [[['_route' => 'indexOnePage15', '_controller' => 'App\\Controller\\OnePageController::index15'], null, null, null, false, false, null]],
    ],
    [ // $regexpList
        0 => '{^(?'
                .'|/_error/(\\d+)(?:\\.([^/]++))?(*:35)'
                .'|/(.*)(*:47)'
            .')/?$}sDu',
    ],
    [ // $dynamicRoutes
        35 => [[['_route' => '_preview_error', '_controller' => 'error_controller::preview', '_format' => 'html'], ['code', '_format'], null, null, false, true, null]],
        47 => [
            [['_route' => 'not_found', '_controller' => 'App\\Controller\\DemoController::notFound'], ['any'], null, null, false, true, null],
            [null, null, null, null, false, false, 0],
        ],
    ],
    null, // $checkCondition
];
