export { default } from "./Content";
