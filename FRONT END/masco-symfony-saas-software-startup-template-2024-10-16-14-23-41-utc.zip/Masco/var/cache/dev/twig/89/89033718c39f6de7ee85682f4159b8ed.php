<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/portfolioDetails.html.twig */
class __TwigTemplate_44e85b3bbb694d5a2dd84fce742c34ad extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/portfolioDetails.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/portfolioDetails.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/portfolioDetails.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Portfolio Section Start -->
<section class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Portfolio Details Area -->
            <div class=\"mx-auto max-w-[1076px]\">
                <!-- Portfolio Main Image -->
                <img src=\"";
        // line 41
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-main-img.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-main-img\" width=\"1076\" height=\"600\" class=\"h-auto w-full rounded-[10px]\" />
                <!-- Portfolio Main Image -->

                <!-- Portfolio Info List -->
                <ul class=\"mb-[60px] mt-[30px] flex flex-wrap justify-between gap-8\">
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Client:</span>
                        <span class=\"text-ColorBlack/80\">Adam Smith</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Category:</span>
                        <span class=\"text-ColorBlack/80\">UI/UX Design</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Duration:</span>
                        <span class=\"text-ColorBlack/80\">1 Week</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4]\">Website Link:</span>
                        <span class=\"text-ColorBlack/80\">example@gmail.com</span>
                    </li>
                </ul>
                <!-- Portfolio Info List -->

                <!-- Portfolio Rich Text -->
                <div class=\"rich-text\">
                    <h4>Project overview</h4>
                    <p>
                        Mobile UX design is the design of user experiences for
                        hand-held and wearable devices. Designers create solutions
                        (typically applications) to meet mobile users' unique
                        requirements and restrictions. Designers focus on
                        accessibility, discoverability and efficiency to optimize
                        on-the-go interactive experiences.
                    </p>
                    <p>
                        Interface (UI) determines how the app will look like, while
                        UX determines what problem it will solve in the users' life.
                        UI is revolves around visually directing the user about the
                        app interface, while UX includes researching, testing,
                        developing the app.
                    </p>

                    <h5>What we did for this project</h5>
                    <p>
                        A user can engage with a product or service by using a user
                        interface (UI), which is essentially a collection of
                        screens, pages, visual elements (such as buttons and icons).
                        The phrase “User Experience” refers to how a person reacts
                        to each component.
                    </p>
                    <ol class=\"list-inside list-decimal\">
                        <li>Strategic Discovery</li>
                        <li>Web application redesign and optimization</li>
                        <li>Mobile application redesign and optimization</li>
                        <li>Landing page redesign and optimization</li>
                        <li>Component-based UI-Kit</li>
                        <li>Product design sprints to explore new functionality</li>
                    </ol>

                    <img src=\"";
        // line 101
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-inner-img.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-inner-img\" width=\"1076\" height=\"650\" class=\"my-6 h-auto w-full rounded-[10px]\" />

                    <h5>Project results</h5>
                    <p>
                        The UI/UX design of software and applications helps improve
                        customer experience and satisfaction. This ultimately helps
                        increase the number of people using your product. If users
                        encounter roadblocks when trying to complete actions on your
                        product, they are very likely to drop off.
                    </p>
                    <p>
                        Creating a brand with clear and targeted messaging was
                        crucial in increasing conversions. Together with the Webflow
                        team, we have compiled a new product page structure using
                        the App model and packed that in an excellent cover 🙂
                    </p>
                </div>
                <!-- Portfolio Rich Text -->
            </div>
            <!-- Portfolio Details Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Portfolio Section End -->

<!-- Horizontal Text Slider -->
<div class=\"overflow-hidden bg-ColorBlack py-5 text-3xl font-bold uppercase leading-[1.4] tracking-widest text-white\">
    <!-- Horizontal Slider Block-->
    <div class=\"horizontal-slide-from-right-to-left flex gap-x-[30px]\">
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"";
        // line 133
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/fire-icon.png"), "html", null, true);
        yield "\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"";
        // line 135
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/fire-icon.png"), "html", null, true);
        yield "\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"";
        // line 137
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/fire-icon.png"), "html", null, true);
        yield "\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"";
        // line 139
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/fire-icon.png"), "html", null, true);
        yield "\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
    </div>
    <!-- Horizontal Slider Block-->
</div>
<!-- Horizontal Text Slider -->

<!-- Related Portfolio Section Start -->
<section class=\"related-portfolio-section\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"mx-auto max-w-[1076px]\">
                <!-- Section Wrapper -->
                <div class=\"jos flex flex-wrap items-center justify-between gap-8\">
                    <!-- Section Block -->
                    <div class=\"mb-5\">
                        <h2>Related Project:</h2>
                    </div>
                    <!-- Section Block -->
                </div>
                <!-- Section Wrapper -->
                <p class=\"jos max-w-[856px]\">
                    There are many variations of passages of Lorem Ipsum
                    available, but the majority have suf alteration in some form,
                    by injected humour, or randomised words which don't look even
                    slightly believable.
                </p>

                <!-- Portfolio List -->
                <div class=\"grid gap-8 sm:grid-cols-2\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"relative z-10 after:absolute after:inset-0 after:-z-10 after:translate-x-0 after:translate-y-0 after:rounded-[11px] after:bg-ColorBlack after:transition-all after:duration-300 after:ease-in-out hover:after:translate-x-[10px] hover:after:translate-y-[10px]\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 175
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-1\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 180
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"relative z-10 after:absolute after:inset-0 after:-z-10 after:translate-x-0 after:translate-y-0 after:rounded-[11px] after:bg-ColorBlack after:transition-all after:duration-300 after:ease-in-out hover:after:translate-x-[10px] hover:after:translate-y-[10px]\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 198
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-2\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 203
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Related Portfolio Section Start -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 230
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 231
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/portfolioDetails.html.twig", 231)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/portfolioDetails.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  373 => 231,  366 => 230,  334 => 203,  326 => 198,  305 => 180,  297 => 175,  258 => 139,  253 => 137,  248 => 135,  243 => 133,  208 => 101,  145 => 41,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

<!-- Portfolio Section Start -->
<section class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Portfolio Details Area -->
            <div class=\"mx-auto max-w-[1076px]\">
                <!-- Portfolio Main Image -->
                <img src=\"{{ asset('assets/img/th-1/portfolio-main-img.jpg') }}\" alt=\"portfolio-main-img\" width=\"1076\" height=\"600\" class=\"h-auto w-full rounded-[10px]\" />
                <!-- Portfolio Main Image -->

                <!-- Portfolio Info List -->
                <ul class=\"mb-[60px] mt-[30px] flex flex-wrap justify-between gap-8\">
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Client:</span>
                        <span class=\"text-ColorBlack/80\">Adam Smith</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Category:</span>
                        <span class=\"text-ColorBlack/80\">UI/UX Design</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4] text-ColorBlack\">Duration:</span>
                        <span class=\"text-ColorBlack/80\">1 Week</span>
                    </li>
                    <li>
                        <span class=\"mb-[5px] block text-xl font-bold leading-[1.4]\">Website Link:</span>
                        <span class=\"text-ColorBlack/80\">example@gmail.com</span>
                    </li>
                </ul>
                <!-- Portfolio Info List -->

                <!-- Portfolio Rich Text -->
                <div class=\"rich-text\">
                    <h4>Project overview</h4>
                    <p>
                        Mobile UX design is the design of user experiences for
                        hand-held and wearable devices. Designers create solutions
                        (typically applications) to meet mobile users' unique
                        requirements and restrictions. Designers focus on
                        accessibility, discoverability and efficiency to optimize
                        on-the-go interactive experiences.
                    </p>
                    <p>
                        Interface (UI) determines how the app will look like, while
                        UX determines what problem it will solve in the users' life.
                        UI is revolves around visually directing the user about the
                        app interface, while UX includes researching, testing,
                        developing the app.
                    </p>

                    <h5>What we did for this project</h5>
                    <p>
                        A user can engage with a product or service by using a user
                        interface (UI), which is essentially a collection of
                        screens, pages, visual elements (such as buttons and icons).
                        The phrase “User Experience” refers to how a person reacts
                        to each component.
                    </p>
                    <ol class=\"list-inside list-decimal\">
                        <li>Strategic Discovery</li>
                        <li>Web application redesign and optimization</li>
                        <li>Mobile application redesign and optimization</li>
                        <li>Landing page redesign and optimization</li>
                        <li>Component-based UI-Kit</li>
                        <li>Product design sprints to explore new functionality</li>
                    </ol>

                    <img src=\"{{ asset('assets/img/th-1/portfolio-inner-img.jpg') }}\" alt=\"portfolio-inner-img\" width=\"1076\" height=\"650\" class=\"my-6 h-auto w-full rounded-[10px]\" />

                    <h5>Project results</h5>
                    <p>
                        The UI/UX design of software and applications helps improve
                        customer experience and satisfaction. This ultimately helps
                        increase the number of people using your product. If users
                        encounter roadblocks when trying to complete actions on your
                        product, they are very likely to drop off.
                    </p>
                    <p>
                        Creating a brand with clear and targeted messaging was
                        crucial in increasing conversions. Together with the Webflow
                        team, we have compiled a new product page structure using
                        the App model and packed that in an excellent cover 🙂
                    </p>
                </div>
                <!-- Portfolio Rich Text -->
            </div>
            <!-- Portfolio Details Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Portfolio Section End -->

<!-- Horizontal Text Slider -->
<div class=\"overflow-hidden bg-ColorBlack py-5 text-3xl font-bold uppercase leading-[1.4] tracking-widest text-white\">
    <!-- Horizontal Slider Block-->
    <div class=\"horizontal-slide-from-right-to-left flex gap-x-[30px]\">
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"{{ asset('assets/img/icons/fire-icon.png') }}\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"{{ asset('assets/img/icons/fire-icon.png') }}\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"{{ asset('assets/img/icons/fire-icon.png') }}\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
        <span class=\"inline-block min-w-[855px]\">We complete client's projects efficiently</span>
        <img src=\"{{ asset('assets/img/icons/fire-icon.png') }}\" alt=\"fire-icon\" width=\"40\" height=\"40\" />
    </div>
    <!-- Horizontal Slider Block-->
</div>
<!-- Horizontal Text Slider -->

<!-- Related Portfolio Section Start -->
<section class=\"related-portfolio-section\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"mx-auto max-w-[1076px]\">
                <!-- Section Wrapper -->
                <div class=\"jos flex flex-wrap items-center justify-between gap-8\">
                    <!-- Section Block -->
                    <div class=\"mb-5\">
                        <h2>Related Project:</h2>
                    </div>
                    <!-- Section Block -->
                </div>
                <!-- Section Wrapper -->
                <p class=\"jos max-w-[856px]\">
                    There are many variations of passages of Lorem Ipsum
                    available, but the majority have suf alteration in some form,
                    by injected humour, or randomised words which don't look even
                    slightly believable.
                </p>

                <!-- Portfolio List -->
                <div class=\"grid gap-8 sm:grid-cols-2\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"relative z-10 after:absolute after:inset-0 after:-z-10 after:translate-x-0 after:translate-y-0 after:rounded-[11px] after:bg-ColorBlack after:transition-all after:duration-300 after:ease-in-out hover:after:translate-x-[10px] hover:after:translate-y-[10px]\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-1.jpg') }}\" alt=\"portfolio-modern-img-1\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"relative z-10 after:absolute after:inset-0 after:-z-10 after:translate-x-0 after:translate-y-0 after:rounded-[11px] after:bg-ColorBlack after:transition-all after:duration-300 after:ease-in-out hover:after:translate-x-[10px] hover:after:translate-y-[10px]\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-2.jpg') }}\" alt=\"portfolio-modern-img-2\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Related Portfolio Section Start -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/portfolioDetails.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\portfolioDetails.html.twig");
    }
}
