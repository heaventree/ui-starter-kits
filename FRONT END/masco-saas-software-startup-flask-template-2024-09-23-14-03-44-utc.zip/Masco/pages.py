from flask import render_template
from app import app


@app.route('/about')
def about():
    return render_template('/pages/about.html')
    
@app.route('/blog')
def blog():
    return render_template('/pages/blog.html')
    
@app.route('/blog-details')
def blogDetails():
    return render_template('/pages/blogDetails.html')
    
@app.route('/career-details')
def careerDetails():
    return render_template('/pages/careerDetails.html')
    
@app.route('/careers')
def careers():
    return render_template('/pages/careers.html')
    
@app.route('/comingsoon')
def comingsoon():
    return render_template('/pages/comingsoon.html')
    
@app.route('/contact')
def contact():
    return render_template('/pages/contact.html')
    
@app.route('/contact2')
def contact2():
    return render_template('/pages/contact2.html')
    
@app.route('/contact3')
def contact3():
    return render_template('/pages/contact3.html')
    
@app.route('/error404')
def error404():
    return render_template('/pages/error404.html')
    
@app.route('/faq')
def faq():
    return render_template('/pages/faq.html')
    
@app.route('/faq2')
def faq2():
    return render_template('/pages/faq2.html')
    
@app.route('/faq3')
def faq3():
    return render_template('/pages/faq3.html')
    
@app.route('/faq4')
def faq4():
    return render_template('/pages/faq4.html')
    
@app.route('/login')
def login():
    return render_template('/pages/login.html')
    
@app.route('/portfolio')
def portfolio():
    return render_template('/pages/portfolio.html')
    
@app.route('/portfolio2')
def portfolio2():
    return render_template('/pages/portfolio2.html')
    
@app.route('/portfolio3')
def portfolio3():
    return render_template('/pages/portfolio3.html')
    
@app.route('/portfolio4')
def portfolio4():
    return render_template('/pages/portfolio4.html')
    
@app.route('/portfolio-details')
def portfolioDetails():
    return render_template('/pages/portfolioDetails.html')
    
@app.route('/pricing')
def pricing():
    return render_template('/pages/pricing.html')
    
@app.route('/pricing2')
def pricing2():
    return render_template('/pages/pricing2.html')
    
@app.route('/reset-password')
def resetPassword():
    return render_template('/pages/resetPassword.html')
    
@app.route('/service-details')
def serviceDetails():
    return render_template('/pages/serviceDetails.html')
    
@app.route('/services')
def services():
    return render_template('/pages/services.html')
    
@app.route('/signup')
def signup():
    return render_template('/pages/signup.html')
    
@app.route('/teams')
def teams():
    return render_template('/pages/teams.html')
    