<template>
    <section id="features-6" class="py-100 features-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Efficiently create, manage and publish your content</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- FEATURES-6 WRAPPER -->
            <div class="fbox-wrapper text-center">
                <div class="row row-cols-1 row-cols-md-2 row-cols-lg-4">
                    <!-- FEATURE BOX #1 -->
                    <div class="col">
                        <div class="fbox-6 fb-1 wow fadeInUp">
                            <!-- Icon -->
                            <div class="fbox-ico ico-55">
                                <div class="shape-ico color--theme">
                                    <!-- Vector Icon -->
                                    <span class="flaticon-rocket-launch"></span>
                                    <!-- Shape -->
                                    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                    </svg>
                                </div>
                            </div>
                            <!-- End Icon -->
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-20 w-700">Quick Access</h6>
                                <p>Luctus augue egestas undo ultrice and quisque lacus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #1 -->
                    <!-- FEATURE BOX #2 -->
                    <div class="col">
                        <div class="fbox-6 fb-2 wow fadeInUp">
                            <!-- Icon -->
                            <div class="fbox-ico ico-55">
                                <div class="shape-ico color--theme">
                                    <!-- Vector Icon -->
                                    <span class="flaticon-data-copy"></span>
                                    <!-- Shape -->
                                    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                    </svg>
                                </div>
                            </div>
                            <!-- End Icon -->
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-20 w-700">File Manager</h6>
                                <p>Luctus augue egestas undo ultrice and quisque lacus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #2 -->
                    <!-- FEATURE BOX #3 -->
                    <div class="col">
                        <div class="fbox-6 fb-3 wow fadeInUp">
                            <!-- Icon -->
                            <div class="fbox-ico ico-55">
                                <div class="shape-ico color--theme">
                                    <!-- Vector Icon -->
                                    <span class="flaticon-networking"></span>
                                    <!-- Shape -->
                                    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                    </svg>
                                </div>
                            </div>
                            <!-- End Icon -->
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-20 w-700">Files Sharing</h6>
                                <p>Luctus augue egestas undo ultrice and quisque lacus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #3 -->
                    <!-- FEATURE BOX #4 -->
                    <div class="col">
                        <div class="fbox-6 fb-4 wow fadeInUp">
                            <!-- Icon -->
                            <div class="fbox-ico ico-55">
                                <div class="shape-ico color--theme">
                                    <!-- Vector Icon -->
                                    <span class="flaticon-download"></span>
                                    <!-- Shape -->
                                    <svg viewBox="0 0 200 200" xmlns="http://www.w3.org/2000/svg">
                                        <path d="M69.8,-23C76.3,-2.7,57.6,25.4,32.9,42.8C8.1,60.3,-22.7,67,-39.1,54.8C-55.5,42.7,-57.5,11.7,-48.6,-11.9C-39.7,-35.5,-19.8,-51.7,5.9,-53.6C31.7,-55.6,63.3,-43.2,69.8,-23Z" transform="translate(100 100)" />
                                    </svg>
                                </div>
                            </div>
                            <!-- End Icon -->
                            <!-- Text -->
                            <div class="fbox-txt">
                                <h6 class="s-20 w-700">Storage & Backup</h6>
                                <p>Luctus augue egestas undo ultrice and quisque lacus</p>
                            </div>
                        </div>
                    </div>
                    <!-- END FEATURE BOX #4 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END FEATURES-6 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
    <hr class="divider" />
</template>
