<template>
    <section id="hero-20" class="bg--fixed hero-section mt-5">
        <div class="container mt-5">
            <div class="row d-flex align-items-center">
                <!-- HERO TEXT -->
                <div class="col-md-7 col-lg-6">
                    <div class="hero-20-txt wow fadeInRight">
                        <!-- Title -->
                        <h2 class="s-48 w-700">Increase your traffic and boost your brand</h2>
                        <!-- Text -->
                        <p class="p-md">Mauris donec turpis suscipit sapien ociis sagittis sapien tempor a volute ligula and aliquet tortor</p>
                        <!-- Button -->
                        <a href="#banner-3" class="btn r-04 btn--theme hover--theme">Get started for free</a>
                        <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> No credit card needed, free 14-day trial</p>
                    </div>
                </div>
                <!-- END HERO TEXT -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
