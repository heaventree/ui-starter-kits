import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app-screenshots',
  templateUrl: './app-screenshots.component.html',
  styleUrls: ['./app-screenshots.component.scss']
})
export class AppScreenshotsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
