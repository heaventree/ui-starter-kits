<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/breadcrumb.html.twig */
class __TwigTemplate_72682a60caf222c5f0a9ffbe9ce82be9 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/breadcrumb.html.twig"));

        // line 1
        yield "  ";
        // line 2
        yield "  <section class=\"section-breadcrumb\">
    ";
        // line 4
        yield "    <div class=\"breadcrumb-wrapper\">
        ";
        // line 6
        yield "        <div class=\"container-default\">
            <div class=\"breadcrumb-block\">
                <h1 class=\"breadcrumb-title\"> ";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["title"]) || array_key_exists("title", $context) ? $context["title"] : (function () { throw new RuntimeError('Variable "title" does not exist.', 8, $this->source); })()), "html", null, true);
        yield "</h1>
                <ul class=\"breadcrumb-nav\">
                    <li><a href=\"";
        // line 10
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\">Home</a></li>
                    ";
        // line 11
        if (array_key_exists("links", $context)) {
            // line 12
            yield "                        ";
            yield (isset($context["links"]) || array_key_exists("links", $context) ? $context["links"] : (function () { throw new RuntimeError('Variable "links" does not exist.', 12, $this->source); })());
            yield "
                    ";
        }
        // line 14
        yield "                    <li>";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["subTitle"]) || array_key_exists("subTitle", $context) ? $context["subTitle"] : (function () { throw new RuntimeError('Variable "subTitle" does not exist.', 14, $this->source); })()), "html", null, true);
        yield "</li>
                </ul>
            </div>
        </div>
        ";
        // line 19
        yield "
        ";
        // line 21
        yield "        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/breadcrumb-shape-1.svg"), "html", null, true);
        yield "\" alt=\"hero-shape-1\" width=\"291\" height=\"380\" />
        </div>

        ";
        // line 26
        yield "        <div class=\"absolute bottom-0 right-0 -z-[1]\">
            <img src=\"";
        // line 27
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/breadcrumb-shape-2.svg"), "html", null, true);
        yield "\" alt=\"hero-shape-2\" width=\"291\" height=\"380\" />
        </div>
    </div>
    ";
        // line 31
        yield "</section>
    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "partials/breadcrumb.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  99 => 31,  93 => 27,  90 => 26,  84 => 22,  81 => 21,  78 => 19,  70 => 14,  64 => 12,  62 => 11,  58 => 10,  53 => 8,  49 => 6,  46 => 4,  43 => 2,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("  {# Breadcrumb Section Start #}
  <section class=\"section-breadcrumb\">
    {# Breadcrumb Section Spacer #}
    <div class=\"breadcrumb-wrapper\">
        {# Section Container #}
        <div class=\"container-default\">
            <div class=\"breadcrumb-block\">
                <h1 class=\"breadcrumb-title\"> {{ title }}</h1>
                <ul class=\"breadcrumb-nav\">
                    <li><a href=\"{{ path('home') }}\">Home</a></li>
                    {% if links is defined %}
                        {{ links | raw }}
                    {% endif %}
                    <li>{{ subTitle }}</li>
                </ul>
            </div>
        </div>
        {# Section Container #}

        {# Breadcrumb Shape - 1 #}
        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/breadcrumb-shape-1.svg') }}\" alt=\"hero-shape-1\" width=\"291\" height=\"380\" />
        </div>

        {# Breadcrumb Shape - 2 #}
        <div class=\"absolute bottom-0 right-0 -z-[1]\">
            <img src=\"{{ asset('assets/img/elements/breadcrumb-shape-2.svg') }}\" alt=\"hero-shape-2\" width=\"291\" height=\"380\" />
        </div>
    </div>
    {# Breadcrumb Section Spacer #}
</section>
    {# Breadcrumb Section End #}", "partials/breadcrumb.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\partials\\breadcrumb.html.twig");
    }
}
