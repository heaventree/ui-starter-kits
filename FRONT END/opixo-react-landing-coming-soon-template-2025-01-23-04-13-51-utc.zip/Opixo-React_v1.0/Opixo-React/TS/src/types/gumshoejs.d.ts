declare module 'gumshoejs'
