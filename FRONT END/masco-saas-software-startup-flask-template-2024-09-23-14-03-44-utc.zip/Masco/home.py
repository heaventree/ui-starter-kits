from flask import render_template
from app import app


@app.route('/')
@app.route('/index')
def index():
    return render_template('/home/index.html')

@app.route('/index2')
def index2():
    return render_template('/home/index2.html')

@app.route('/index3')
def index3():
    return render_template('/home/index3.html')

@app.route('/index4')
def index4():
    return render_template('/home/index4.html')

@app.route('/index5')
def index5():
    return render_template('/home/index5.html')

@app.route('/index6')
def index6():
    return render_template('/home/index6.html')

@app.route('/index7')
def index7():
    return render_template('/home/index7.html')

@app.route('/index8')
def index8():
    return render_template('/home/index8.html')

@app.route('/index9')
def index9():
    return render_template('/home/index9.html')

@app.route('/index10')
def index10():
    return render_template('/home/index10.html')

@app.route('/index11')
def index11():
    return render_template('/home/index11.html')

@app.route('/index12')
def index12():
    return render_template('/home/index12.html')

@app.route('/index13')
def index13():
    return render_template('/home/index13.html')

@app.route('/index14')
def index14():
    return render_template('/home/index14.html')

@app.route('/index15')
def index15():
    return render_template('/home/index15.html')
