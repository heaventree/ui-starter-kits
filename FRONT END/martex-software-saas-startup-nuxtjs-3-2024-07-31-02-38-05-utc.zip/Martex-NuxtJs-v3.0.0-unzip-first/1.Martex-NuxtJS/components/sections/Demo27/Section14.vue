<template>
    <section class="pt-100 ct-08 content-section division">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Discover insights across all your data with Martex</h2>
                        <!-- Text -->
                        <p class="s-21">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- IMAGE BLOCK -->
            <div class="row">
                <div class="col">
                    <div class="img-block wow fadeInUp">
                        <img class="img-fluid" src="/assets/images/img-19.png" alt="video-preview" />
                    </div>
                </div>
            </div>
            <!-- ACTION BUTTON -->
            <div class="row">
                <div class="col">
                    <div class="img-block-btn text-center wow fadeInUp">
                        <!-- Button -->
                        <a href="#integrations-2" class="btn r-04 btn--tra-black hover--theme">Monitor your activity</a>
                        <!-- Advantages List -->
                        <ul class="advantages ico-15 clearfix">
                            <li><p>Free 14 days trial</p></li>
                            <li class="advantages-links-divider">
                                <p><span class="flaticon-minus"></span></p>
                            </li>
                            <li><p>Exclusive Support</p></li>
                            <li class="advantages-links-divider">
                                <p><span class="flaticon-minus"></span></p>
                            </li>
                            <li><p>No Fees</p></li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
        <!-- End container -->
    </section>
</template>
