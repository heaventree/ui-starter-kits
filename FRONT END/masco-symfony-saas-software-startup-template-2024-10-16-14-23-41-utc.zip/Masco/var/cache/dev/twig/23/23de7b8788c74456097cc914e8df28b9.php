<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/contact3.html.twig */
class __TwigTemplate_fecec293f99f391e8deddf03a18ed8d6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/contact3.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/contact3.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 7
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 8
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 10
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 11
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 24
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 25
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/contact3.html.twig", 25)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 28
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 29
        yield "
    <!-- Contact Info Section Start -->
    <div class=\"section-contact-info\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <div class=\"grid items-center gap-10 md:grid-cols-2 lg:gap-20 xl:grid-cols-[0.9fr_1fr] xl:gap-32 xxl:grid-cols-[0.7fr_1fr] xxl:gap-[210px]\">
                    <!-- Contact Info List -->
                    <div class=\"flex flex-col gap-[60px]\">
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0\">
                            <img src=\"";
        // line 41
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-chat.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-chat\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Chat with us
                                </div>
                                <p>
                                    We're waiting to help you every Monday-Friday from 9 am
                                    to 5 pm EST easily.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0.3\">
                            <img src=\"";
        // line 55
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-phone.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-phone\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Give us a call
                                </div>
                                <p>
                                    Give us a ring at
                                    <a href=\"tel:+01234567890\" class=\"font-semibold hover:text-ColorBlue\">(+012-345-567-890)</a>. Every monday-friday from 9 am to 5 pm.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0.6\">
                            <img src=\"";
        // line 69
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-message.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-message\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Email Us
                                </div>
                                <p>
                                    Drop us an email at
                                    <a href=\"mailto:example@yourmail.com\" class=\"font-semibold underline underline-offset-4 hover:text-ColorBlue\">example@gmail.com</a>
                                    and you'll receive a reply within 24 hours.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                    </div>
                    <!-- Contact Info List -->
                    <!-- Contact Form Block -->
                    <div class=\"jos xm:p-10 rounded-[10px] border-2 border-ColorBlack/50 bg-ColorOffWhite p-[30px]\">
                        <div class=\"mb-5 text-xl font-semibold tracking-tight text-ColorBlack lg:text-2xl\">
                            Send us a message
                        </div>

                        <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                            <!-- From Group List -->
                            <div class=\"flex flex-col gap-6\">
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your full name\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"tel\" name=\"phone\" id=\"phone\" placeholder=\"Enter your phone number*\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your email\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <textarea name=\"message\" id=\"message\" placeholder=\"Write us your question here...\" class=\"min-h-[130px] w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required></textarea>
                                </div>
                                <!-- Form Group Item-->
                            </div>
                            <!-- From Group List -->
                            <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8 block w-full\">
                                Send Message
                            </button>
                        </form>
                    </div>
                    <!-- Contact Form Block -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </div>
    <!-- Contact Info Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 133
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 134
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/contact3.html.twig", 134)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/contact3.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  257 => 134,  250 => 133,  181 => 69,  164 => 55,  147 => 41,  133 => 29,  126 => 28,  117 => 25,  110 => 24,  90 => 11,  86 => 10,  82 => 8,  75 => 7,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 

{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

    <!-- Contact Info Section Start -->
    <div class=\"section-contact-info\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <div class=\"grid items-center gap-10 md:grid-cols-2 lg:gap-20 xl:grid-cols-[0.9fr_1fr] xl:gap-32 xxl:grid-cols-[0.7fr_1fr] xxl:gap-[210px]\">
                    <!-- Contact Info List -->
                    <div class=\"flex flex-col gap-[60px]\">
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-chat.svg') }}\" alt=\"icon-duotone-chat\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Chat with us
                                </div>
                                <p>
                                    We're waiting to help you every Monday-Friday from 9 am
                                    to 5 pm EST easily.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0.3\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-phone.svg') }}\" alt=\"icon-duotone-phone\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Give us a call
                                </div>
                                <p>
                                    Give us a ring at
                                    <a href=\"tel:+01234567890\" class=\"font-semibold hover:text-ColorBlue\">(+012-345-567-890)</a>. Every monday-friday from 9 am to 5 pm.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                        <!-- Contact Info Item -->
                        <div class=\"jos flex gap-[30px]\" data-jos_delay=\"0.6\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-message.svg') }}\" alt=\"icon-duotone-message\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5] text-ColorBlack\">
                                    Email Us
                                </div>
                                <p>
                                    Drop us an email at
                                    <a href=\"mailto:example@yourmail.com\" class=\"font-semibold underline underline-offset-4 hover:text-ColorBlue\">example@gmail.com</a>
                                    and you'll receive a reply within 24 hours.
                                </p>
                            </div>
                        </div>
                        <!-- Contact Info Item -->
                    </div>
                    <!-- Contact Info List -->
                    <!-- Contact Form Block -->
                    <div class=\"jos xm:p-10 rounded-[10px] border-2 border-ColorBlack/50 bg-ColorOffWhite p-[30px]\">
                        <div class=\"mb-5 text-xl font-semibold tracking-tight text-ColorBlack lg:text-2xl\">
                            Send us a message
                        </div>

                        <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                            <!-- From Group List -->
                            <div class=\"flex flex-col gap-6\">
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your full name\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"tel\" name=\"phone\" id=\"phone\" placeholder=\"Enter your phone number*\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your email\" class=\"w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                </div>
                                <!-- Form Group Item-->
                                <!-- Form Group Item-->
                                <div>
                                    <textarea name=\"message\" id=\"message\" placeholder=\"Write us your question here...\" class=\"min-h-[130px] w-full border-b-2 border-dashed border-ColorBlack/20 bg-ColorOffWhite px-2 py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required></textarea>
                                </div>
                                <!-- Form Group Item-->
                            </div>
                            <!-- From Group List -->
                            <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8 block w-full\">
                                Send Message
                            </button>
                        </form>
                    </div>
                    <!-- Contact Form Block -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </div>
    <!-- Contact Info Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/contact3.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\contact3.html.twig");
    }
}
