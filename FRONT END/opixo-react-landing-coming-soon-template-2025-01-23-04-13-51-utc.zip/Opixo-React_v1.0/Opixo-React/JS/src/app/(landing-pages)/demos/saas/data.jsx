import avatar3 from '@/assets/images/avatars/img-3.png';
import avatar5 from '@/assets/images/avatars/img-5.png';
import avatar7 from '@/assets/images/avatars/img-7.png';
import avatar8 from '@/assets/images/avatars/img-8.png';
export const navLinks = [{
  label: 'Home',
  link: '#home'
}, {
  label: 'Service',
  link: '#service'
}, {
  label: 'Features',
  link: '#features'
}, {
  label: 'Price',
  link: '#price'
}, {
  label: 'Team',
  link: '#team'
}, {
  label: 'Faq',
  link: '#faq'
}];
export const services = [{
  title: 'Clean Design',
  description: 'Quisque quis velit quiars ligula aliquet lacinia quis a diam quisque pretium nulla nec ultricies magna.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-blue-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z" />
        <polyline points="3.27 6.96 12 12.01 20.73 6.96" />
        <line x1={12} y1="22.08" x2={12} y2={12} />
      </svg>,
  variant: 'bg-blue-50'
}, {
  title: 'Awesome Code',
  description: 'Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit sed quia consequuntur nesciunt.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-red-600" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round">
        <circle cx={12} cy={12} r={4} />
        <path d="M16 8v5a3 3 0 0 0 6 0v-1a10 10 0 1 0-3.92 7.94" />
      </svg>,
  variant: 'bg-red-50'
}, {
  title: 'Creative Idea',
  description: 'At vero eos et accusamus et iusto odio dignissimos ducimus qui blanditiis praesentium.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-emerald-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <path d="M22.65 14.39L12 22.13 1.35 14.39a.84.84 0 0 1-.3-.94l1.22-3.78 2.44-7.51A.42.42 0 0 1 4.82 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.49h8.1l2.44-7.51A.42.42 0 0 1 18.6 2a.43.43 0 0 1 .58 0 .42.42 0 0 1 .11.18l2.44 7.51L23 13.45a.84.84 0 0 1-.35.94z"></path>
      </svg>,
  variant: 'bg-emerald-50'
}, {
  title: 'Unlimited Features',
  description: 'Et harum quidem rerum facilis est expedita distinctio nam libero tempore cum soluta nobis est eligendi.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-sky-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="3" y="3" width="7" height="7" />
        <rect x="14" y="3" width="7" height="7" />
        <rect x="14" y="14" width="7" height="7" />
        <rect x="3" y="14" width="7" height="7" />
      </svg>,
  variant: 'bg-sky-50'
}, {
  title: 'Fully Responsive',
  description: 'Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-amber-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <rect x="2" y="3" width="20" height="14" rx="2" ry="2" />
        <line x1="8" y1="21" x2="16" y2="21" />
        <line x1="12" y1="17" x2="12" y2="21" />
      </svg>,
  variant: 'bg-amber-50'
}, {
  title: 'Finance Friendly',
  description: 'Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium rem doloremque laudantium.',
  icon: <svg xmlns="http://www.w3.org/2000/svg" className="h-10 w-10 text-violet-500" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
        <circle cx="12" cy="12" r="10" />
        <circle cx="12" cy="12" r="4" />
        <line x1="21.17" y1="8" x2="12" y2="8" />
        <line x1="3.95" y1="6.06" x2="8.54" y2="14" />
        <line x1="10.88" y1="21.94" x2="15.46" y2="14" />
      </svg>,
  variant: 'bg-violet-50'
}];
export const pricingPlans = [{
  name: 'Basic Plan',
  monthlyPrice: 8,
  yearlyPrice: 28,
  features: [{
    icon: 'lucide:check',
    name: '10 users',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '50 GB storage',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Front plan features',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '100 apps',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:x',
    name: 'Product support',
    variant: 'bg-red-500/20 text-red-500'
  }, {
    icon: 'lucide:x',
    name: 'Advanced security',
    variant: 'bg-red-500/20 text-red-500'
  }, {
    icon: 'lucide:x',
    name: 'Free subdomain',
    variant: 'bg-red-500/20 text-red-500'
  }]
}, {
  name: 'Business Plan',
  monthlyPrice: 18,
  yearlyPrice: 48,
  features: [{
    icon: 'lucide:check',
    name: '10 users',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '50 GB storage',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Front plan features',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '100 apps',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Product support',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Advanced security',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:x',
    name: 'Free subdomain',
    variant: 'bg-red-500/20 text-red-500'
  }],
  isPopular: true
}, {
  name: 'Exclusive Plan',
  monthlyPrice: 28,
  yearlyPrice: 68,
  features: [{
    icon: 'lucide:check',
    name: '10 users',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '50 GB storage',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Front plan features',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: '100 apps',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Product support',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Advanced security',
    variant: 'bg-primary/20 text-primary'
  }, {
    icon: 'lucide:check',
    name: 'Free subdomain',
    variant: 'bg-primary/20 text-primary'
  }]
}];
export const teamMembers = [{
  avatar: avatar7,
  userName: '@maxine',
  name: 'Maxine Gilmer',
  position: 'Web designer',
  description: 'These alternatives to the classic Lorem Ipsum texts are often amusing and tell short, funny or nonsensical stories.'
}, {
  avatar: avatar3,
  userName: '@michael',
  name: 'Michael Ellis',
  position: 'UI/UX designer',
  description: 'We all intend to plan ahead, but too often let the day-to-day minutia get in the way of making a calendar.'
}, {
  avatar: avatar8,
  userName: '@ruben',
  name: 'Ruben Gouse',
  position: 'Web developer',
  description: 'These qualities can be combined perfectly natural. However, things like people look miserable.'
}, {
  avatar: avatar5,
  userName: '@francis',
  name: 'Francis Ibikunle',
  position: 'Manager',
  description: 'These alternatives to the classic Lorem Ipsum are often amusing and tell short, funny or nonsensical stories.'
}];