<template>
    <section class="py-100 ct-02 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- IMAGE BLOCK -->
                <div class="col-md-6">
                    <div class="img-block left-column wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/img-07.png" alt="content-image" />
                    </div>
                </div>
                <!-- TEXT BLOCK -->
                <div class="col-md-6">
                    <div class="txt-block right-column wow fadeInLeft">
                        <!-- Section ID -->
                        <span class="section-id">Built-In Automation</span>
                        <!-- Title -->
                        <h2 class="s-46 w-700">Achieve more with better workflows</h2>
                        <!-- Text -->
                        <p>Sodales tempor sapien quaerat ipsum undo congue laoreet turpis neque auctor turpis vitae dolor luctus placerat magna and ligula cursus purus vitae purus an ipsum suscipit</p>
                        <!-- List -->
                        <ul class="simple-list">
                            <li class="list-item">
                                <p>Sapien quaerat tempor an ipsum laoreet purus and sapien dolor an ultrice ipsum aliquam undo congue cursus dolor</p>
                            </li>
                            <li class="list-item">
                                <p class="mb-0">Purus suscipit cursus vitae cubilia magnis volute egestas vitae sapien turpis ultrice auctor congue magna placerat</p>
                            </li>
                        </ul>
                        <!-- Link -->
                        <div class="txt-block-tra-link mt-25">
                            <a href="#integrations-1" class="tra-link ico-20 color--theme"> All-in-one platform <span class="flaticon-next"></span> </a>
                        </div>
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
