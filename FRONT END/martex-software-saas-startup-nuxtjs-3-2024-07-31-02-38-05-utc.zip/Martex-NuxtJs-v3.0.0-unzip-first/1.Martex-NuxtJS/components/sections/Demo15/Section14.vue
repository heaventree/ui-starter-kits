<template>
    <section id="reviews-2" class="pt-100 reviews-section">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Read what our users have to say about us</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- TESTIMONIALS-2 WRAPPER -->
            <div class="reviews-2-wrapper rel shape--02 shape--whitesmoke">
                <div class="row align-items-center row-cols-1 row-cols-md-2">
                    <!-- TESTIMONIAL #1 -->
                    <div class="col">
                        <div id="rw-2-1" class="review-2 bg--white-100 block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Text -->
                                <p>Quaerat sodales sapien euismod blandit aliquet ipsum primis undo and cubilia laoreet augue and luctus magna dolor luctus egestas sapien vitae</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-1.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Scott Boxer</h6>
                                        <p class="p-sm">@scott_boxer</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                    </div>
                    <!-- END TESTIMONIAL #1 -->
                    <!-- TESTIMONIAL #2 -->
                    <div class="col">
                        <div id="rw-2-2" class="review-2 bg--white-100 block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Text -->
                                <p>At sagittis congue augue and magna ipsum vitae a purus ipsum primis diam a cubilia laoreet augue egestas luctus a donec vitae ultrice ligula magna suscipit lectus gestas augue into cubilia</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-2.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Joel Peterson</h6>
                                        <p class="p-sm">Internet Surfer</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                    </div>
                    <!-- END TESTIMONIAL #2 -->
                    <!-- TESTIMONIAL #3 -->
                    <div class="col">
                        <div id="rw-2-3" class="review-2 bg--white-100 block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Text -->
                                <p>An augue cubilia laoreet magna suscipit egestas and ipsum a lectus purus ipsum primis and augue ultrice ligula and egestas a suscipit lectus gestas undo auctor tempus feugiat impedit quaerat</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-5.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Jennifer Harper</h6>
                                        <p class="p-sm">App Developer</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                    </div>
                    <!-- END TESTIMONIAL #3 -->
                    <!-- TESTIMONIAL #4 -->
                    <div class="col">
                        <div id="rw-2-4" class="review-2 bg--white-100 block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Text -->
                                <p>Augue at vitae purus tempus egestas volutpat augue undo cubilia laoreet magna suscipit luctus dolor blandit at purus tempus feugiat impedit</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-8.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Evelyn Martinez</h6>
                                        <p class="p-sm">WordPress Consultant</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                    </div>
                    <!-- END TESTIMONIAL #4 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END TESTIMONIALS-2 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
