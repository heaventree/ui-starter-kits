------------------------------------------------------------------
MDI - DASH-003 Dashboard Template
------------------------------------------------------------------
- 1 Screen Dashboard (Desktop size)
- 100% Color Customizable
- 100% Scalable All Files
- Compatibility with Figma
- Vector-Based Assets
- Free Vector Icons
- Layered by name
- Well Organized Layer
- Fully editable (all colors and text can be modified)
- Open Source Font (Google Font)
------------------------------------------------------------------

------------------------------------------------------------------
FONT DOWNLOAD LINK
------------------------------------------------------------------
Urbanist Font Family
https://fonts.google.com/specimen/Urbanist?query=urbanist
------------------------------------------------------------------

*Note:
 All images in the main file are replaced by placeholders, all images used for demo purpose only.