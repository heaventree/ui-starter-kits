<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/signup.html.twig */
class __TwigTemplate_97285ea72a101daa3eded023312619e0 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/signup.html.twig"));

        // line 1
        yield "<!doctype html>
<html lang=\"en\">

";
        // line 4
        yield from         $this->loadTemplate("partials/head.html.twig", "home/signup.html.twig", 4)->unwrap()->yield($context);
        // line 5
        yield "
<body>
    <div class=\"page-wrapper relative z-[1] bg-ColorOffWhite\">
        <main class=\"main-wrapper relative overflow-hidden\">
            <!-- Sign-in Section Start -->
            <section class=\"section-signin\">
                <!-- Section Space -->
                <div class=\"section-space\">
                    <!-- Section Container -->
                    <div class=\"container-default\">
                        <div class=\"mx-auto max-w-[636px]\">
                            <div class=\"flex flex-col items-center justify-center text-center\">
                                <!-- Logo -->
                                <a href=\"";
        // line 18
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"mb-[60px] lg:mb-20 xl:mb-[100px]\">
                                    <img src=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"logo-blue-dark\" width=\"109\" height=\"24\" />
                                </a>
                                <!-- Logo -->

                                <!-- Section Wrapper -->
                                <div>
                                    <!-- Section Block -->
                                    <div>
                                        <!-- Section Title -->
                                        <h2 class=\"mb-[15px]\">Create an account</h2>
                                        <!-- Section Title -->
                                        <p class=\"text-ColorBlack/80\">
                                            Enter the information below to create your account
                                        </p>
                                    </div>
                                    <!-- Section Block -->
                                </div>
                                <!-- Section Wrapper -->
                            </div>

                            <!-- Sign-in Form Block -->
                            <div class=\"jos xm:p-10 mt-10 rounded-[10px] border-2 border-ColorBlack bg-white p-[30px] lg:mt-[60px]\">
                                <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                                    <!-- From Group List -->
                                    <div class=\"flex flex-col gap-6\">
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"name\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Enter your full name</label>
                                            <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"email\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Email address*</label>
                                            <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"password\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Password*</label>
                                            <input type=\"password\" name=\"password\" id=\"password\" placeholder=\"**********\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->

                                        <!-- Form Group Item-->
                                        <div class=\"flex flex-wrap items-center justify-between text-base text-ColorBlack/80\">
                                            <label for=\"check\" class=\"flex items-center gap-2\">
                                                <input type=\"checkbox\" name=\"check\" id=\"check\" class=\"h-5 w-5 rounded-[10px] border border-ColorBlack accent-ColorBlue\" />
                                                <span>I agree to the Terms and Conditions of
                                                    Privacy</span>
                                            </label>
                                        </div>
                                        <!-- Form Group Item-->
                                    </div>
                                    <!-- From Group List -->
                                    <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8 w-full\">
                                        Create Account
                                    </button>
                                </form>

                                <p class=\"mt-[15px] text-center text-base text-ColorBlack/80\">
                                    Already have an account?
                                    <a href=\"";
        // line 81
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"font-semibold text-ColorBlue/80 hover:text-ColorBlue\">Sign in now</a>
                                </p>
                            </div>
                            <!-- Sign-in Form Block -->
                        </div>
                    </div>
                    <!-- Section Container -->
                </div>
                <!-- Section Space -->
            </section>
            <!-- Sign-in Section End -->
        </main>
    </div>

     <!--Vendor js-->
     <script src=\"";
        // line 96
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/counterup.js"), "html", null, true);
        yield "\" type=\"module\"></script>
    <script src=\"";
        // line 97
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/swiper-bundle.min.js"), "html", null, true);
        yield "\"></script>
    <script src=\"";
        // line 98
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/fslightbox.js"), "html", null, true);
        yield "\"></script>
    <script src=\"";
        // line 99
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/jos.min.js"), "html", null, true);
        yield "\"></script>

    <!-- Main js -->
    <script src=\"";
        // line 102
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/main.js"), "html", null, true);
        yield "\"></script>
</body>

</html>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/signup.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  168 => 102,  162 => 99,  158 => 98,  154 => 97,  150 => 96,  132 => 81,  67 => 19,  63 => 18,  48 => 5,  46 => 4,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!doctype html>
<html lang=\"en\">

{% include 'partials/head.html.twig' %}

<body>
    <div class=\"page-wrapper relative z-[1] bg-ColorOffWhite\">
        <main class=\"main-wrapper relative overflow-hidden\">
            <!-- Sign-in Section Start -->
            <section class=\"section-signin\">
                <!-- Section Space -->
                <div class=\"section-space\">
                    <!-- Section Container -->
                    <div class=\"container-default\">
                        <div class=\"mx-auto max-w-[636px]\">
                            <div class=\"flex flex-col items-center justify-center text-center\">
                                <!-- Logo -->
                                <a href=\"{{ path('home') }}\" class=\"mb-[60px] lg:mb-20 xl:mb-[100px]\">
                                    <img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"logo-blue-dark\" width=\"109\" height=\"24\" />
                                </a>
                                <!-- Logo -->

                                <!-- Section Wrapper -->
                                <div>
                                    <!-- Section Block -->
                                    <div>
                                        <!-- Section Title -->
                                        <h2 class=\"mb-[15px]\">Create an account</h2>
                                        <!-- Section Title -->
                                        <p class=\"text-ColorBlack/80\">
                                            Enter the information below to create your account
                                        </p>
                                    </div>
                                    <!-- Section Block -->
                                </div>
                                <!-- Section Wrapper -->
                            </div>

                            <!-- Sign-in Form Block -->
                            <div class=\"jos xm:p-10 mt-10 rounded-[10px] border-2 border-ColorBlack bg-white p-[30px] lg:mt-[60px]\">
                                <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                                    <!-- From Group List -->
                                    <div class=\"flex flex-col gap-6\">
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"name\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Enter your full name</label>
                                            <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"email\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Email address*</label>
                                            <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->
                                        <!-- Form Group Item-->
                                        <div>
                                            <label for=\"password\" class=\"mb-[10px] block text-left font-semibold text-ColorBlack\">Password*</label>
                                            <input type=\"password\" name=\"password\" id=\"password\" placeholder=\"**********\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                                        </div>
                                        <!-- Form Group Item-->

                                        <!-- Form Group Item-->
                                        <div class=\"flex flex-wrap items-center justify-between text-base text-ColorBlack/80\">
                                            <label for=\"check\" class=\"flex items-center gap-2\">
                                                <input type=\"checkbox\" name=\"check\" id=\"check\" class=\"h-5 w-5 rounded-[10px] border border-ColorBlack accent-ColorBlue\" />
                                                <span>I agree to the Terms and Conditions of
                                                    Privacy</span>
                                            </label>
                                        </div>
                                        <!-- Form Group Item-->
                                    </div>
                                    <!-- From Group List -->
                                    <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8 w-full\">
                                        Create Account
                                    </button>
                                </form>

                                <p class=\"mt-[15px] text-center text-base text-ColorBlack/80\">
                                    Already have an account?
                                    <a href=\"{{ path('login') }}\" class=\"font-semibold text-ColorBlue/80 hover:text-ColorBlue\">Sign in now</a>
                                </p>
                            </div>
                            <!-- Sign-in Form Block -->
                        </div>
                    </div>
                    <!-- Section Container -->
                </div>
                <!-- Section Space -->
            </section>
            <!-- Sign-in Section End -->
        </main>
    </div>

     <!--Vendor js-->
     <script src=\"{{ asset('assets/js/vendors/counterup.js') }}\" type=\"module\"></script>
    <script src=\"{{ asset('assets/js/vendors/swiper-bundle.min.js') }}\"></script>
    <script src=\"{{ asset('assets/js/vendors/fslightbox.js') }}\"></script>
    <script src=\"{{ asset('assets/js/vendors/jos.min.js') }}\"></script>

    <!-- Main js -->
    <script src=\"{{ asset('assets/js/main.js') }}\"></script>
</body>

</html>
", "home/signup.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\signup.html.twig");
    }
}
