import type { FaqType, FooterLinkType } from '@/types/data'

export const faqsData: FaqType[] = [
  {
    question: 'Who are produces sit pleasure?',
    answer:
      'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. ',
  },
  {
    question: 'What is quo voluptas nulla pariatur?',
    answer:
      'Vivamus elementum semper nisi. Aenean vulputate eleifend tellus. Aenean leo ligula, porttitor eu, consequat vitae, eleifend ac, enim. Aliquam lorem ante, dapibus in, viverra quis, feugiat a, tellus. Phasellus viverra nulla ut metus varius laoreet. Duis leo. Sed fringilla mauris sit amet nibh.',
  },
  {
    question: 'How to do transactions using iMbank?',
    answer:
      'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. ',
  },
  {
    question: 'How to activate iMbank service?',
    answer:
      'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. ',
  },
  {
    question: 'Who is eligible to open iMbank account?',
    answer:
      'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. ',
  },
  {
    question: 'Will I be given a passbook?',
    answer:
      'Aenean commodo ligula eget dolor. Aenean massa. Cum sociis natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Donec quam felis, ultricies nec, pellentesque eu, pretium quis, sem. ',
  },
]

export const footerLinks: FooterLinkType[] = [
  {
    title: 'About Us',
    links: [
      'Support Center',
      'Customer Support',
      'About Us',
      'Copyright',
      'Popular Campaign',
      'Return Policy',
      'Privacy Policy',
      'Terms & Conditions',
    ],
  },
  {
    title: 'My Account',
    links: ['Press Inquiries', 'Social Media Directories', 'Images & B-roll', 'Site Map', 'Store Hours', 'Permissions', 'Speaker Requests'],
  },
  {
    title: 'Policy',
    links: ['Application Security', 'Software Principles', 'Software Policy', 'Responsible Supply'],
  },
]
