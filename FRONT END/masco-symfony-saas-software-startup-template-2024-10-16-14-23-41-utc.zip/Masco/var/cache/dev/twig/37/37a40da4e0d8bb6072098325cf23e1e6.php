<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/head.html.twig */
class __TwigTemplate_4ecf408cc12acaabfe073b7758448efa extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/head.html.twig"));

        // line 1
        yield "<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>Masco - Saas Software Startup Tailwind Template</title>
    <meta name=\"description\" content=\"AIMass Tailwind based SASS Template\" />

    <!-- Favicon  -->
    <link rel=\"icon\" href=\"";
        // line 8
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/favicon.png"), "html", null, true);
        yield "\" />

    <!-- Icon Font -->
    <link rel=\"stylesheet\" href=\"";
        // line 11
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/iconfonts/font-awesome/stylesheet.css"), "html", null, true);
        yield "\" />
    <!-- Site font -->
    <link rel=\"stylesheet\" href=\"";
        // line 13
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/inter/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 14
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/plus-jakarta-sans/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 15
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/syne/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 16
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/outfit/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 17
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/sora/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 18
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/dm-sans/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/cabin/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 20
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/general-sans/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 21
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/public-sans/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 22
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/kanit/stylesheet.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 23
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/fonts/webfonts/clash-display/stylesheet.css"), "html", null, true);
        yield "\" />

    <!-- Vendor CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 26
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/vendors/swiper-bundle.min.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 27
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/vendors/jos.css"), "html", null, true);
        yield "\" />
    <link rel=\"stylesheet\" href=\"";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/vendors/menu.css"), "html", null, true);
        yield "\" />

    <!-- Custom CSS -->
    <link rel=\"stylesheet\" href=\"";
        // line 31
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/custom.css"), "html", null, true);
        yield "\" />

    <!-- Development css -->
    <link href=\"";
        // line 34
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/css/style.css"), "html", null, true);
        yield "\" rel=\"stylesheet\" />

</head>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "partials/head.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  127 => 34,  121 => 31,  115 => 28,  111 => 27,  107 => 26,  101 => 23,  97 => 22,  93 => 21,  89 => 20,  85 => 19,  81 => 18,  77 => 17,  73 => 16,  69 => 15,  65 => 14,  61 => 13,  56 => 11,  50 => 8,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<head>
    <meta charset=\"UTF-8\" />
    <meta name=\"viewport\" content=\"width=device-width, initial-scale=1.0\" />
    <title>Masco - Saas Software Startup Tailwind Template</title>
    <meta name=\"description\" content=\"AIMass Tailwind based SASS Template\" />

    <!-- Favicon  -->
    <link rel=\"icon\" href=\"{{ asset('assets/img/favicon.png') }}\" />

    <!-- Icon Font -->
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/iconfonts/font-awesome/stylesheet.css') }}\" />
    <!-- Site font -->
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/inter/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/plus-jakarta-sans/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/syne/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/outfit/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/sora/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/dm-sans/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/cabin/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/general-sans/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/public-sans/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/kanit/stylesheet.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/fonts/webfonts/clash-display/stylesheet.css') }}\" />

    <!-- Vendor CSS -->
    <link rel=\"stylesheet\" href=\"{{ asset('assets/css/vendors/swiper-bundle.min.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/css/vendors/jos.css') }}\" />
    <link rel=\"stylesheet\" href=\"{{ asset('assets/css/vendors/menu.css') }}\" />

    <!-- Custom CSS -->
    <link rel=\"stylesheet\" href=\"{{ asset('assets/css/custom.css') }}\" />

    <!-- Development css -->
    <link href=\"{{ asset('assets/css/style.css') }}\" rel=\"stylesheet\" />

</head>
", "partials/head.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\partials\\head.html.twig");
    }
}
