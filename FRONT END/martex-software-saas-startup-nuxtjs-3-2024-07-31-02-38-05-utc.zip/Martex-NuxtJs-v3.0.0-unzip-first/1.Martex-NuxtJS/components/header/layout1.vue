<template>
    <header id="header" class="tra-menu white-scroll">
        <div class="header-wrapper">
            <HeaderLogo />
            <HeaderMenu />
            <HeaderDarkLightToggle />
        </div>
    </header>
</template>
