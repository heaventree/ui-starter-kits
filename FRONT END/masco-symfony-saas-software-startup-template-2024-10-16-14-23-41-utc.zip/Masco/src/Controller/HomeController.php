<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class HomeController extends AbstractController
{
    #[Route('/home/about', name:'about')]
    public function about(): Response
    {
        return $this->render('/home/about.html.twig',[
            'title' => 'About Us',
            'subTitle' => 'About',
        ]);
    }
        
    #[Route('/home/blog', name:'blog')]
    public function blog(): Response
    {
        return $this->render('home/blog.html.twig',[
            'title' => 'Blog',
            'subTitle' => 'Blog',
        ]);
    }

    #[Route('/home/blog-details', name:'blogDetails')]
    public function blogDetails(): Response
    {
        return $this->render('home/blogDetails.html.twig',[
            'title' => 'Blog Details',
            'subTitle' => 'Blog Details',
        ]);
    }

    #[Route('/home/career-details', name:'careerDetails')]
    public function careerDetails(): Response
    {
        return $this->render('home/careerDetails.html.twig',[
            'title' => 'UI/UX and product designer',
            'subTitle' => 'Career Details',
        ]);
    }

    #[Route('/home/careers', name:'careers')]
    public function careers(): Response
    {
        return $this->render('home/careers.html.twig',[
            'title' => 'Careers',
            'subTitle' => 'Careers',
        ]);
    }

    #[Route('/home/comingsoon', name:'comingsoon')]
    public function comingsoon(): Response
    {
        return $this->render('home/comingsoon.html.twig',[
            'title' => '',
            'subTitle' => '',
        ]);
    }

    #[Route('/home/contact', name:'contact')]
    public function contact(): Response
    {
        return $this->render('home/contact.html.twig',[
            'title' => 'Contact Us',
            'subTitle' => 'Contact Us',
        ]);
    }

    #[Route('/home/contact2', name:'contact2')]
    public function contact2(): Response
    {
        return $this->render('home/contact2.html.twig',[
            'title' => 'Send us a message',
            'subTitle' => 'Contact Us',
        ]);
    }

    #[Route('/home/contact3', name:'contact3')]
    public function contact3(): Response
    {
        return $this->render('home/contact3.html.twig',[
            'title' => 'Contact Us',
            'subTitle' => 'Contact Us',
        ]);
    }

    #[Route('/home/error404', name:'error404')]
    public function error404(): Response
    {
        return $this->render('home/error404.html.twig');
    }

    #[Route('/home/faq', name:'faq')]
    public function faq(): Response
    {
        return $this->render('home/faq.html.twig',[
            'title' => 'FAQs',
            'subTitle' => 'FAQ',
        ]);
    }

    #[Route('/home/faq2', name:'faq2')]
    public function faq2(): Response
    {
        return $this->render('home/faq2.html.twig',[
            'title' => 'FAQs',
            'subTitle' => 'FAQ',
        ]);
    }

    #[Route('/home/faq3', name:'faq3')]
    public function faq3(): Response
    {
        return $this->render('home/faq3.html.twig',[
            'title' => 'FAQs',
            'subTitle' => 'FAQ',
        ]);
    }

    #[Route('/home/faq4', name:'faq4')]
    public function faq4(): Response
    {
        return $this->render('home/faq4.html.twig',[
            'title' => 'FAQs',
            'subTitle' => 'FAQ',
        ]);
    }

    #[Route('/home/login', name:'login')]
    public function login(): Response
    {
        return $this->render('home/login.html.twig');
    }

    #[Route('/home/portfolio', name:'portfolio')]
    public function portfolio(): Response
    {
        return $this->render('home/portfolio.html.twig',[
            'title' => 'Portfolio Classic',
            'subTitle' => 'Portfolio Classic',
        ]);
    }

    #[Route('/home/portfolio2', name:'portfolio2')]
    public function portfolio2(): Response
    {
        return $this->render('home/portfolio2.html.twig',[
            'title' => 'Portfolio Masonry',
            'subTitle' => 'Portfolio Masonry',
        ]);
    }

    #[Route('/home/portfolio3', name:'portfolio3')]
    public function portfolio3(): Response
    {
        return $this->render('home/portfolio3.html.twig',[
            'title' => 'Portfolio Modern',
            'subTitle' => 'Portfolio Modern',
        ]);
    }

    #[Route('/home/portfolio4', name:'portfolio4')]
    public function portfolio4(): Response
    {
        return $this->render('home/portfolio4.html.twig',[
            'title' => 'Portfolio Minimal',
            'subTitle' => 'Portfolio Minimal',
        ]);
    }

    #[Route('/home/portfolio-details', name:'portfolioDetails')]
    public function portfolioDetails(): Response
    {
        return $this->render('home/portfolioDetails.html.twig',[
            'title' => 'Applications',
            'subTitle' => 'Portfolio Details',
        ]);
    }

    #[Route('/home/pricing', name:'pricing')]
    public function pricing(): Response
    {
        return $this->render('home/pricing.html.twig',[
            'title' => 'Pricing',
            'subTitle' => 'Pricing',
        ]);
    }

    #[Route('/home/pricing2', name:'pricing2')]
    public function pricing2(): Response
    {
        return $this->render('home/pricing2.html.twig',[
            'title' => 'Pricing',
            'subTitle' => 'Pricing',
        ]);
    }

    #[Route('/home/reset-password', name:'resetPassword')]
    public function resetPassword(): Response
    {
        return $this->render('home/resetPassword.html.twig');
    }

    #[Route('/home/service-details', name:'serviceDetails')]
    public function serviceDetails(): Response
    {
        return $this->render('home/serviceDetails.html.twig',[
            'title' => 'Service Details',
            'subTitle' => 'Service Details',
        ]);
    }

    #[Route('/home/services', name:'services')]
    public function services(): Response
    {
        return $this->render('home/services.html.twig',[
            'title' => 'Our Services',
            'subTitle' => 'Our Services',
        ]);
    }

    #[Route('/home/signup', name:'signup')]
    public function signup(): Response
    {
        return $this->render('home/signup.html.twig');
    }

    #[Route('/home/teams', name:'teams')]
    public function teams(): Response
    {
        return $this->render('home/teams.html.twig',[
            'title' => 'Our Team',
            'subTitle' => 'Our Team',
        ]);
    }


}
