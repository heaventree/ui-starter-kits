export { default } from "./Faq";
