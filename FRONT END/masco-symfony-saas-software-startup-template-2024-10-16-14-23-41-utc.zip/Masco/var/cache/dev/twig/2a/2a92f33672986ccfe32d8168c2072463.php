<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/portfolio2.html.twig */
class __TwigTemplate_053eb5ebe5885d2b784bb170f98dce62 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/portfolio2.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/portfolio2.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/portfolio2.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Tab Button Menu -->
            <div class=\"flex flex-wrap justify-center gap-3 md:gap-6\">
                <button class=\"active tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"show-all\">
                    Show All
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"website\">
                    Website
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"branding\">
                    Branding
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"commercial\">
                    Commercial
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"ui-ux-design\">
                    UI/UX Design
                </button>
            </div>
            <!-- Tab Button Menu -->

            <!-- Portfolio Area -->
            <div class=\"my-10 lg:my-[60xp] xl:my-20\">
                <!-- Portfolio List -->
                <div class=\"tab-content columns-1 gap-6 md:columns-2\" id=\"show-all\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 66
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-1.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 69
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">App — The power of communication</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 81
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-3.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 84
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Strategic — Ways to level up your brand</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 96
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-4.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-4\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 99
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Journal — Asset in business</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Commercial</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 111
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 114
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 126
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-5.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-5\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 129
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Book — Design of the year</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"website\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 145
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 148
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"branding\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 164
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 167
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 179
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-3.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 182
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Strategic — Ways to level up your brand</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"commercial\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 198
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-4.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-4\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 201
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Journal — Asset in business</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Commercial</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"ui-ux-design\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 217
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-1.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 220
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">App — The power of communication</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 232
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-masonry-img-5.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-masonry-img-5\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"";
        // line 235
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Book — Design of the year</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Portfolio Area -->

            <div class=\"flex justify-center\">
                <button class=\"btn is-blue is-rounded is-large group\">
                    View more
                </button>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 264
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 265
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/portfolio2.html.twig", 265)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/portfolio2.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  443 => 265,  436 => 264,  402 => 235,  396 => 232,  381 => 220,  375 => 217,  356 => 201,  350 => 198,  331 => 182,  325 => 179,  310 => 167,  304 => 164,  285 => 148,  279 => 145,  260 => 129,  254 => 126,  239 => 114,  233 => 111,  218 => 99,  212 => 96,  197 => 84,  191 => 81,  176 => 69,  170 => 66,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Tab Button Menu -->
            <div class=\"flex flex-wrap justify-center gap-3 md:gap-6\">
                <button class=\"active tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"show-all\">
                    Show All
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"website\">
                    Website
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"branding\">
                    Branding
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"commercial\">
                    Commercial
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"ui-ux-design\">
                    UI/UX Design
                </button>
            </div>
            <!-- Tab Button Menu -->

            <!-- Portfolio Area -->
            <div class=\"my-10 lg:my-[60xp] xl:my-20\">
                <!-- Portfolio List -->
                <div class=\"tab-content columns-1 gap-6 md:columns-2\" id=\"show-all\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-1.jpg') }}\" alt=\"portfolio-masonry-img-1.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">App — The power of communication</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-3.jpg') }}\" alt=\"portfolio-masonry-img-3.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Strategic — Ways to level up your brand</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-4.jpg') }}\" alt=\"portfolio-masonry-img-4\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Journal — Asset in business</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Commercial</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-2.jpg') }}\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-5.jpg') }}\" alt=\"portfolio-masonry-img-5\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Book — Design of the year</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"website\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-2.jpg') }}\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"branding\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-2.jpg') }}\" alt=\"portfolio-masonry-img-2.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Website — The future lifestyle platform</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-3.jpg') }}\" alt=\"portfolio-masonry-img-3.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Strategic — Ways to level up your brand</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Branding</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"commercial\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-4.jpg') }}\" alt=\"portfolio-masonry-img-4\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Journal — Asset in business</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">Commercial</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
                <!-- Portfolio List -->
                <div class=\"tab-content hidden columns-1 gap-6 md:columns-2\" id=\"ui-ux-design\">
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-1.jpg') }}\" alt=\"portfolio-masonry-img-1.jpg\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">App — The power of communication</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos mb-6\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"relative overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-masonry-img-5.jpg') }}\" alt=\"portfolio-masonry-img-5\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover\" />
                                <div class=\"absolute inset-0 flex translate-y-full items-end bg-gradient-to-b from-ColorBlack/0 to-ColorBlack p-6 transition-all duration-500 ease-in-out group-hover:translate-y-0 lg:p-10\">
                                    <div class=\"flex flex-col text-white\">
                                        <a href=\"{{ path('portfolioDetails') }}\" class=\"mb-3 translate-y-8 text-xl font-semibold leading-[1.33] -tracking-[0.5px] transition-all duration-300 ease-in-out group-hover:translate-y-0 xl:text-2xl\">Book — Design of the year</a>
                                        <a href=\"#\" class=\"translate-y-16 transition-all delay-300 duration-500 ease-in-out group-hover:translate-y-0\">UI/UX Design</a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Portfolio Area -->

            <div class=\"flex justify-center\">
                <button class=\"btn is-blue is-rounded is-large group\">
                    View more
                </button>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/portfolio2.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\portfolio2.html.twig");
    }
}
