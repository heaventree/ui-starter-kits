<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/contact.html.twig */
class __TwigTemplate_e77868a71e2671fa0ff10004ee8dedd6 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'headButtons' => [$this, 'block_headButtons'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/contact.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/contact.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 7
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 8
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/contact.html.twig", 8)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 11
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 12
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 14
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 15
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Contact Info Section Start -->
<div class=\"section-contact-info\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Contact Info List -->
            <div class=\"grid gap-6 md:grid-cols-2 lg:grid-cols-3\">
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"";
        // line 44
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-chat.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-chat\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Chat with us
                                </div>
                                <p>
                                    We're waiting to help you every Monday-Friday from 9
                                    am to 5 pm EST easily.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0.3\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"";
        // line 62
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-phone.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-phone\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Give us a call
                                </div>
                                <p>
                                    Give us a ring at
                                    <a href=\"tel:+01234567890\" class=\"font-semibold hover:text-ColorBlue\">(+012-345-567-890)</a>. Every monday-friday from 9 am to 5 pm.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0.6\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"";
        // line 80
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-duotone-message.svg"), "html", null, true);
        yield "\" alt=\"icon-duotone-message\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Email Us
                                </div>
                                <p>
                                    Drop us an email at
                                    <a href=\"mailto:example@yourmail.com\" class=\"font-semibold underline underline-offset-4 hover:text-ColorBlue\">example@gmail.com</a>
                                    and you'll receive a reply within 24 hours.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- Contact Info Section End -->

<!-- Contact Section Start -->
<section class=\"section-contact\">
    <!-- Section Space -->
    <div class=\"section-space-bottom\">
        <!-- Section Container -->
        <div class=\"container-custom has-container-custom\">
            <!-- Contact Section Area -->
            <div class=\"grid gap-[60px] lg:grid-cols-[0.85fr_1fr] lg:gap-20 xl:gap-[100px] xxl:gap-[134px]\">
                <!-- Contact Content Block -->
                <div class=\"jos\">
                    <!-- Section Wrapper -->
                    <div>
                        <!-- Section Block -->
                        <div class=\"mb-5\">
                            <h2>
                                Fill out this form, We ‘ll quickly get back to you
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <p>
                            We are here to help you! Tell us how we can help and we’ll
                            get in touch within next 24hrs with expert
                        </p>
                        <!-- Horizontal Line Separator -->
                        <div class=\"my-7 h-px w-full bg-ColorBlack opacity-10 xl:my-10 xxl:my-14\"></div>
                        <!-- BlockQuote Block-->
                        <div>
                            <div class=\"mb-[25px] flex justify-center gap-1 text-[#FFC947] lg:justify-start\">
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                            </div>
                            <blockquote class=\"mb-6 font-semibold italic text-opacity-80\">
                                \"Snaga did an exceptional job for us. keep up the
                                excellent digital work. Man, this thing is getting
                                better and better as I learn more about it. I have
                                gotten at least 50 times the value from Snaga. It is
                                worth much more than I paid.\"
                            </blockquote>
                            <div class=\"flex flex-col items-center gap-4 lg:flex-row\">
                                <img src=\"";
        // line 146
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/about-hero-user-blockquote-img-2.jpg"), "html", null, true);
        yield "\" alt=\"about-hero-user-blockquote-img-2\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] rounded-[50%] lg:mx-0\" />
                                <div>
                                    <span class=\"block font-semibold text-ColorBlack\">Brooklyn Simmons</span>
                                    <span class=\"text-sm text-opacity-80\">CEO & Co-founder @ Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Contact Content Block -->

                <!-- Contact Form Block -->
                <div class=\"jos xm:p-10 rounded-[10px] border border-ColorBlack/50 bg-ColorOffWhite p-[30px]\">
                    <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                        <!-- From Group List -->
                        <div class=\"flex flex-col gap-6\">
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"name\" class=\"mb-[10px] block text-left font-semibold\">Your name</label>
                                <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your full name\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                            </div>
                            <!-- Form Group Item-->
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"email\" class=\"mb-[10px] block text-left font-semibold\">Email address</label>
                                <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your full name\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                            </div>
                            <!-- Form Group Item-->
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"message\" class=\"mb-[10px] block text-left font-semibold\">Write your message</label>
                                <textarea name=\"message\" id=\"message\" placeholder=\"Write us your question here...\" class=\"min-h-[130px] w-full rounded-[30px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required></textarea>
                            </div>
                            <!-- Form Group Item-->
                        </div>
                        <!-- From Group List -->
                        <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8\">
                            Send Message
                        </button>
                    </form>
                </div>
                <!-- Contact Form Block -->
            </div>
            <!-- Contact Section Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Contact Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 202
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 203
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/contact.html.twig", 203)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/contact.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  327 => 203,  320 => 202,  259 => 146,  190 => 80,  169 => 62,  148 => 44,  133 => 31,  126 => 30,  106 => 15,  102 => 14,  98 => 12,  91 => 11,  82 => 8,  75 => 7,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 



{% block content %}

<!-- Contact Info Section Start -->
<div class=\"section-contact-info\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Contact Info List -->
            <div class=\"grid gap-6 md:grid-cols-2 lg:grid-cols-3\">
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-chat.svg') }}\" alt=\"icon-duotone-chat\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Chat with us
                                </div>
                                <p>
                                    We're waiting to help you every Monday-Friday from 9
                                    am to 5 pm EST easily.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0.3\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-phone.svg') }}\" alt=\"icon-duotone-phone\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Give us a call
                                </div>
                                <p>
                                    Give us a ring at
                                    <a href=\"tel:+01234567890\" class=\"font-semibold hover:text-ColorBlue\">(+012-345-567-890)</a>. Every monday-friday from 9 am to 5 pm.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info Item -->
                <div class=\"jos\" data-jos_delay=\"0.6\">
                    <div class=\"hover-solid-shadow h-full\">
                        <div class=\"h-full rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                            <img src=\"{{ asset('assets/img/icons/icon-duotone-message.svg') }}\" alt=\"icon-duotone-message\" width=\"64\" height=\"60\" class=\"mb-[30px] h-[60px] w-auto\" />
                            <div>
                                <div class=\"mb-4 text-2xl font-semibold -tracking-[0.5]\">
                                    Email Us
                                </div>
                                <p>
                                    Drop us an email at
                                    <a href=\"mailto:example@yourmail.com\" class=\"font-semibold underline underline-offset-4 hover:text-ColorBlue\">example@gmail.com</a>
                                    and you'll receive a reply within 24 hours.
                                </p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Contact Info Item -->
                <!-- Contact Info List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- Contact Info Section End -->

<!-- Contact Section Start -->
<section class=\"section-contact\">
    <!-- Section Space -->
    <div class=\"section-space-bottom\">
        <!-- Section Container -->
        <div class=\"container-custom has-container-custom\">
            <!-- Contact Section Area -->
            <div class=\"grid gap-[60px] lg:grid-cols-[0.85fr_1fr] lg:gap-20 xl:gap-[100px] xxl:gap-[134px]\">
                <!-- Contact Content Block -->
                <div class=\"jos\">
                    <!-- Section Wrapper -->
                    <div>
                        <!-- Section Block -->
                        <div class=\"mb-5\">
                            <h2>
                                Fill out this form, We ‘ll quickly get back to you
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <p>
                            We are here to help you! Tell us how we can help and we’ll
                            get in touch within next 24hrs with expert
                        </p>
                        <!-- Horizontal Line Separator -->
                        <div class=\"my-7 h-px w-full bg-ColorBlack opacity-10 xl:my-10 xxl:my-14\"></div>
                        <!-- BlockQuote Block-->
                        <div>
                            <div class=\"mb-[25px] flex justify-center gap-1 text-[#FFC947] lg:justify-start\">
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                                <span><i class=\"fa-sharp fa-solid fa-star\"></i></span>
                            </div>
                            <blockquote class=\"mb-6 font-semibold italic text-opacity-80\">
                                \"Snaga did an exceptional job for us. keep up the
                                excellent digital work. Man, this thing is getting
                                better and better as I learn more about it. I have
                                gotten at least 50 times the value from Snaga. It is
                                worth much more than I paid.\"
                            </blockquote>
                            <div class=\"flex flex-col items-center gap-4 lg:flex-row\">
                                <img src=\"{{ asset('assets/img/th-1/about-hero-user-blockquote-img-2.jpg') }}\" alt=\"about-hero-user-blockquote-img-2\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] rounded-[50%] lg:mx-0\" />
                                <div>
                                    <span class=\"block font-semibold text-ColorBlack\">Brooklyn Simmons</span>
                                    <span class=\"text-sm text-opacity-80\">CEO & Co-founder @ Company</span>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Contact Content Block -->

                <!-- Contact Form Block -->
                <div class=\"jos xm:p-10 rounded-[10px] border border-ColorBlack/50 bg-ColorOffWhite p-[30px]\">
                    <form action=\"https://formspree.io/f/mlqvzkyx\" method=\"post\">
                        <!-- From Group List -->
                        <div class=\"flex flex-col gap-6\">
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"name\" class=\"mb-[10px] block text-left font-semibold\">Your name</label>
                                <input type=\"text\" name=\"name\" id=\"name\" placeholder=\"Enter your full name\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                            </div>
                            <!-- Form Group Item-->
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"email\" class=\"mb-[10px] block text-left font-semibold\">Email address</label>
                                <input type=\"email\" name=\"email\" id=\"email\" placeholder=\"Enter your full name\" class=\"w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required />
                            </div>
                            <!-- Form Group Item-->
                            <!-- Form Group Item-->
                            <div>
                                <label for=\"message\" class=\"mb-[10px] block text-left font-semibold\">Write your message</label>
                                <textarea name=\"message\" id=\"message\" placeholder=\"Write us your question here...\" class=\"min-h-[130px] w-full rounded-[30px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/50 focus:border-ColorBlue\" required></textarea>
                            </div>
                            <!-- Form Group Item-->
                        </div>
                        <!-- From Group List -->
                        <button type=\"submit\" class=\"btn is-blue is-rounded is-large mt-8\">
                            Send Message
                        </button>
                    </form>
                </div>
                <!-- Contact Form Block -->
            </div>
            <!-- Contact Section Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Contact Section End -->

{% endblock %} 



{% block footer %}
{% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/contact.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\contact.html.twig");
    }
}
