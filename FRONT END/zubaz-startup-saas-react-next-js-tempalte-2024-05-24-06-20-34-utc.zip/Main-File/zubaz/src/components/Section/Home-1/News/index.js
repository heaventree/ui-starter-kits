export { default } from "./News";
