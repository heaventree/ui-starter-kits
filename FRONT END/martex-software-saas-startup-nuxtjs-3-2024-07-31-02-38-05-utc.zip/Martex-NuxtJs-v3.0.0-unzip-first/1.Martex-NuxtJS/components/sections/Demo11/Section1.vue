<template>
    <section id="hero-11" class="bg--scroll hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO TEXT -->
                <div class="col-md-6">
                    <div class="hero-11-txt wow fadeInRight">
                        <!-- Title -->
                        <h2 class="s-60 w-700">A design experience like never before</h2>
                        <!-- Text -->
                        <p class="p-lg">Mauris donec turpis suscipit sapien ociis sagittis sapien tempor a volute ligula and aliquet tortor</p>
                        <!-- Button -->
                        <a href="#banner-3" class="btn r-04 btn--theme hover--tra-black">Get started for free</a>
                        <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> No credit card needed, free 14-day trial</p>
                    </div>
                </div>
                <!-- END HERO TEXT -->
                <!-- HERO IMAGE -->
                <div class="col-md-6">
                    <div class="hero-11-img text-center wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/hero-11-img.png" alt="hero-image" />
                    </div>
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
