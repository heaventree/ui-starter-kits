<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/error404.html.twig */
class __TwigTemplate_4bdd31a9e7cdb8b3783a6b892825d504 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/error404.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/error404.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 8
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 9
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 11
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 27
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 28
        yield "
 <!-- 404 Section Start -->
 <section class=\"section-404\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"\"></div>
            <div class=\"mt-10 flex flex-col items-center justify-center text-center lg:mt-[60px] xl:mt-[90px]\">
                <img src=\"";
        // line 37
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/404-img.svg"), "html", null, true);
        yield "\" alt=\"404-img\" width=\"532\" height=\"550\" class=\"mb-[30px]\" />
                <h2 class=\"mb-[15px]\">Page not found</h2>
                <p class=\"mb-10 max-w-[374px] text-ColorBlack/80\">
                    The requested URL you are looking for doesn’t exist on this
                    server.
                </p>
                <a href=\"";
        // line 43
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Back To Homepage</span></a>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- 404 Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 56
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 57
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/error404.html.twig", 57)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/error404.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  161 => 57,  154 => 56,  136 => 43,  127 => 37,  116 => 28,  109 => 27,  89 => 12,  85 => 11,  81 => 9,  74 => 8,  63 => 4,  56 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 


{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 



{% block content %}

 <!-- 404 Section Start -->
 <section class=\"section-404\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"\"></div>
            <div class=\"mt-10 flex flex-col items-center justify-center text-center lg:mt-[60px] xl:mt-[90px]\">
                <img src=\"{{ asset('assets/img/th-1/404-img.svg') }}\" alt=\"404-img\" width=\"532\" height=\"550\" class=\"mb-[30px]\" />
                <h2 class=\"mb-[15px]\">Page not found</h2>
                <p class=\"mb-10 max-w-[374px] text-ColorBlack/80\">
                    The requested URL you are looking for doesn’t exist on this
                    server.
                </p>
                <a href=\"{{ path('home') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Back To Homepage</span></a>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- 404 Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/error404.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\error404.html.twig");
    }
}
