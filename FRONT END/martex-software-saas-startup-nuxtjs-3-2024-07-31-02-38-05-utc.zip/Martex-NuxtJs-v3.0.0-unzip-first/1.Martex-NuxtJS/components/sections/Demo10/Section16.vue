<template>
    <section id="reviews-1" class="gr--whitesmoke pt-100 reviews-section">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-48 w-700">Read what our users have to say about us</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- TESTIMONIALS CONTENT -->
            <div class="row">
                <div class="col">
                    <SlidersTetimonials />
                </div>
            </div>
            <!-- END TESTIMONIALS CONTENT -->
        </div>
        <!-- End container -->
    </section>
</template>
