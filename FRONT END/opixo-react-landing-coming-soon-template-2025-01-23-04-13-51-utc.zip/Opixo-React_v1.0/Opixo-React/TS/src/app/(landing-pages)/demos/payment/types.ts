export type StepType = {
  icon: string
  title: string
  description: string
}

export type platformType = {
  icon: string
  title: string
  description: string
}
