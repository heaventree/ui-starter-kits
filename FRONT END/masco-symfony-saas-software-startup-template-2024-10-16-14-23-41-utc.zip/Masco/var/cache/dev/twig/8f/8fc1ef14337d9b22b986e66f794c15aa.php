<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/pricing2.html.twig */
class __TwigTemplate_32b98f8fabe4181d45f27a09f79b2515 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/pricing2.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/pricing2.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/pricing2.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Pricing Section Start -->
<section class=\"section-pricing\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Section Content Wrapper -->
            <div class=\"jos\">
                <!-- Section Content Block -->
                <div class=\"mx-auto max-w-[636px]\">
                    <div class=\"mb-5\">
                        <h2 class=\"text-center font-bold leading-[1.14] text-[#121212]\">
                            Our pricing plans are designed for your favor
                        </h2>
                    </div>
                    <p class=\"text-center\">
                        Starting any business has a cost, so you need to determine
                        how you will cover the costs. You have ways to finance your
                        startup
                    </p>
                </div>
                <!-- Section Content Block -->
            </div>
            <!-- Section Content Wrapper -->

            <!-- Pricing Area -->
            <div>
                <!-- Pricing Button Block -->
                <div class=\"my-[50px] flex flex-row items-center justify-center gap-6\">
                    <span class=\"font-bold\">Per Month</span>

                    <!-- Toggle Button -->
                    <label for=\"toggle\" class=\"flex cursor-pointer items-center\">
                        <!-- toggle -->
                        <span class=\"relative h-[35px] w-[70px] rounded-[35px] bg-[#121212]\">
                            <!-- hidden input -->
                            <input id=\"toggle\" type=\"checkbox\" class=\"hidden\" onclick=\"toggleSwitch()\" />
                            <!-- dot -->
                            <span class=\"toggle_dot absolute h-[35px] w-[35px] rounded-full bg-[#C1FF00] transition-all duration-300\"></span>
                        </span>
                    </label>
                    <!-- Toggle Button -->
                    <span class=\"font-bold\">Per Year</span>
                </div>
                <!-- Pricing Button Block -->

                <!-- Pricing Content Block -->
                <div class=\"mx-auto max-w-[1076px]\">
                    <div class=\"flex flex-col items-center justify-between gap-10 rounded-[10px] border border-ColorBlack p-8 sm:p-10 md:flex-row lg:px-[73px] lg:py-[50px]\">
                        <div class=\"w-full text-center md:w-1/2 md:text-left lg:max-w-[381px]\">
                            <div class=\"text-xl leading-[1.6] tracking-tighter text-[#121212]\">
                                For business
                            </div>
                            <div class=\"month\">
                                <span class=\"font-PublicSans text-[50px] font-bold leading-[1.4] text-[#121212] lg:text-[56px]\">\$30.00</span>/Per Month
                            </div>
                            <div class=\"annual hidden\">
                                <span class=\"font-PublicSans text-[50px] font-bold leading-[1.4] text-[#121212] lg:text-[56px]\">\$300.00</span>/Per Year
                            </div>
                            <p>
                                One way to determine how much money you need is to do a
                                break-even analysis.
                            </p>
                        </div>
                        <div class=\"w-full md:w-1/2\">
                            <div class=\"mb-6 text-center font-semibold text-[#121212] md:text-left\">
                                That includes:
                            </div>
                            <!-- Pricing Info List -->
                            <ul class=\"flex flex-col gap-3\">
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Live chat and email
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Fully managed program
                                    <!-- Pricing Info Item -->
                                    <!-- Pricing Info Item -->
                                </li>

                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Experience team members
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Step by step working process
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Re-evaluation project management
                                </li>
                                <!-- Pricing Info Item -->
                            </ul>
                            <!-- Pricing Info List -->

                            <button class=\"btn mt-[30px] block rounded-[3px] border-none bg-[#C1FF00] py-[18px] text-ColorBlack hover:bg-[#a6ff00] xl:mt-[50px]\">
                                Choose Plan
                            </button>
                        </div>
                    </div>
                </div>
                <!-- Pricing Content Block -->
            </div>
            <!-- Pricing Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Pricing Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 156
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 157
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/pricing2.html.twig", 157)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/pricing2.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  269 => 157,  262 => 156,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

<!-- Pricing Section Start -->
<section class=\"section-pricing\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Section Content Wrapper -->
            <div class=\"jos\">
                <!-- Section Content Block -->
                <div class=\"mx-auto max-w-[636px]\">
                    <div class=\"mb-5\">
                        <h2 class=\"text-center font-bold leading-[1.14] text-[#121212]\">
                            Our pricing plans are designed for your favor
                        </h2>
                    </div>
                    <p class=\"text-center\">
                        Starting any business has a cost, so you need to determine
                        how you will cover the costs. You have ways to finance your
                        startup
                    </p>
                </div>
                <!-- Section Content Block -->
            </div>
            <!-- Section Content Wrapper -->

            <!-- Pricing Area -->
            <div>
                <!-- Pricing Button Block -->
                <div class=\"my-[50px] flex flex-row items-center justify-center gap-6\">
                    <span class=\"font-bold\">Per Month</span>

                    <!-- Toggle Button -->
                    <label for=\"toggle\" class=\"flex cursor-pointer items-center\">
                        <!-- toggle -->
                        <span class=\"relative h-[35px] w-[70px] rounded-[35px] bg-[#121212]\">
                            <!-- hidden input -->
                            <input id=\"toggle\" type=\"checkbox\" class=\"hidden\" onclick=\"toggleSwitch()\" />
                            <!-- dot -->
                            <span class=\"toggle_dot absolute h-[35px] w-[35px] rounded-full bg-[#C1FF00] transition-all duration-300\"></span>
                        </span>
                    </label>
                    <!-- Toggle Button -->
                    <span class=\"font-bold\">Per Year</span>
                </div>
                <!-- Pricing Button Block -->

                <!-- Pricing Content Block -->
                <div class=\"mx-auto max-w-[1076px]\">
                    <div class=\"flex flex-col items-center justify-between gap-10 rounded-[10px] border border-ColorBlack p-8 sm:p-10 md:flex-row lg:px-[73px] lg:py-[50px]\">
                        <div class=\"w-full text-center md:w-1/2 md:text-left lg:max-w-[381px]\">
                            <div class=\"text-xl leading-[1.6] tracking-tighter text-[#121212]\">
                                For business
                            </div>
                            <div class=\"month\">
                                <span class=\"font-PublicSans text-[50px] font-bold leading-[1.4] text-[#121212] lg:text-[56px]\">\$30.00</span>/Per Month
                            </div>
                            <div class=\"annual hidden\">
                                <span class=\"font-PublicSans text-[50px] font-bold leading-[1.4] text-[#121212] lg:text-[56px]\">\$300.00</span>/Per Year
                            </div>
                            <p>
                                One way to determine how much money you need is to do a
                                break-even analysis.
                            </p>
                        </div>
                        <div class=\"w-full md:w-1/2\">
                            <div class=\"mb-6 text-center font-semibold text-[#121212] md:text-left\">
                                That includes:
                            </div>
                            <!-- Pricing Info List -->
                            <ul class=\"flex flex-col gap-3\">
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Live chat and email
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Fully managed program
                                    <!-- Pricing Info Item -->
                                    <!-- Pricing Info Item -->
                                </li>

                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Experience team members
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Step by step working process
                                </li>
                                <!-- Pricing Info Item -->
                                <!-- Pricing Info Item -->
                                <li class=\"font-semibold\">
                                    <span class=\"text-[#9B51E0]\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Re-evaluation project management
                                </li>
                                <!-- Pricing Info Item -->
                            </ul>
                            <!-- Pricing Info List -->

                            <button class=\"btn mt-[30px] block rounded-[3px] border-none bg-[#C1FF00] py-[18px] text-ColorBlack hover:bg-[#a6ff00] xl:mt-[50px]\">
                                Choose Plan
                            </button>
                        </div>
                    </div>
                </div>
                <!-- Pricing Content Block -->
            </div>
            <!-- Pricing Area -->
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</section>
<!-- Pricing Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/pricing2.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\pricing2.html.twig");
    }
}
