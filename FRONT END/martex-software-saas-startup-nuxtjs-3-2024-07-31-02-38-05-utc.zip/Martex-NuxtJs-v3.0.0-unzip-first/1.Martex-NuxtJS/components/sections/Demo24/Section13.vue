<template>
    <section class="pt-100 ct-01 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- CONTENT BOX #1 -->
                        <div class="cbox-4">
                            <!-- Icon & Title -->
                            <div class="box-title">
                                <span class="flaticon-click color--theme"></span>
                                <h5 class="s-24">Quick Integration</h5>
                            </div>
                            <!-- Text -->
                            <div class="cbox-4-txt">
                                <p>Quaerat sodales sapien blandit purus primis purus ipsum cubilia laoreet augue luctus and magna dolor luctus egestas an ipsum sapien primis vitae volute and magna turpis</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #1 -->
                        <!-- CONTENT BOX #2 -->
                        <div class="cbox-4">
                            <!-- Icon & Title -->
                            <div class="box-title">
                                <span class="flaticon-workflow-2 color--theme"></span>
                                <h5 class="s-24">Extensions & Addons</h5>
                            </div>
                            <!-- Text -->
                            <div class="cbox-4-txt">
                                <p>Quaerat sodales sapien blandit purus primis purus ipsum cubilia laoreet augue luctus and magna dolor luctus egestas an ipsum sapien primis vitae volute and magna turpis</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #2 -->
                        <!-- CONTENT BOX #3 -->
                        <div class="cbox-4">
                            <!-- Icon & Title -->
                            <div class="box-title">
                                <span class="flaticon-shield-1 color--theme"></span>
                                <h5 class="s-24">Advanced Security</h5>
                            </div>
                            <!-- Text -->
                            <div class="cbox-4-txt">
                                <p class="mb-0">Quaerat sodales sapien blandit purus primis purus ipsum cubilia laoreet augue luctus and magna dolor luctus egestas an ipsum sapien primis vitae volute and magna turpis</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #3 -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="img-block right-column wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/img-06.png" alt="content-image" />
                    </div>
                </div>
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
