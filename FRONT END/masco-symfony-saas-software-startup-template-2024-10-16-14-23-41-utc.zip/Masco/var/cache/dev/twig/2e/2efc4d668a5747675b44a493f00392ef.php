<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/layout/layout3.html.twig */
class __TwigTemplate_7fe06e1db34c70a13a3844724f9e2a08 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'content' => [$this, 'block_content'],
            'footerSection' => [$this, 'block_footerSection'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/layout/layout3.html.twig"));

        // line 1
        yield "<!doctype html>
<html lang=\"en\">

";
        // line 4
        yield from         $this->loadTemplate("partials/head.html.twig", "partials/layout/layout3.html.twig", 4)->unwrap()->yield($context);
        // line 5
        yield "
<body>
    <div class=\"page-wrapper relative z-[1] ";
        // line 7
        ((array_key_exists("bgColor", $context)) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["bgColor"]) || array_key_exists("bgColor", $context) ? $context["bgColor"] : (function () { throw new RuntimeError('Variable "bgColor" does not exist.', 7, $this->source); })()), "html", null, true)) : (yield "bg-white"));
        yield "\">
        <!-- Header Start -->
        <header class=\"site-header site-header--sticky mobile-sticky-enable is--bg-dark is--white py-3\" id=\"sticky-menu\">
            <div class=\"container-default\">
                <div class=\"flex items-center justify-between gap-x-8\">
                    <!-- Header Logo -->
                    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"\">
                        ";
        // line 14
        yield from $this->unwrap()->yieldBlock('headerLogo', $context, $blocks);
        // line 16
        yield " 
                    </a>
                    <!-- Header Logo -->

                    <!-- Header Navigation -->
                    <div class=\"menu-block-wrapper\">
                        <div class=\"menu-overlay\"></div>
                        <nav class=\"menu-block\" id=\"append-menu-header\">
                            <div class=\"mobile-menu-head\">
                                <div class=\"go-back\">
                                    <i class=\"fa-solid fa-angle-left\"></i>
                                </div>
                                <div class=\"current-menu-title\"></div>
                                <div class=\"mobile-menu-close\">&times;</div>
                            </div>
                            <ul class=\"site-menu-main\">
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"";
        // line 33
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"nav-link-item drop-trigger\">Home</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-features\" class=\"nav-link-item drop-trigger\">Features</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-about\" class=\"nav-link-item drop-trigger\">About</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-service\" class=\"nav-link-item drop-trigger\">Services</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-pricing\" class=\"nav-link-item drop-trigger\">Pricing</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-testimonial\" class=\"nav-link-item drop-trigger\">Testimonial</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Header Navigation -->

                    <!-- Header User Event -->
                    ";
        // line 56
        yield from $this->unwrap()->yieldBlock('headButtons', $context, $blocks);
        // line 58
        yield " 
                    <!-- Header User Event -->
                </div>
            </div>
        </header>
        <!-- Header End -->

        <main class=\"main-wrapper relative overflow-hidden\">
            ";
        // line 66
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 68
        yield " 
        </main>

        ";
        // line 71
        yield from $this->unwrap()->yieldBlock('footerSection', $context, $blocks);
        // line 73
        yield " 

        ";
        // line 75
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 77
        yield " 
        

    </div>

    ";
        // line 82
        yield from         $this->loadTemplate("partials/scripts.html.twig", "partials/layout/layout3.html.twig", 82)->unwrap()->yield($context);
        // line 83
        yield "
</body>

</html>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 14
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 15
        yield "
                        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 56
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 57
        yield "
                    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 66
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 67
        yield "
            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 71
    public function block_footerSection($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footerSection"));

        // line 72
        yield "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 75
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 76
        yield "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "partials/layout/layout3.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  235 => 76,  228 => 75,  219 => 72,  212 => 71,  203 => 67,  196 => 66,  187 => 57,  180 => 56,  171 => 15,  164 => 14,  153 => 83,  151 => 82,  144 => 77,  142 => 75,  138 => 73,  136 => 71,  131 => 68,  129 => 66,  119 => 58,  117 => 56,  91 => 33,  72 => 16,  70 => 14,  66 => 13,  57 => 7,  53 => 5,  51 => 4,  46 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!doctype html>
<html lang=\"en\">

{% include 'partials/head.html.twig' %}

<body>
    <div class=\"page-wrapper relative z-[1] {{ bgColor is defined ? bgColor : 'bg-white' }}\">
        <!-- Header Start -->
        <header class=\"site-header site-header--sticky mobile-sticky-enable is--bg-dark is--white py-3\" id=\"sticky-menu\">
            <div class=\"container-default\">
                <div class=\"flex items-center justify-between gap-x-8\">
                    <!-- Header Logo -->
                    <a href=\"{{ path('home') }}\" class=\"\">
                        {% block headerLogo %}

                        {% endblock %} 
                    </a>
                    <!-- Header Logo -->

                    <!-- Header Navigation -->
                    <div class=\"menu-block-wrapper\">
                        <div class=\"menu-overlay\"></div>
                        <nav class=\"menu-block\" id=\"append-menu-header\">
                            <div class=\"mobile-menu-head\">
                                <div class=\"go-back\">
                                    <i class=\"fa-solid fa-angle-left\"></i>
                                </div>
                                <div class=\"current-menu-title\"></div>
                                <div class=\"mobile-menu-close\">&times;</div>
                            </div>
                            <ul class=\"site-menu-main\">
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"{{ path('home') }}\" class=\"nav-link-item drop-trigger\">Home</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-features\" class=\"nav-link-item drop-trigger\">Features</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-about\" class=\"nav-link-item drop-trigger\">About</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-service\" class=\"nav-link-item drop-trigger\">Services</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-pricing\" class=\"nav-link-item drop-trigger\">Pricing</a>
                                </li>
                                <li class=\"nav-item nav-link-item--white nav-item-has-children\">
                                    <a href=\"#section-testimonial\" class=\"nav-link-item drop-trigger\">Testimonial</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Header Navigation -->

                    <!-- Header User Event -->
                    {% block headButtons %}

                    {% endblock %} 
                    <!-- Header User Event -->
                </div>
            </div>
        </header>
        <!-- Header End -->

        <main class=\"main-wrapper relative overflow-hidden\">
            {% block content %}

            {% endblock %} 
        </main>

        {% block footerSection %}

        {% endblock %} 

        {% block footer %}

        {% endblock %} 
        

    </div>

    {% include 'partials/scripts.html.twig' %}

</body>

</html>", "partials/layout/layout3.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\partials\\layout\\layout3.html.twig");
    }
}
