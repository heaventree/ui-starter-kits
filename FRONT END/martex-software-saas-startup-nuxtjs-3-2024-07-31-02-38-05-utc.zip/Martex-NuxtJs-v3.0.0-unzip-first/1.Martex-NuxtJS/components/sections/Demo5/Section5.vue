<template>
    <section id="lnk-1" class="pt-100 ws-wrapper content-section">
        <div class="container">
            <div class="bc-5-wrapper bg--02 hidd bg--scroll r-16">
                <div class="section-overlay">
                    <!-- SECTION TITLE -->
                    <div class="row justify-content-center">
                        <div class="col-md-11 col-lg-9">
                            <div class="section-title wow fadeInUp mb-60">
                                <!-- Title -->
                                <h2 class="s-50 w-700">Build a customer-centric marketing strategy</h2>
                                <!-- Text -->
                                <p class="p-xl">Aliquam a augue suscipit luctus neque purus ipsum neque diam dolor primis libero tempus, blandit and cursus varius and magnis sodales</p>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End section overlay -->
            </div>
            <!-- End content wrapper -->
        </div>
        <!-- End container -->
    </section>
</template>
