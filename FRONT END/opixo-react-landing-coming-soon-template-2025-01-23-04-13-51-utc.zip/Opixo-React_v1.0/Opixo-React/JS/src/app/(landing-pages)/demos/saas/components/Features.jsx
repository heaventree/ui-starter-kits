import saasImg2 from '@/assets/images/landing/saas/saas2.png';
import saasImg from '@/assets/images/landing/saas/app.png';
const Features = () => {
  return <section id="features" className="bg-slate-50 bg-[url(../images/landing/saas/hero-3-bg.png)] bg-cover bg-left bg-no-repeat">
      <div className="py-24">
        <div className="container">
          <div className="mb-14 flex items-center justify-center">
            <div className="max-w-2xl text-center">
              <h5 className="mb-2 text-lg font-medium capitalize text-gray-800">
                Our <span className="font-semibold text-primary">Features</span>
              </h5>
              <h2 className="mb-1 text-3xl/snug font-bold text-gray-800">Simply Beautiful Crafted Pages For Every Usecase</h2>
              <p className="text-base text-gray-600">Nemo enim ipsam voluptatem that quia voluptas aut fugit </p>
            </div>
          </div>
          <div className="mt-14 grid grid-cols-1 items-center gap-6 md:grid-cols-2">
            <div>
              <img src={saasImg2} width={596} height={398} className="max-h-full max-w-full rounded-md" alt="saas" />
            </div>
            <div className="my-auto md:mx-auto">
              <h2 className="mb-2 text-2xl font-semibold text-gray-800 lg:text-3xl">Saas Application</h2>
              <p className="text-base text-gray-600">
                A simple and clean landing page designed for <br /> saas basad application
              </p>
              <div className="mt-10 flex flex-col gap-y-4">
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          {' '}
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            {' '}
                            <rect id="bound" x={0} y={0} width={24} height={24} />{' '}
                            <path d="M7,14 C7,16.7614237 9.23857625,19 12,19 C14.7614237,19 17,16.7614237 17,14 C17,12.3742163 15.3702913,9.86852817 12,6.69922982 C8.62970872,9.86852817 7,12.3742163 7,14 Z M12,21 C8.13400675,21 5,17.8659932 5,14 C5,11.4226712 7.33333333,8.08933783 12,4 C16.6666667,8.08933783 19,11.4226712 19,14 C19,17.8659932 15.8659932,21 12,21 Z" id="Oval-2" fill="currentColor" />{' '}
                            <path d="M12,4 C16.6666667,8.08933783 19,11.4226712 19,14 C19,17.8659932 15.8659932,21 12,21 L12,4 Z" id="Combined-Shape" fill="currentColor" />{' '}
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Clean Design</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          {' '}
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            {' '}
                            <rect id="bound" x={0} y={0} width={24} height={24} />{' '}
                            <polygon id="Path-48" fill="currentColor" opacity="0.3" points="5 3 19 3 23 8 1 8" />
                            <polygon id="Path-48-Copy" fill="currentColor" points="23 8 12 20 1 8">
                              {' '}
                            </polygon>
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Most Of Common Section Covered</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          {' '}
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            <polygon id="Shape" points="0 0 24 0 24 24 0 24" />
                            <path d="M4.85714286,1 L11.7364114,1 C12.0910962,1 12.4343066,1.12568431 12.7051108,1.35473959 L17.4686994,5.3839416 C17.8056532,5.66894833 18,6.08787823 18,6.52920201 L18,19.0833333 C18,20.8738751 17.9795521,21 16.1428571,21 L4.85714286,21 C3.02044787,21 3,20.8738751 3,19.0833333 L3,2.91666667 C3,1.12612489 3.02044787,1 4.85714286,1 Z M8,12 C7.44771525,12 7,12.4477153 7,13 C7,13.5522847 7.44771525,14 8,14 L15,14 C15.5522847,14 16,13.5522847 16,13 C16,12.4477153 15.5522847,12 15,12 L8,12 Z M8,16 C7.44771525,16 7,16.4477153 7,17 C7,17.5522847 7.44771525,18 8,18 L11,18 C11.5522847,18 12,17.5522847 12,17 C12,16.4477153 11.5522847,16 11,16 L8,16 Z" id="Combined-Shape-Copy" fill="currentColor" opacity="0.3" />
                            <path d="M6.85714286,3 L14.7364114,3 C15.0910962,3 15.4343066,3.12568431 15.7051108,3.35473959 L20.4686994,7.3839416 C20.8056532,7.66894833 21,8.08787823 21,8.52920201 L21,21.0833333 C21,22.8738751 20.9795521,23 19.1428571,23 L6.85714286,23 C5.02044787,23 5,22.8738751 5,21.0833333 L5,4.91666667 C5,3.12612489 5.02044787,3 6.85714286,3 Z M8,12 C7.44771525,12 7,12.4477153 7,13 C7,13.5522847 7.44771525,14 8,14 L15,14 C15.5522847,14 16,13.5522847 16,13 C16,12.4477153 15.5522847,12 15,12 L8,12 Z M8,16 C7.44771525,16 7,16.4477153 7,17 C7,17.5522847 7.44771525,18 8,18 L11,18 C11.5522847,18 12,17.5522847 12,17 C12,16.4477153 11.5522847,16 11,16 L8,16 Z" id="Combined-Shape" fill="currentColor" />
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Secondary Page Include</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          {' '}
                          <g id="Stockholm-icons-/-Layout-/-Layout-top-panel-2" stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            {' '}
                            <rect id="bound" x={0} y={0} width={24} height={24} />{' '}
                            <path d="M3,4 L20,4 C20.5522847,4 21,4.44771525 21,5 L21,7 C21,7.55228475 20.5522847,8 20,8 L3,8 C2.44771525,8 2,7.55228475 2,7 L2,5 C2,4.44771525 2.44771525,4 3,4 Z M10,10 L20,10 C20.5522847,10 21,10.4477153 21,11 L21,19 C21,19.5522847 20.5522847,20 20,20 L10,20 C9.44771525,20 9,19.5522847 9,19 L9,11 C9,10.4477153 9.44771525,10 10,10 Z" id="Combined-Shape" fill="currentColor" />{' '}
                            <rect id="Rectangle-7-Copy-2" fill="currentColor" opacity="0.3" x={2} y={10} width={5} height={10} rx={1} />{' '}
                          </g>{' '}
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">No Additional Cost</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div className="pb-24">
        <div className="container">
          <div className="grid grid-cols-1 items-center gap-6 md:grid-cols-2">
            <div className="my-auto md:mx-auto">
              <h2 className="mb-2 text-2xl font-semibold text-gray-800 lg:text-3xl">Mobile Application</h2>
              <p className="text-base font-medium text-gray-600">
                showcase your awesome mobile application <br />
                with fascination impression
              </p>
              <div className="mt-10 flex flex-col gap-y-4">
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            <rect id="bound" x={0} y={0} width={24} height={24} />
                            <path d="M7,14 C7,16.7614237 9.23857625,19 12,19 C14.7614237,19 17,16.7614237 17,14 C17,12.3742163 15.3702913,9.86852817 12,6.69922982 C8.62970872,9.86852817 7,12.3742163 7,14 Z M12,21 C8.13400675,21 5,17.8659932 5,14 C5,11.4226712 7.33333333,8.08933783 12,4 C16.6666667,8.08933783 19,11.4226712 19,14 C19,17.8659932 15.8659932,21 12,21 Z" id="Oval-2" fill="currentColor" />
                            <path d="M12,4 C16.6666667,8.08933783 19,11.4226712 19,14 C19,17.8659932 15.8659932,21 12,21 L12,4 Z" id="Combined-Shape" fill="currentColor" />
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Clean Design</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            <rect id="bound" x={0} y={0} width={24} height={24} />
                            <polygon id="Path-48" fill="currentColor" opacity="0.3" points="5 3 19 3 23 8 1 8" />
                            <polygon id="Path-48-Copy" fill="currentColor" points="23 8 12 20 1 8"></polygon>
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Most Of Common Section Covered</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          <g stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            <polygon id="Shape" points="0 0 24 0 24 24 0 24" />
                            <path d="M4.85714286,1 L11.7364114,1 C12.0910962,1 12.4343066,1.12568431 12.7051108,1.35473959 L17.4686994,5.3839416 C17.8056532,5.66894833 18,6.08787823 18,6.52920201 L18,19.0833333 C18,20.8738751 17.9795521,21 16.1428571,21 L4.85714286,21 C3.02044787,21 3,20.8738751 3,19.0833333 L3,2.91666667 C3,1.12612489 3.02044787,1 4.85714286,1 Z M8,12 C7.44771525,12 7,12.4477153 7,13 C7,13.5522847 7.44771525,14 8,14 L15,14 C15.5522847,14 16,13.5522847 16,13 C16,12.4477153 15.5522847,12 15,12 L8,12 Z M8,16 C7.44771525,16 7,16.4477153 7,17 C7,17.5522847 7.44771525,18 8,18 L11,18 C11.5522847,18 12,17.5522847 12,17 C12,16.4477153 11.5522847,16 11,16 L8,16 Z" id="Combined-Shape-Copy" fill="currentColor" opacity="0.3" />
                            <path d="M6.85714286,3 L14.7364114,3 C15.0910962,3 15.4343066,3.12568431 15.7051108,3.35473959 L20.4686994,7.3839416 C20.8056532,7.66894833 21,8.08787823 21,8.52920201 L21,21.0833333 C21,22.8738751 20.9795521,23 19.1428571,23 L6.85714286,23 C5.02044787,23 5,22.8738751 5,21.0833333 L5,4.91666667 C5,3.12612489 5.02044787,3 6.85714286,3 Z M8,12 C7.44771525,12 7,12.4477153 7,13 C7,13.5522847 7.44771525,14 8,14 L15,14 C15.5522847,14 16,13.5522847 16,13 C16,12.4477153 15.5522847,12 15,12 L8,12 Z M8,16 C7.44771525,16 7,16.4477153 7,17 C7,17.5522847 7.44771525,18 8,18 L11,18 C11.5522847,18 12,17.5522847 12,17 C12,16.4477153 11.5522847,16 11,16 L8,16 Z" id="Combined-Shape" fill="currentColor" />
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">Secondary Page Include</p>
                  </div>
                </div>
                <div className="flex items-center gap-5">
                  <div>
                    <span className="relative z-0 inline-flex h-8 w-8 bg-primary/10" style={{
                    borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
                  }}>
                      <div className="absolute bottom-0 left-4 right-0 top-4 -z-20">
                        <svg className="h-5 w-5 text-primary" viewBox="0 0 24 24" version="1.1" xmlns="http://www.w3.org/2000/svg" xmlnsXlink="http://www.w3.org/1999/xlink">
                          <g id="Stockholm-icons-/-Layout-/-Layout-top-panel-2" stroke="none" strokeWidth={1} fill="none" fillRule="evenodd">
                            <rect id="bound" x={0} y={0} width={24} height={24} />
                            <path d="M3,4 L20,4 C20.5522847,4 21,4.44771525 21,5 L21,7 C21,7.55228475 20.5522847,8 20,8 L3,8 C2.44771525,8 2,7.55228475 2,7 L2,5 C2,4.44771525 2.44771525,4 3,4 Z M10,10 L20,10 C20.5522847,10 21,10.4477153 21,11 L21,19 C21,19.5522847 20.5522847,20 20,20 L10,20 C9.44771525,20 9,19.5522847 9,19 L9,11 C9,10.4477153 9.44771525,10 10,10 Z" id="Combined-Shape" fill="currentColor" />
                            <rect id="Rectangle-7-Copy-2" fill="currentColor" opacity="0.3" x={2} y={10} width={5} height={10} rx={1} />
                          </g>
                        </svg>
                      </div>
                    </span>
                  </div>
                  <div>
                    <p className="text-lg font-medium text-gray-600">No Additional Cost</p>
                  </div>
                </div>
              </div>
            </div>
            <div>
              <img src={saasImg} height={650} width={371} className="mx-auto max-h-[650px] max-w-full rounded-md" alt="saas" />
            </div>
          </div>
        </div>
      </div>
    </section>;
};
export default Features;