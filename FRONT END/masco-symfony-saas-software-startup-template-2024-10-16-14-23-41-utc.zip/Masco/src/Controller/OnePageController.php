<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\Routing\Attribute\Route;

class OnePageController extends AbstractController
{
    #[Route('/onepage/index', name:'indexOnePage1')]
    public function index(): Response
    {
        return $this->render('/onePage/indexOnePage1.html.twig');
    }
    #[Route('/onepage/index2', name:'indexOnePage2')]
    public function index2(): Response
    {
        return $this->render('/onePage/indexOnePage2.html.twig');
    }

    #[Route('/onepage/index3', name:'indexOnePage3')]
    public function index3(): Response
    {
        return $this->render('/onePage/indexOnePage3.html.twig');
    }

    #[Route('/onepage/index4', name:'indexOnePage4')]
    public function index4(): Response
    {
        return $this->render('/onePage/indexOnePage4.html.twig');
    }

    #[Route('/onepage/index5', name:'indexOnePage5')]
        public function index5(): Response
    {
        return $this->render('/onePage/indexOnePage5.html.twig');
    }

    #[Route('/onepage/index6', name:'indexOnePage6')]
        public function index6(): Response
    {
        return $this->render('/onePage/indexOnePage6.html.twig');
    }

    #[Route('/onepage/index7', name:'indexOnePage7')]
        public function index7(): Response
    {
        return $this->render('/onePage/indexOnePage7.html.twig');
    }

    #[Route('/onepage/index8', name:'indexOnePage8')]
        public function index8(): Response
    {
        return $this->render('/onePage/indexOnePage8.html.twig');
    }

    #[Route('/onepage/index9', name:'indexOnePage9')]
    public function index9(): Response
    {
        return $this->render('/onePage/indexOnePage9.html.twig');
    }

    #[Route('/onepage/index10', name:'indexOnePage10')]
    public function index10(): Response
    {
        return $this->render('/onePage/indexOnePage10.html.twig',[
            'bgColor'=>'bg-ColorEggSour',
        ]);
    }

    #[Route('/onepage/index11', name:'indexOnePage11')]
    public function index11(): Response
    {
        return $this->render('/onePage/indexOnePage11.html.twig');
    }

    #[Route('/onepage/index12', name:'indexOnePage12')]
    public function index12(): Response
    {
        return $this->render('/onePage/indexOnePage12.html.twig',[
            'bgColor'=>'bg-[#F6F9F0]',
        ]);
    }

    #[Route('/onepage/index13', name:'indexOnePage13')]
    public function index13(): Response
    {
        return $this->render('/onePage/indexOnePage13.html.twig',[
            'bgColor'=>'bg-[#F6F9F0]',
        ]);
    }

    #[Route('/onepage/index14', name:'indexOnePage14')]
    public function index14(): Response
    {
        return $this->render('/onePage/indexOnePage14.html.twig');
    }

    #[Route('/onepage/index15', name:'indexOnePage15')]
    public function index15(): Response
    {
        return $this->render('/onePage/indexOnePage15.html.twig');
    }
}