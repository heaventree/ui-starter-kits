<template>
    <section id="projects-1" class="py-100 projects-section">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-10 col-lg-9">
                    <div class="section-title mb-80">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Great Design That Works!</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- PROJECTS WRAPPER -->
            <div class="projects-wrapper rel shape--02 shape--white-300">
                <div class="row align-items-center row-cols-1 row-cols-md-2">
                    <!-- PROJECT #1 -->
                    <div class="col">
                        <div id="pt-1-1" class="project-details">
                            <!-- Title -->
                            <h5 class="s-22 w-700">Vintage Poster</h5>
                            <!-- Image -->
                            <div class="project-preview r-10">
                                <!-- Project Preview -->
                                <div class="hover-overlay">
                                    <img class="img-fluid" src="/assets/images/projects/project-05.jpg" alt="project-preview" />
                                    <div class="item-overlay"></div>
                                </div>
                                <!-- Project Link -->
                                <div class="project-link ico-35 color--white">
                                    <NuxtLink to="/project-details" title=""><span class="flaticon-visibility"></span></NuxtLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PROJECT #1 -->
                    <!-- PROJECT #2 -->
                    <div class="col">
                        <div id="pt-1-2" class="project-details">
                            <!-- Title -->
                            <h5 class="s-22 w-700">Glued Poster</h5>
                            <!-- Image -->
                            <div class="project-preview r-10">
                                <!-- Project Preview -->
                                <div class="hover-overlay">
                                    <img class="img-fluid" src="/assets/images/projects/project-02.jpg" alt="project-preview" />
                                    <div class="item-overlay"></div>
                                </div>
                                <!-- Project Link -->
                                <div class="project-link ico-35 color--white">
                                    <NuxtLink to="/project-details" title=""><span class="flaticon-visibility"></span></NuxtLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PROJECT #2 -->
                    <!-- PROJECT #3 -->
                    <div class="col">
                        <div id="pt-1-3" class="project-details">
                            <!-- Title -->
                            <h5 class="s-22 w-700">Double Color</h5>
                            <!-- Image -->
                            <div class="project-preview r-10">
                                <!-- Project Preview -->
                                <div class="hover-overlay">
                                    <img class="img-fluid" src="/assets/images/projects/project-03.jpg" alt="project-preview" />
                                    <div class="item-overlay"></div>
                                </div>
                                <!-- Project Link -->
                                <div class="project-link ico-35 color--white">
                                    <NuxtLink to="/project-details" title=""><span class="flaticon-visibility"></span></NuxtLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PROJECT #3 -->
                    <!-- PROJECT #4 -->
                    <div class="col">
                        <div id="pt-1-4" class="project-details">
                            <!-- Title -->
                            <h5 class="s-22 w-700">Reativity</h5>
                            <!-- Image -->
                            <div class="project-preview r-10">
                                <!-- Project Preview -->
                                <div class="hover-overlay">
                                    <img class="img-fluid" src="/assets/images/projects/project-04.jpg" alt="project-preview" />
                                    <div class="item-overlay"></div>
                                </div>
                                <!-- Project Link -->
                                <div class="project-link ico-35 color--white">
                                    <NuxtLink to="/project-details" title=""><span class="flaticon-visibility"></span></NuxtLink>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END PROJECT #4 -->
                </div>
            </div>
            <!-- END PROJECTS WRAPPER -->
            <!-- MORE PROJECTS BUTTON -->
            <div class="row">
                <div class="col">
                    <div class="more-projects wow fadeInUp">
                        <NuxtLink to="/projects" class="btn btn--theme hover--tra-black">See more projects</NuxtLink>
                    </div>
                </div>
            </div>
        </div>
        <!-- End container -->
    </section>
</template>
