<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/about.html.twig */
class __TwigTemplate_9842f1f1ac99797519a1c64e2d4be982 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'headButtons' => [$this, 'block_headButtons'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/about.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/about.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 4
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 5
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 8
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 9
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/about.html.twig", 9)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 12
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 13
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"##\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
        <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 31
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 32
        yield "
";
        // line 34
        yield "<div class=\"section-about-gallery\">
    ";
        // line 36
        yield "    <div class=\"section-space\">
        ";
        // line 38
        yield "        <div class=\"container-default\">
            ";
        // line 40
        yield "            <div class=\"grid gap-x-6 gap-y-10 sm:grid-cols-3\">
                ";
        // line 42
        yield "                <div class=\"jos\" data-jos_animation=\"fade-up\" data-jos_delay=\"0\">
                    <img src=\"";
        // line 43
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/about-gallery-img-1.jpg"), "html", null, true);
        yield "\" alt=\"about-gallery-img-1\" width=\"416\" height=\"286\" class=\"rounded-lg\" />
                </div>
                ";
        // line 46
        yield "                ";
        // line 47
        yield "                <div class=\"jos sm:translate-y-10\" data-jos_animation=\"fade-down\" data-jos_delay=\"0.3\">
                    <img src=\"";
        // line 48
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/about-gallery-img-2.jpg"), "html", null, true);
        yield "\" alt=\"about-gallery-img-1\" width=\"416\" height=\"381\" class=\"rounded-lg\" />
                </div>
                ";
        // line 51
        yield "                ";
        // line 52
        yield "                <div class=\"jos\" data-jos_animation=\"fade-up\" data-jos_delay=\"0.6\">
                    <img src=\"";
        // line 53
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/about-gallery-img-3.jpg"), "html", null, true);
        yield "\" alt=\"about-gallery-img-1\" width=\"416\" height=\"286\" class=\"rounded-lg\" />
                </div>
                ";
        // line 56
        yield "            </div>
            ";
        // line 58
        yield "        </div>
        ";
        // line 60
        yield "    </div>
    ";
        // line 62
        yield "</div>
";
        // line 64
        yield "
";
        // line 66
        yield "<div class=\"section-brand\">
    <div class=\"jos\">
        ";
        // line 69
        yield "        <div class=\"pb-[60px] md:pb-20 lg:pb-[100px]\">
            ";
        // line 71
        yield "            <div class=\"container-default\">
                <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                    From start-ups to Fortune 500, we partner with brands of all
                    sizes
                </div>
                ";
        // line 77
        yield "                <div class=\"swiper brand-slider\">
                    ";
        // line 79
        yield "                    <div class=\"swiper-wrapper\">
                        ";
        // line 81
        yield "                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 82
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 85
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 88
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 91
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 94
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 97
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 100
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 103
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 106
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 109
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                    </div>
                </div>
                ";
        // line 114
        yield "            </div>
            ";
        // line 116
        yield "        </div>
        ";
        // line 118
        yield "    </div>
</div>
";
        // line 121
        yield "
";
        // line 123
        yield "<section class=\"section-about-hero\">
    <div class=\"relative z-10 overflow-hidden bg-[#FAF9F5]\">
        ";
        // line 126
        yield "        <div class=\"section-space\">
            ";
        // line 128
        yield "            <div class=\"container-custom has-container-custom\">
                ";
        // line 130
        yield "                <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-[60px] xl:gap-[100px] xxl:grid-cols-[1fr_minmax(0,_1.1fr)]\">
                    ";
        // line 132
        yield "                    <div class=\"jos order-2 lg:order-1\" data-jos_animation=\"fade-left\" data-jos_delay=\"0\">
                        <div class=\"relative flex items-center justify-center mx-auto lg:mx-0 max-w-full sm:max-w-[80%] md:max-w-[70%] lg:max-w-full\">
                            <img src=\"";
        // line 134
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/hero-img.jpg"), "html", null, true);
        yield "\" alt=\"hero image\" width=\"600\" height=\"579\" class=\"h-auto w-full\" />
                            <a data-fslightbox=\"gallery\" href=\"https://www.youtube.com/watch?v=3nQNiWdeH2Q\" class=\"group group absolute flex h-[100px] w-[100px] items-center justify-center rounded-[50%] bg-white text-ColorBlue\" aria-label=\"video-play\">
                                <span class=\"text-2xl transition-all duration-300 ease-linear group-hover:scale-110\"><i class=\"fa-solid fa-play\"></i></span>
                            </a>
                        </div>
                    </div>
                    ";
        // line 141
        yield "                    ";
        // line 142
        yield "                    <div class=\"jos order-1 lg:order-2\" data-jos_animation=\"fade-right\" data-jos_delay=\"0.3\">
                        ";
        // line 144
        yield "                        <div>
                            ";
        // line 146
        yield "                            <div class=\"mb-5\">
                                <h2>
                                    Our vision is to build brands and provide world-class
                                    experiences to our clients
                                </h2>
                            </div>
                            ";
        // line 153
        yield "                            <p>
                                SINCE 1998, we transform bold business ideas into
                                exceptional digital products. We ideate, design, and
                                develop data-driven digital products made to answer
                                business challenges.
                            </p>
                            ";
        // line 160
        yield "                            <div class=\"my-7 h-px w-full bg-ColorBlack opacity-10 xl:my-10 xxl:my-14\"></div>
                            ";
        // line 162
        yield "                            <div>
                                <blockquote class=\"mb-6 font-semibold italic text-ColorBlack/80\">
                                    “We love what we do & create partnerships with our
                                    clients to ensure their digital transformation is
                                    positioned for long-term success.”
                                </blockquote>
                                <div class=\"flex flex-col items-center gap-4 lg:flex-row\">
                                    <img src=\"";
        // line 169
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/about-hero-user-blockquote-img.jpg"), "html", null, true);
        yield "\" alt=\"about-hero-user-blockquote-img\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] rounded-[50%] lg:mx-0\" />
                                    <div>
                                        <span class=\"block font-semibold\">Karen Lynn</span>
                                        <span class=\"text-sm text-opacity-80\">CEO & Co-founder @ Company</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        ";
        // line 178
        yield "                    </div>
                    ";
        // line 180
        yield "                </div>
                ";
        // line 182
        yield "            </div>
            ";
        // line 184
        yield "        </div>
        ";
        // line 186
        yield "    </div>
</section>
";
        // line 189
        yield "
";
        // line 191
        yield "<section class=\"section-fact\">
    ";
        // line 193
        yield "    <div class=\"section-space\">
        ";
        // line 195
        yield "        <div class=\"container-custom has-container-custom\">
            ";
        // line 197
        yield "            <div class=\"grid gap-10 gap-x-12 lg:grid-cols-2 xl:grid-cols-[1fr_minmax(0,_0.7fr)] xxl:gap-x-[185px]\">
                ";
        // line 199
        yield "                <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"0\">
                    ";
        // line 201
        yield "                    <div>
                        ";
        // line 203
        yield "                        <div class=\"mb-5\">
                            <h2>
                                Our creative talent has been influencing branding around
                                the world for a long time
                            </h2>
                        </div>
                        ";
        // line 210
        yield "                        <p>
                            With more than a decade of experience. We are worry about
                            the details so you need don't have to. When you work with
                            our agency, you can be sure that your website meets every
                            standard.
                        </p>
                    </div>
                    ";
        // line 218
        yield "                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group mt-8 inline-block lg:mt-[50px]\"><span>Get in touch</span></a>
                </div>
                ";
        // line 221
        yield "                ";
        // line 222
        yield "                <div>
                    ";
        // line 224
        yield "                    <div class=\"grid items-center justify-center gap-6 sm:grid-cols-2 sm:gap-0.5 sm:bg-ColorOffWhite\">
                        ";
        // line 226
        yield "                        <div class=\"text-center sm:bg-white sm:pb-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"36\">36</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Satisfied clients</span>
                        </div>
                        ";
        // line 233
        yield "                        ";
        // line 234
        yield "                        <div class=\"text-center sm:bg-white sm:pb-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"80\">80</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Active Engagement</span>
                        </div>
                        ";
        // line 241
        yield "                        ";
        // line 242
        yield "                        <div class=\"text-center sm:bg-white sm:pt-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"54\">54</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Success projects</span>
                        </div>
                        ";
        // line 249
        yield "                        ";
        // line 250
        yield "                        <div class=\"text-center sm:bg-white sm:pt-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"36\">72</span>+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Awards winning</span>
                        </div>
                        ";
        // line 257
        yield "                    </div>
                    ";
        // line 259
        yield "                </div>
                ";
        // line 261
        yield "            </div>
            ";
        // line 263
        yield "        </div>
        ";
        // line 265
        yield "    </div>
    ";
        // line 267
        yield "</section>
";
        // line 269
        yield "
";
        // line 271
        yield "<section class=\"section-features\">
    <div class=\"bg-ColorOffWhite\">
        ";
        // line 274
        yield "        <div class=\"section-space\">
            ";
        // line 276
        yield "            <div class=\"container-default\">
                ";
        // line 278
        yield "                <div class=\"jos mb-[60px] xl:mb-20\">
                    ";
        // line 280
        yield "                    <div class=\"mx-auto max-w-[526px]\">
                        <h2 class=\"text-center\">
                            Our core values that drive everything we do
                        </h2>
                    </div>
                    ";
        // line 286
        yield "                </div>
                ";
        // line 288
        yield "
                ";
        // line 290
        yield "                <div class=\"grid gap-10 sm:grid-cols-2 xl:grid-cols-3 xl:gap-10 xxl:gap-x-20 xxl:gap-y-[60px]\">
                    ";
        // line 292
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 294
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-1.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-1\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Passionate about work
                                </div>
                                <p>
                                    Passion for work is a enthusiasm and excitement for
                                    what you do.
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 307
        yield "                    ";
        // line 308
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0.3\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 310
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-2.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-1\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Creative team members
                                </div>
                                <p>
                                    A creative team is to design and execute campaigns &
                                    encourage
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 323
        yield "                    ";
        // line 324
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0.6\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 326
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-3.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-3\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Innovation solutions
                                </div>
                                <p>
                                    using either completely concepts finding new ways of
                                    using existing
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 339
        yield "                    ";
        // line 340
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"0.9\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 342
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-4.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-4\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Qualitiful products
                                </div>
                                <p>
                                    Product quality refers to how well a product satisfies
                                    our customer
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 355
        yield "                    ";
        // line 356
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"1.2\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 358
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-5.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-5\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Customer satisfaction
                                </div>
                                <p>
                                    Happy customers are delighted because of the customer
                                    service
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 371
        yield "                    ";
        // line 372
        yield "                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"1.5\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"";
        // line 374
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-yellow-feature-6.svg"), "html", null, true);
        yield "\" alt=\"icon-yellow-feature-6\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Simplicity interface
                                </div>
                                <p>
                                    Simplicity is used loosely to refer to the need to
                                    minimize a process
                                </p>
                            </div>
                        </div>
                    </div>
                    ";
        // line 387
        yield "                </div>
                ";
        // line 389
        yield "            </div>
            ";
        // line 391
        yield "        </div>
        ";
        // line 393
        yield "    </div>
</section>
";
        // line 396
        yield "
";
        // line 398
        yield "<section class=\"section-portfolio\">
    <div class=\"relative z-10 overflow-hidden\">
        ";
        // line 401
        yield "        <div class=\"section-space\">
            ";
        // line 403
        yield "            <div class=\"container-default\">
                ";
        // line 405
        yield "                <div class=\"jos mb-[60px] flex flex-wrap items-end justify-between gap-8 xl:mb-20\">
                    ";
        // line 407
        yield "                    <div class=\"max-w-[550px]\">
                        <h2>We create world-class web design, & branding</h2>
                    </div>
                    ";
        // line 411
        yield "                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>See more works</span></a>
                </div>
                ";
        // line 414
        yield "
                ";
        // line 416
        yield "                <div class=\"grid gap-8 md:grid-cols-2 lg:gap-10 xl:gap-[60px]\">
                    ";
        // line 418
        yield "                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 421
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-img-1\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 lg:flex-nowrap xl:mb-7\">
                                    <a href=\"##\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue xl:text-2xl\">App — The power of communication</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <a href=\"##\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    ";
        // line 434
        yield "                    ";
        // line 435
        yield "                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 438
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-img-2\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 lg:flex-nowrap xl:mb-7\">
                                    <a href=\"##\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue xl:text-2xl\">Website — The future lifestyle platform.</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <a href=\"##\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    ";
        // line 451
        yield "                </div>
                ";
        // line 453
        yield "            </div>
            ";
        // line 455
        yield "        </div>
        ";
        // line 457
        yield "
        ";
        // line 459
        yield "        <div class=\"absolute right-0 top-0 -z-10\">
            <img src=\"";
        // line 460
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/portfolio-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"portfolio-1-shape-1\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
";
        // line 465
        yield "
";
        // line 467
        yield "<section class=\"section-team\">
    <div class=\"bg-ColorOffWhite\">
        ";
        // line 470
        yield "        <div class=\"section-space\">
            ";
        // line 472
        yield "            <div class=\"container-default\">
                ";
        // line 474
        yield "                <div class=\"jos mb-[60px] xl:mb-20\">
                    ";
        // line 476
        yield "                    <div class=\"mx-auto max-w-[526px]\">
                        <h2 class=\"text-center\">
                            Amazing team behind our creative products
                        </h2>
                    </div>
                    ";
        // line 482
        yield "                </div>
                ";
        // line 484
        yield "
                ";
        // line 486
        yield "                <div class=\"grid gap-x-6 gap-y-8 sm:grid-cols-2 lg:grid-cols-4\">
                    ";
        // line 488
        yield "                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"";
        // line 489
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/team-img-1.jpg"), "html", null, true);
        yield "\" alt=\"team-img-1\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Eleanor Pena</div>
                            <span class=\"block text-opacity-80\">CEO & Co-founder</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    ";
        // line 511
        yield "                    ";
        // line 512
        yield "                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"";
        // line 513
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/team-img-2.jpg"), "html", null, true);
        yield "\" alt=\"team-img-2\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">
                                Leslie Alexander
                            </div>
                            <span class=\"block text-opacity-80\">Product Manager</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    ";
        // line 537
        yield "                    ";
        // line 538
        yield "                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"";
        // line 539
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/team-img-3.jpg"), "html", null, true);
        yield "\" alt=\"team-img-3\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Jane Cooper</div>
                            <span class=\"block text-opacity-80\">Web Developer</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    ";
        // line 561
        yield "                    ";
        // line 562
        yield "                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"";
        // line 563
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/team-img-4.jpg"), "html", null, true);
        yield "\" alt=\"team-img-4\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Floyd Miles</div>
                            <span class=\"block text-opacity-80\">Marketing Expert</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    ";
        // line 585
        yield "                </div>
                ";
        // line 587
        yield "            </div>
            ";
        // line 589
        yield "        </div>
        ";
        // line 591
        yield "    </div>
</section>
";
        // line 594
        yield "
";
        // line 596
        yield "<section class=\"section-faq\">
    ";
        // line 598
        yield "    <div class=\"section-space\">
        ";
        // line 600
        yield "        <div class=\"container-default\">
            ";
        // line 602
        yield "            <div class=\"jos mb-[60px] xl:mb-20\">
                ";
        // line 604
        yield "                <div class=\"mx-auto max-w-[625px]\">
                    <h2 class=\"text-center\">
                        Frequently asked questions about our digital agency
                    </h2>
                </div>
                ";
        // line 610
        yield "            </div>
            ";
        // line 612
        yield "            ";
        // line 613
        yield "            <div class=\"jos\">
                ";
        // line 615
        yield "                <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                    ";
        // line 617
        yield "                    <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        ";
        // line 619
        yield "                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What is a digital agency?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        ";
        // line 629
        yield "                        ";
        // line 630
        yield "                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        ";
        // line 639
        yield "                    </li>
                    ";
        // line 641
        yield "                    ";
        // line 642
        yield "                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        ";
        // line 644
        yield "                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What services does a digital agency provide?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        ";
        // line 654
        yield "                        ";
        // line 655
        yield "                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        ";
        // line 664
        yield "                    </li>
                    ";
        // line 666
        yield "                    ";
        // line 667
        yield "                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        ";
        // line 669
        yield "                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. Hiring a digital agency vs hiring in-house: What is
                                the difference?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        ";
        // line 680
        yield "                        ";
        // line 681
        yield "                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        ";
        // line 690
        yield "                    </li>
                    ";
        // line 692
        yield "                    ";
        // line 693
        yield "                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        ";
        // line 695
        yield "                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What questions should you ask when interviewing a
                                digital agency?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        ";
        // line 706
        yield "                        ";
        // line 707
        yield "                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        ";
        // line 716
        yield "                    </li>
                    ";
        // line 718
        yield "                    ";
        // line 719
        yield "                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        ";
        // line 721
        yield "                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. How do digital agencies charge for their services?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        ";
        // line 731
        yield "                        ";
        // line 732
        yield "                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        ";
        // line 741
        yield "                    </li>
                    ";
        // line 743
        yield "                </ul>
                ";
        // line 745
        yield "
                <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                </div>
            </div>
            ";
        // line 751
        yield "        </div>
        ";
        // line 753
        yield "    </div>
    ";
        // line 755
        yield "</section>
";
        // line 757
        yield "
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 762
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 763
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/about.html.twig", 763)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/about.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  1124 => 763,  1117 => 762,  1108 => 757,  1105 => 755,  1102 => 753,  1099 => 751,  1092 => 745,  1089 => 743,  1086 => 741,  1076 => 732,  1074 => 731,  1063 => 721,  1060 => 719,  1058 => 718,  1055 => 716,  1045 => 707,  1043 => 706,  1031 => 695,  1028 => 693,  1026 => 692,  1023 => 690,  1013 => 681,  1011 => 680,  999 => 669,  996 => 667,  994 => 666,  991 => 664,  981 => 655,  979 => 654,  968 => 644,  965 => 642,  963 => 641,  960 => 639,  950 => 630,  948 => 629,  937 => 619,  934 => 617,  931 => 615,  928 => 613,  926 => 612,  923 => 610,  916 => 604,  913 => 602,  910 => 600,  907 => 598,  904 => 596,  901 => 594,  897 => 591,  894 => 589,  891 => 587,  888 => 585,  864 => 563,  861 => 562,  859 => 561,  835 => 539,  832 => 538,  830 => 537,  804 => 513,  801 => 512,  799 => 511,  775 => 489,  772 => 488,  769 => 486,  766 => 484,  763 => 482,  756 => 476,  753 => 474,  750 => 472,  747 => 470,  743 => 467,  740 => 465,  733 => 460,  730 => 459,  727 => 457,  724 => 455,  721 => 453,  718 => 451,  703 => 438,  698 => 435,  696 => 434,  681 => 421,  676 => 418,  673 => 416,  670 => 414,  666 => 411,  661 => 407,  658 => 405,  655 => 403,  652 => 401,  648 => 398,  645 => 396,  641 => 393,  638 => 391,  635 => 389,  632 => 387,  617 => 374,  613 => 372,  611 => 371,  596 => 358,  592 => 356,  590 => 355,  575 => 342,  571 => 340,  569 => 339,  554 => 326,  550 => 324,  548 => 323,  533 => 310,  529 => 308,  527 => 307,  512 => 294,  508 => 292,  505 => 290,  502 => 288,  499 => 286,  492 => 280,  489 => 278,  486 => 276,  483 => 274,  479 => 271,  476 => 269,  473 => 267,  470 => 265,  467 => 263,  464 => 261,  461 => 259,  458 => 257,  450 => 250,  448 => 249,  440 => 242,  438 => 241,  430 => 234,  428 => 233,  420 => 226,  417 => 224,  414 => 222,  412 => 221,  408 => 218,  399 => 210,  391 => 203,  388 => 201,  385 => 199,  382 => 197,  379 => 195,  376 => 193,  373 => 191,  370 => 189,  366 => 186,  363 => 184,  360 => 182,  357 => 180,  354 => 178,  343 => 169,  334 => 162,  331 => 160,  323 => 153,  315 => 146,  312 => 144,  309 => 142,  307 => 141,  298 => 134,  294 => 132,  291 => 130,  288 => 128,  285 => 126,  281 => 123,  278 => 121,  274 => 118,  271 => 116,  268 => 114,  261 => 109,  255 => 106,  249 => 103,  243 => 100,  237 => 97,  231 => 94,  225 => 91,  219 => 88,  213 => 85,  207 => 82,  204 => 81,  201 => 79,  198 => 77,  191 => 71,  188 => 69,  184 => 66,  181 => 64,  178 => 62,  175 => 60,  172 => 58,  169 => 56,  164 => 53,  161 => 52,  159 => 51,  154 => 48,  151 => 47,  149 => 46,  144 => 43,  141 => 42,  138 => 40,  135 => 38,  132 => 36,  129 => 34,  126 => 32,  119 => 31,  98 => 13,  91 => 12,  82 => 9,  75 => 8,  64 => 5,  57 => 4,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}


{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"##\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    {# Responsive Offcanvas Menu Button #}
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 



{% block content %}

{# About Gallery Section Start #}
<div class=\"section-about-gallery\">
    {# Section Spacer #}
    <div class=\"section-space\">
        {# Section Container #}
        <div class=\"container-default\">
            {# About Gallery Area #}
            <div class=\"grid gap-x-6 gap-y-10 sm:grid-cols-3\">
                {# Single Gallery Image #}
                <div class=\"jos\" data-jos_animation=\"fade-up\" data-jos_delay=\"0\">
                    <img src=\"{{ asset('assets/img/th-1/about-gallery-img-1.jpg') }}\" alt=\"about-gallery-img-1\" width=\"416\" height=\"286\" class=\"rounded-lg\" />
                </div>
                {# Single Gallery Image #}
                {# Single Gallery Image #}
                <div class=\"jos sm:translate-y-10\" data-jos_animation=\"fade-down\" data-jos_delay=\"0.3\">
                    <img src=\"{{ asset('assets/img/th-1/about-gallery-img-2.jpg') }}\" alt=\"about-gallery-img-1\" width=\"416\" height=\"381\" class=\"rounded-lg\" />
                </div>
                {# Single Gallery Image #}
                {# Single Gallery Image #}
                <div class=\"jos\" data-jos_animation=\"fade-up\" data-jos_delay=\"0.6\">
                    <img src=\"{{ asset('assets/img/th-1/about-gallery-img-3.jpg') }}\" alt=\"about-gallery-img-1\" width=\"416\" height=\"286\" class=\"rounded-lg\" />
                </div>
                {# Single Gallery Image #}
            </div>
            {# About Gallery Area #}
        </div>
        {# Section Container #}
    </div>
    {# Section Spacer #}
</div>
{# About Gallery Section End #}

{# Brand Section Start #}
<div class=\"section-brand\">
    <div class=\"jos\">
        {# Section Space #}
        <div class=\"pb-[60px] md:pb-20 lg:pb-[100px]\">
            {# Section Container #}
            <div class=\"container-default\">
                <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                    From start-ups to Fortune 500, we partner with brands of all
                    sizes
                </div>
                {# Brand Slider #}
                <div class=\"swiper brand-slider\">
                    {# Additional required wrapper #}
                    <div class=\"swiper-wrapper\">
                        {# Slides #}
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                    </div>
                </div>
                {# Brand Slider #}
            </div>
            {# Section Container #}
        </div>
        {# Section Space #}
    </div>
</div>
{# Brand Section End #}

{# About Hero Section Start #}
<section class=\"section-about-hero\">
    <div class=\"relative z-10 overflow-hidden bg-[#FAF9F5]\">
        {# Section Space #}
        <div class=\"section-space\">
            {# Section Container #}
            <div class=\"container-custom has-container-custom\">
                {# About Hero Area #}
                <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-[60px] xl:gap-[100px] xxl:grid-cols-[1fr_minmax(0,_1.1fr)]\">
                    {# About Hero Image Block #}
                    <div class=\"jos order-2 lg:order-1\" data-jos_animation=\"fade-left\" data-jos_delay=\"0\">
                        <div class=\"relative flex items-center justify-center mx-auto lg:mx-0 max-w-full sm:max-w-[80%] md:max-w-[70%] lg:max-w-full\">
                            <img src=\"{{ asset('assets/img/th-1/hero-img.jpg') }}\" alt=\"hero image\" width=\"600\" height=\"579\" class=\"h-auto w-full\" />
                            <a data-fslightbox=\"gallery\" href=\"https://www.youtube.com/watch?v=3nQNiWdeH2Q\" class=\"group group absolute flex h-[100px] w-[100px] items-center justify-center rounded-[50%] bg-white text-ColorBlue\" aria-label=\"video-play\">
                                <span class=\"text-2xl transition-all duration-300 ease-linear group-hover:scale-110\"><i class=\"fa-solid fa-play\"></i></span>
                            </a>
                        </div>
                    </div>
                    {# About Hero Image Block #}
                    {# About Hero Content Block #}
                    <div class=\"jos order-1 lg:order-2\" data-jos_animation=\"fade-right\" data-jos_delay=\"0.3\">
                        {# Section Wrapper #}
                        <div>
                            {# Section Block #}
                            <div class=\"mb-5\">
                                <h2>
                                    Our vision is to build brands and provide world-class
                                    experiences to our clients
                                </h2>
                            </div>
                            {# Section Block #}
                            <p>
                                SINCE 1998, we transform bold business ideas into
                                exceptional digital products. We ideate, design, and
                                develop data-driven digital products made to answer
                                business challenges.
                            </p>
                            {# Horizontal Line Separator #}
                            <div class=\"my-7 h-px w-full bg-ColorBlack opacity-10 xl:my-10 xxl:my-14\"></div>
                            {# BlockQuote Block #}
                            <div>
                                <blockquote class=\"mb-6 font-semibold italic text-ColorBlack/80\">
                                    “We love what we do & create partnerships with our
                                    clients to ensure their digital transformation is
                                    positioned for long-term success.”
                                </blockquote>
                                <div class=\"flex flex-col items-center gap-4 lg:flex-row\">
                                    <img src=\"{{ asset('assets/img/th-1/about-hero-user-blockquote-img.jpg') }}\" alt=\"about-hero-user-blockquote-img\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] rounded-[50%] lg:mx-0\" />
                                    <div>
                                        <span class=\"block font-semibold\">Karen Lynn</span>
                                        <span class=\"text-sm text-opacity-80\">CEO & Co-founder @ Company</span>
                                    </div>
                                </div>
                            </div>
                        </div>
                        {# Section Wrapper #}
                    </div>
                    {# About Hero Content Block #}
                </div>
                {# About Hero Area #}
            </div>
            {# Section Container #}
        </div>
        {# Section Space #}
    </div>
</section>
{# About Hero Section End #}

{# Fact Section Start #}
<section class=\"section-fact\">
    {# Section Space #}
    <div class=\"section-space\">
        {# Section Container #}
        <div class=\"container-custom has-container-custom\">
            {# Fact Area Block #}
            <div class=\"grid gap-10 gap-x-12 lg:grid-cols-2 xl:grid-cols-[1fr_minmax(0,_0.7fr)] xxl:gap-x-[185px]\">
                {# Content Block Left #}
                <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"0\">
                    {# Section Wrapper #}
                    <div>
                        {# Section Block #}
                        <div class=\"mb-5\">
                            <h2>
                                Our creative talent has been influencing branding around
                                the world for a long time
                            </h2>
                        </div>
                        {# Section Block #}
                        <p>
                            With more than a decade of experience. We are worry about
                            the details so you need don't have to. When you work with
                            our agency, you can be sure that your website meets every
                            standard.
                        </p>
                    </div>
                    {# Section Wrapper #}
                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group mt-8 inline-block lg:mt-[50px]\"><span>Get in touch</span></a>
                </div>
                {# Content Block Left #}
                {# Content Block Right #}
                <div>
                    {# Counter List #}
                    <div class=\"grid items-center justify-center gap-6 sm:grid-cols-2 sm:gap-0.5 sm:bg-ColorOffWhite\">
                        {# Counter Item #}
                        <div class=\"text-center sm:bg-white sm:pb-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"36\">36</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Satisfied clients</span>
                        </div>
                        {# Counter Item #}
                        {# Counter Item #}
                        <div class=\"text-center sm:bg-white sm:pb-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"80\">80</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Active Engagement</span>
                        </div>
                        {# Counter Item #}
                        {# Counter Item #}
                        <div class=\"text-center sm:bg-white sm:pt-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"54\">54</span>K+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Success projects</span>
                        </div>
                        {# Counter Item #}
                        {# Counter Item #}
                        <div class=\"text-center sm:bg-white sm:pt-10\">
                            <div class=\"mb-1 font-PlusJakartaSans text-4xl font-extrabold leading-[1.2] -tracking-[1px] text-ColorBlack sm:text-5xl lg:text-[64px] xl:text-[70px]\" data-module=\"countup\">
                                <span class=\"start-number\" data-countup-number=\"36\">72</span>+
                            </div>
                            <span class=\"text-xl font-semibold text-ColorBlue\">Awards winning</span>
                        </div>
                        {# Counter Item #}
                    </div>
                    {# Counter List #}
                </div>
                {# Content Block Right #}
            </div>
            {# Fact Area Block #}
        </div>
        {# Section Container #}
    </div>
    {# Section Space #}
</section>
{# Fact Section End #}

{# Feature Section Start #}
<section class=\"section-features\">
    <div class=\"bg-ColorOffWhite\">
        {# Section Space #}
        <div class=\"section-space\">
            {# Section Container #}
            <div class=\"container-default\">
                {# Section Content Wrapper #}
                <div class=\"jos mb-[60px] xl:mb-20\">
                    {# Section Content Block #}
                    <div class=\"mx-auto max-w-[526px]\">
                        <h2 class=\"text-center\">
                            Our core values that drive everything we do
                        </h2>
                    </div>
                    {# Section Content Block #}
                </div>
                {# Section Content Wrapper #}

                {# Feature List #}
                <div class=\"grid gap-10 sm:grid-cols-2 xl:grid-cols-3 xl:gap-10 xxl:gap-x-20 xxl:gap-y-[60px]\">
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-1.svg') }}\" alt=\"icon-yellow-feature-1\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Passionate about work
                                </div>
                                <p>
                                    Passion for work is a enthusiasm and excitement for
                                    what you do.
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0.3\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-2.svg') }}\" alt=\"icon-yellow-feature-1\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Creative team members
                                </div>
                                <p>
                                    A creative team is to design and execute campaigns &
                                    encourage
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-left\" data-jos_delay=\"0.6\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-3.svg') }}\" alt=\"icon-yellow-feature-3\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Innovation solutions
                                </div>
                                <p>
                                    using either completely concepts finding new ways of
                                    using existing
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"0.9\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-4.svg') }}\" alt=\"icon-yellow-feature-4\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Qualitiful products
                                </div>
                                <p>
                                    Product quality refers to how well a product satisfies
                                    our customer
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"1.2\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-5.svg') }}\" alt=\"icon-yellow-feature-5\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Customer satisfaction
                                </div>
                                <p>
                                    Happy customers are delighted because of the customer
                                    service
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                    {# Feature Item #}
                    <div class=\"jos\" data-jos_animation=\"fade-right\" data-jos_delay=\"1.5\">
                        <div class=\"flex flex-col gap-6 text-center lg:flex-row lg:text-left\">
                            <img src=\"{{ asset('assets/img/icons/icon-yellow-feature-6.svg') }}\" alt=\"icon-yellow-feature-6\" width=\"60\" height=\"60\" class=\"mx-auto h-[60px] w-[60px] lg:mx-0\" />
                            <div>
                                <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5] xxl:text-2xl\">
                                    Simplicity interface
                                </div>
                                <p>
                                    Simplicity is used loosely to refer to the need to
                                    minimize a process
                                </p>
                            </div>
                        </div>
                    </div>
                    {# Feature Item #}
                </div>
                {# Feature List #}
            </div>
            {# Section Container #}
        </div>
        {# Section Space #}
    </div>
</section>
{# Feature Section End #}

{# Portfolio Section Start #}
<section class=\"section-portfolio\">
    <div class=\"relative z-10 overflow-hidden\">
        {# Section Space #}
        <div class=\"section-space\">
            {# Section Container #}
            <div class=\"container-default\">
                {# Section Wrapper #}
                <div class=\"jos mb-[60px] flex flex-wrap items-end justify-between gap-8 xl:mb-20\">
                    {# Section Block #}
                    <div class=\"max-w-[550px]\">
                        <h2>We create world-class web design, & branding</h2>
                    </div>
                    {# Section Block #}
                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>See more works</span></a>
                </div>
                {# Section Wrapper #}

                {# Portfolio List #}
                <div class=\"grid gap-8 md:grid-cols-2 lg:gap-10 xl:gap-[60px]\">
                    {# Portfolio Item #}
                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-img-1.jpg') }}\" alt=\"portfolio-img-1\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 lg:flex-nowrap xl:mb-7\">
                                    <a href=\"##\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue xl:text-2xl\">App — The power of communication</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <a href=\"##\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    {# Portfolio Item #}
                    {# Portfolio Item #}
                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-img-2.jpg') }}\" alt=\"portfolio-img-2\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 lg:flex-nowrap xl:mb-7\">
                                    <a href=\"##\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue xl:text-2xl\">Website — The future lifestyle platform.</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <a href=\"##\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    {# Portfolio Item #}
                </div>
                {# Portfolio List #}
            </div>
            {# Section Container #}
        </div>
        {# Section Space #}

        {# Portfolio Shape - 2 #}
        <div class=\"absolute right-0 top-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/portfolio-1-shape-1.svg') }}\" alt=\"portfolio-1-shape-1\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
{# Portfolio Section End #}

{# Team Section Start #}
<section class=\"section-team\">
    <div class=\"bg-ColorOffWhite\">
        {# Section Space #}
        <div class=\"section-space\">
            {# Section Container #}
            <div class=\"container-default\">
                {# Section Content Wrapper #}
                <div class=\"jos mb-[60px] xl:mb-20\">
                    {# Section Content Block #}
                    <div class=\"mx-auto max-w-[526px]\">
                        <h2 class=\"text-center\">
                            Amazing team behind our creative products
                        </h2>
                    </div>
                    {# Section Content Block #}
                </div>
                {# Section Content Wrapper #}

                {# Team List #}
                <div class=\"grid gap-x-6 gap-y-8 sm:grid-cols-2 lg:grid-cols-4\">
                    {# Team Item #}
                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"{{ asset('assets/img/th-1/team-img-1.jpg') }}\" alt=\"team-img-1\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Eleanor Pena</div>
                            <span class=\"block text-opacity-80\">CEO & Co-founder</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    {# Team Item #}
                    {# Team Item #}
                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"{{ asset('assets/img/th-1/team-img-2.jpg') }}\" alt=\"team-img-2\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">
                                Leslie Alexander
                            </div>
                            <span class=\"block text-opacity-80\">Product Manager</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    {# Team Item #}
                    {# Team Item #}
                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"{{ asset('assets/img/th-1/team-img-3.jpg') }}\" alt=\"team-img-3\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Jane Cooper</div>
                            <span class=\"block text-opacity-80\">Web Developer</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    {# Team Item #}
                    {# Team Item #}
                    <div class=\"jos flex flex-col items-center justify-center rounded-[10px] bg-white p-5 text-center\" data-jos_animation=\"flip-left\">
                        <img src=\"{{ asset('assets/img/th-1/team-img-4.jpg') }}\" alt=\"team-img-4\" width=\"266\" height=\"250\" class=\"h-auto w-full rounded-[10px] lg:w-auto\" />
                        <div class=\"mb-4 mt-6\">
                            <div class=\"mb-1 text-xl font-semibold\">Floyd Miles</div>
                            <span class=\"block text-opacity-80\">Marketing Expert</span>
                        </div>

                        <div class=\"flex flex-wrap gap-[10px] xl:gap-4\">
                            <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"twitter\">
                                <i class=\"fa-brands fa-x-twitter\"></i>
                            </a>
                            <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"facebook\">
                                <i class=\"fa-brands fa-facebook-f\"></i>
                            </a>
                            <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"instagram\">
                                <i class=\"fa-brands fa-instagram\"></i>
                            </a>
                            <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[35px] w-[35px] items-center justify-center rounded-[50%] bg-ColorBlack bg-opacity-5 text-sm text-ColorBlack transition-all duration-300 hover:bg-ColorBlack hover:bg-opacity-100 hover:text-white\" aria-label=\"github\">
                                <i class=\"fa-brands fa-github\"></i>
                            </a>
                        </div>
                    </div>
                    {# Team Item #}
                </div>
                {# Team List #}
            </div>
            {# Section Container #}
        </div>
        {# Section Space #}
    </div>
</section>
{# Team Section End #}

{# FAQ Section Start #}
<section class=\"section-faq\">
    {# Section Space #}
    <div class=\"section-space\">
        {# Section Container #}
        <div class=\"container-default\">
            {# Section Content Wrapper #}
            <div class=\"jos mb-[60px] xl:mb-20\">
                {# Section Content Block #}
                <div class=\"mx-auto max-w-[625px]\">
                    <h2 class=\"text-center\">
                        Frequently asked questions about our digital agency
                    </h2>
                </div>
                {# Section Content Block #}
            </div>
            {# Section Content Wrapper #}
            {# FAQ Area #}
            <div class=\"jos\">
                {# Accordion List #}
                <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                    {# Accordion Item #}
                    <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        {# Accordion Header #}
                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What is a digital agency?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        {# Accordion Header #}
                        {# Accordion Body #}
                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        {# Accordion Body #}
                    </li>
                    {# Accordion Item #}
                    {# Accordion Item #}
                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        {# Accordion Header #}
                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What services does a digital agency provide?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        {# Accordion Header #}
                        {# Accordion Body #}
                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        {# Accordion Body #}
                    </li>
                    {# Accordion Item #}
                    {# Accordion Item #}
                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        {# Accordion Header #}
                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. Hiring a digital agency vs hiring in-house: What is
                                the difference?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        {# Accordion Header #}
                        {# Accordion Body #}
                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        {# Accordion Body #}
                    </li>
                    {# Accordion Item #}
                    {# Accordion Item #}
                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        {# Accordion Header #}
                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. What questions should you ask when interviewing a
                                digital agency?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        {# Accordion Header #}
                        {# Accordion Body #}
                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        {# Accordion Body #}
                    </li>
                    {# Accordion Item #}
                    {# Accordion Item #}
                    <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                        {# Accordion Header #}
                        <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                            <button class=\"flex-1 text-left\">
                                Q. How do digital agencies charge for their services?
                            </button>
                            <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                            </div>
                        </div>
                        {# Accordion Header #}
                        {# Accordion Body #}
                        <div class=\"accordion-body max-w-[826px] opacity-80\">
                            <p class=\"pt-5\">
                                A digital agency is a company that leverages digital
                                channels to grow their clients’ brands online. ls and
                                technologies such as web design, digital marketing,
                                creative design and app development.
                            </p>
                        </div>
                        {# Accordion Body #}
                    </li>
                    {# Accordion Item #}
                </ul>
                {# Accordion List #}

                <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                    <a href=\"##\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                </div>
            </div>
            {# FAQ Area #}
        </div>
        {# Section Container #}
    </div>
    {# Section Space #}
</section>
{# FAQ Section End #}

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %}

", "home/about.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\about.html.twig");
    }
}
