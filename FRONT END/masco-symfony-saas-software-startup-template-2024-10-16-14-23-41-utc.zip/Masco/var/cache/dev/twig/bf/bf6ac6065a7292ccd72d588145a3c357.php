<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/comingsoon.html.twig */
class __TwigTemplate_91719705fadf9c6426899715febff66f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/comingsoon.html.twig"));

        // line 1
        yield "<!doctype html>
<html lang=\"en\">

";
        // line 4
        yield from         $this->loadTemplate("partials/head.html.twig", "home/comingsoon.html.twig", 4)->unwrap()->yield($context);
        // line 5
        yield "
<body>
    <div class=\"page-wrapper relative z-[1] bg-ColorOffWhite\">
        <main class=\"main-wrapper relative overflow-hidden\">
            <!-- Sign-in Section Start -->
            <section class=\"section-signin\">
                <!-- Section Space -->
                <div class=\"section-space\">
                    <!-- Section Container -->
                    <div class=\"container-default\">
                        <div class=\"mx-auto max-w-[856px]\">
                            <div class=\"flex flex-col items-center justify-center text-center\">
                                <!-- Logo -->
                                <a href=\"";
        // line 18
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"mb-[60px] lg:mb-20 xl:mb-[100px]\">
                                    <img src=\"";
        // line 19
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"logo-blue-dark\" width=\"109\" height=\"24\" />
                                </a>
                                <!-- Logo -->

                                <!-- Count Down Wrapper -->
                                <div class=\"jos mb-10 grid grid-cols-2 gap-10 text-center text-[62px] font-bold leading-none text-ColorBlue sm:flex sm:flex-row sm:gap-20 md:gap-x-[100px] lg:mb-[60px]\">
                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"days\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Days</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"hours\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Hours</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"minutes\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Minutes</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"seconds\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Seconds</span>
                                    </div>
                                </div>
                                <!-- Count Down Wrapper -->

                                <!-- Section Wrapper -->
                                <div>
                                    <!-- Section Block -->
                                    <div>
                                        <!-- Section Title -->
                                        <h2 class=\"mb-10\">
                                            We're coming! With something special for you. Stay with
                                            us
                                        </h2>
                                        <!-- Section Title -->
                                    </div>
                                    <!-- Section Block -->
                                </div>
                                <!-- Section Wrapper -->

                                <!-- Newsletter Form -->
                                <div class=\"jos\">
                                    <form action=\"#\" method=\"post\">
                                        <div class=\"relative h-auto w-full sm:h-[60px] sm:w-[480px] md:w-[556px]\">
                                            <input type=\"email\" name=\"email\" id=\"email\" class=\"h-full w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/80 focus:border-ColorBlue\" placeholder=\"Enter your email\" required />
                                            <button type=\"submit\" class=\"btn is-blue is-large is-rounded bottom-[5px] right-[5px] top-[5px] mt-6 h-[50px] leading-none hover:bg-white sm:absolute sm:mt-0\">
                                                Get Notified
                                            </button>
                                        </div>
                                    </form>
                                    <p class=\"mt-3\">
                                        We do not share your information with any third party & no
                                        spam
                                    </p>
                                </div>
                                <!-- Newsletter Form -->
                            </div>
                        </div>
                    </div>
                    <!-- Section Container -->
                </div>
                <!-- Section Space -->
            </section>
            <!-- Sign-in Section End -->
        </main>
    </div>

    <!--Vendor js-->
    <script src=\"";
        // line 90
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/counterup.js"), "html", null, true);
        yield "\" type=\"module\"></script>
    <script src=\"";
        // line 91
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/swiper-bundle.min.js"), "html", null, true);
        yield "\"></script>
    <script src=\"";
        // line 92
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/fslightbox.js"), "html", null, true);
        yield "\"></script>
    <script src=\"";
        // line 93
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/jos.min.js"), "html", null, true);
        yield "\"></script>
    <script src=\"";
        // line 94
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/vendors/countdown.js"), "html", null, true);
        yield "\"></script>

    <!-- Main js -->
    <script src=\"";
        // line 97
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/js/main.js"), "html", null, true);
        yield "\"></script>
    
</body>

</html>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/comingsoon.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  163 => 97,  157 => 94,  153 => 93,  149 => 92,  145 => 91,  141 => 90,  67 => 19,  63 => 18,  48 => 5,  46 => 4,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!doctype html>
<html lang=\"en\">

{% include 'partials/head.html.twig' %}

<body>
    <div class=\"page-wrapper relative z-[1] bg-ColorOffWhite\">
        <main class=\"main-wrapper relative overflow-hidden\">
            <!-- Sign-in Section Start -->
            <section class=\"section-signin\">
                <!-- Section Space -->
                <div class=\"section-space\">
                    <!-- Section Container -->
                    <div class=\"container-default\">
                        <div class=\"mx-auto max-w-[856px]\">
                            <div class=\"flex flex-col items-center justify-center text-center\">
                                <!-- Logo -->
                                <a href=\"{{ path('home') }}\" class=\"mb-[60px] lg:mb-20 xl:mb-[100px]\">
                                    <img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"logo-blue-dark\" width=\"109\" height=\"24\" />
                                </a>
                                <!-- Logo -->

                                <!-- Count Down Wrapper -->
                                <div class=\"jos mb-10 grid grid-cols-2 gap-10 text-center text-[62px] font-bold leading-none text-ColorBlue sm:flex sm:flex-row sm:gap-20 md:gap-x-[100px] lg:mb-[60px]\">
                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"days\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Days</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"hours\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Hours</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"minutes\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Minutes</span>
                                    </div>

                                    <div class=\"relative flex flex-col gap-y-[5px] after:absolute after:left-[calc(100%+_30px)] after:top-0 after:content-none last:after:content-none sm:after:content-['_:'] md:after:left-[calc(100%+_40px)]\">
                                        <div class=\"seconds\"></div>
                                        <span class=\"text-xl font-medium capitalize\">Seconds</span>
                                    </div>
                                </div>
                                <!-- Count Down Wrapper -->

                                <!-- Section Wrapper -->
                                <div>
                                    <!-- Section Block -->
                                    <div>
                                        <!-- Section Title -->
                                        <h2 class=\"mb-10\">
                                            We're coming! With something special for you. Stay with
                                            us
                                        </h2>
                                        <!-- Section Title -->
                                    </div>
                                    <!-- Section Block -->
                                </div>
                                <!-- Section Wrapper -->

                                <!-- Newsletter Form -->
                                <div class=\"jos\">
                                    <form action=\"#\" method=\"post\">
                                        <div class=\"relative h-auto w-full sm:h-[60px] sm:w-[480px] md:w-[556px]\">
                                            <input type=\"email\" name=\"email\" id=\"email\" class=\"h-full w-full rounded-[50px] border border-ColorBlack/50 px-[30px] py-[15px] outline-none transition-all duration-300 placeholder:text-ColorBlack/80 focus:border-ColorBlue\" placeholder=\"Enter your email\" required />
                                            <button type=\"submit\" class=\"btn is-blue is-large is-rounded bottom-[5px] right-[5px] top-[5px] mt-6 h-[50px] leading-none hover:bg-white sm:absolute sm:mt-0\">
                                                Get Notified
                                            </button>
                                        </div>
                                    </form>
                                    <p class=\"mt-3\">
                                        We do not share your information with any third party & no
                                        spam
                                    </p>
                                </div>
                                <!-- Newsletter Form -->
                            </div>
                        </div>
                    </div>
                    <!-- Section Container -->
                </div>
                <!-- Section Space -->
            </section>
            <!-- Sign-in Section End -->
        </main>
    </div>

    <!--Vendor js-->
    <script src=\"{{ asset('assets/js/vendors/counterup.js') }}\" type=\"module\"></script>
    <script src=\"{{ asset('assets/js/vendors/swiper-bundle.min.js') }}\"></script>
    <script src=\"{{ asset('assets/js/vendors/fslightbox.js') }}\"></script>
    <script src=\"{{ asset('assets/js/vendors/jos.min.js') }}\"></script>
    <script src=\"{{ asset('assets/js/vendors/countdown.js') }}\"></script>

    <!-- Main js -->
    <script src=\"{{ asset('assets/js/main.js') }}\"></script>
    
</body>

</html>
", "home/comingsoon.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\comingsoon.html.twig");
    }
}
