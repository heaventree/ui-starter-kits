<template>
    <div>
        <div id="loading" class="loading--theme">
            <div id="loading-center"><span class="loader"></span></div>
        </div>
    </div>
</template>
