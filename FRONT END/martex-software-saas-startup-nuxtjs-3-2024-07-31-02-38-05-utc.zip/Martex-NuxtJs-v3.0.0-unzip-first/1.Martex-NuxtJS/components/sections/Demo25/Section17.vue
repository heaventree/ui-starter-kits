<template>
    <section id="integrations-2" class="pt-100 integrations-section">
        <div class="container">
            <!-- INTEGRATIONS-2 WRAPPER -->
            <div class="integrations-2-wrapper bg--white-400 bg--scroll r-12 text-center">
                <!-- SECTION TITLE -->
                <div class="row justify-content-center">
                    <div class="col-md-10 col-lg-9">
                        <div class="section-title mb-50">
                            <!-- Title -->
                            <h2 class="s-48 w-700">Easy integrate all your essential tools</h2>
                            <!-- Text -->
                            <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                        </div>
                    </div>
                </div>
                <!-- TOOLS ROW -->
                <div class="row row-cols-1 row-cols-sm-3 row-cols-md-5">
                    <!-- TOOL #1 -->
                    <div class="col">
                        <a href="#" class="in_tool it-1 r-12 wow fadeInUp">
                            <!-- Logo -->
                            <div class="in_tool_logo ico-65 bg--white-100 block-shadow r-12">
                                <img class="img-fluid" src="/assets/images/png_icons/tool-1.png" alt="brand-logo" />
                            </div>
                            <!-- Title -->
                            <h6 class="s-17 w-700">Zapier</h6>
                        </a>
                    </div>
                    <!-- END TOOL #1 -->
                    <!-- TOOL #2 -->
                    <div class="col">
                        <a href="#" class="in_tool it-2 r-12 wow fadeInUp">
                            <!-- Logo -->
                            <div class="in_tool_logo ico-65 bg--white-100 block-shadow r-12">
                                <img class="img-fluid" src="/assets/images/png_icons/tool-2.png" alt="brand-logo" />
                            </div>
                            <!-- Title -->
                            <h6 class="s-17 w-700">Google Analytics</h6>
                        </a>
                    </div>
                    <!-- END TOOL #2 -->
                    <!-- TOOL #3 -->
                    <div class="col">
                        <a href="#" class="in_tool it-3 r-12 wow fadeInUp">
                            <!-- Logo -->
                            <div class="in_tool_logo ico-65 bg--white-100 block-shadow r-12">
                                <img class="img-fluid" src="/assets/images/png_icons/tool-3.png" alt="brand-logo" />
                            </div>
                            <!-- Title -->
                            <h6 class="s-17 w-700">Amplitude</h6>
                        </a>
                    </div>
                    <!-- END TOOL #3 -->
                    <!-- TOOL #4 -->
                    <div class="col">
                        <a href="#" class="in_tool it-4 r-12 wow fadeInUp">
                            <!-- Logo -->
                            <div class="in_tool_logo ico-65 bg--white-100 block-shadow r-12">
                                <img class="img-fluid" src="/assets/images/png_icons/tool-4.png" alt="brand-logo" />
                            </div>
                            <!-- Title -->
                            <h6 class="s-17 w-700">Hubspot</h6>
                        </a>
                    </div>
                    <!-- END TOOL #4 -->
                    <!-- TOOL #5 -->
                    <div class="col">
                        <a href="#" class="in_tool it-5 r-12 wow fadeInUp">
                            <!-- Logo -->
                            <div class="in_tool_logo ico-65 bg--white-100 block-shadow r-12">
                                <img class="img-fluid" src="/assets/images/png_icons/tool-5.png" alt="brand-logo" />
                            </div>
                            <!-- Title -->
                            <h6 class="s-17 w-700">MailChimp</h6>
                        </a>
                    </div>
                    <!-- END TOOL #5 -->
                </div>
                <!-- END TOOLS ROW -->
                <!-- MORE BUTTON -->
                <div class="row">
                    <div class="col">
                        <div class="more-btn text-center mt-60 wow fadeInUp">
                            <NuxtLink to="/integrations" class="btn btn--tra-black hover--theme">View all integrations</NuxtLink>
                        </div>
                    </div>
                </div>
            </div>
            <!-- END INTEGRATIONS-2 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
