<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/faq2.html.twig */
class __TwigTemplate_4a53caccf412bbc09d75e3ef714a1d1d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/faq2.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/faq2.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 8
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 9
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 11
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 25
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 26
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/faq2.html.twig", 26)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 29
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 30
        yield "

<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"grid gap-10 md:grid-cols-2 lg:gap-20 xl:gap-[104px]\">
                    <div class=\"jos\">
                        <!-- FAQ List -->
                        <ul>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q1. What is a digital agency?
                                </div>
                                <p>
                                    Digital agencies are strategic and creative marketing
                                    agencies from a focused on user experience, mobile,
                                    social, data gathering &analytics
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q2. What services does a digital agency provide?
                                </div>
                                <p>
                                    A full service digital marketing agency is one that
                                    manages all aspects of a company's online presence.
                                    This kind of agency’s different from a departments
                                    that focus on one area.
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q3. Would my company benefit from digital marketing?
                                </div>
                                <p>
                                    Digital marketing is a must for building a successful
                                    business. It is a growing your brand or improving
                                    sales, there are no limits to it. In the digital
                                    space, you can take advantage of it and future-proof.
                                </p>
                            </li>
                        </ul>
                        <!-- FAQ List -->
                    </div>
                    <div class=\"jos\">
                        <!-- FAQ List -->
                        <ul>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q4. Would my company benefit from digital marketing?
                                </div>
                                <p>
                                    YES YES YES. You don’t have to replace your
                                    traditional marketing efforts with digital ones, but
                                    it is 2019 and if the word digital come
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q5. How often should I update my website?
                                </div>
                                <p>
                                    A website that sits stagnant for long periods of time,
                                    without any new or fresh content, is nothing more that
                                    an online brochure for company. A successful website
                                    will interact with consumers.
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q6. Is email marketing still effective?
                                </div>
                                <p>
                                    Definitely! You should never assume that because
                                    social media has a become so hugely popular, that it’s
                                    enough to solely focus your digital marketing strategy
                                    on social platforms.
                                </p>
                            </li>
                        </ul>
                        <!-- FAQ List -->
                    </div>
                </div>
                <!-- FAQ Area -->

                <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                    <a href=\"";
        // line 121
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                </div>
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

<!-- Brand Section Start -->
<div class=\"section-brand\">
    <div class=\"jos\">
        <div class=\"bg-ColorOffWhite\">
            <!-- Section Space -->
            <div class=\"py-[60px] md:py-20 lg:py-[100px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                        From start-ups to Fortune 500, we partner with brands of all
                        sizes
                    </div>
                    <!-- Brand Slider -->
                    <div class=\"swiper brand-slider\">
                        <!-- Additional required wrapper -->
                        <div class=\"swiper-wrapper\">
                            <!-- Slides -->
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 149
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 152
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 155
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 158
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 161
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 164
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 167
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 170
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 173
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"";
        // line 176
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                        </div>
                    </div>
                    <!-- Brand Slider -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </div>
</div>
<!-- Brand Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 194
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 195
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/faq2.html.twig", 195)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/faq2.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  341 => 195,  334 => 194,  311 => 176,  305 => 173,  299 => 170,  293 => 167,  287 => 164,  281 => 161,  275 => 158,  269 => 155,  263 => 152,  257 => 149,  226 => 121,  133 => 30,  126 => 29,  117 => 26,  110 => 25,  90 => 12,  86 => 11,  82 => 9,  75 => 8,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 


{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}


<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"grid gap-10 md:grid-cols-2 lg:gap-20 xl:gap-[104px]\">
                    <div class=\"jos\">
                        <!-- FAQ List -->
                        <ul>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q1. What is a digital agency?
                                </div>
                                <p>
                                    Digital agencies are strategic and creative marketing
                                    agencies from a focused on user experience, mobile,
                                    social, data gathering &analytics
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q2. What services does a digital agency provide?
                                </div>
                                <p>
                                    A full service digital marketing agency is one that
                                    manages all aspects of a company's online presence.
                                    This kind of agency’s different from a departments
                                    that focus on one area.
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q3. Would my company benefit from digital marketing?
                                </div>
                                <p>
                                    Digital marketing is a must for building a successful
                                    business. It is a growing your brand or improving
                                    sales, there are no limits to it. In the digital
                                    space, you can take advantage of it and future-proof.
                                </p>
                            </li>
                        </ul>
                        <!-- FAQ List -->
                    </div>
                    <div class=\"jos\">
                        <!-- FAQ List -->
                        <ul>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q4. Would my company benefit from digital marketing?
                                </div>
                                <p>
                                    YES YES YES. You don’t have to replace your
                                    traditional marketing efforts with digital ones, but
                                    it is 2019 and if the word digital come
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q5. How often should I update my website?
                                </div>
                                <p>
                                    A website that sits stagnant for long periods of time,
                                    without any new or fresh content, is nothing more that
                                    an online brochure for company. A successful website
                                    will interact with consumers.
                                </p>
                            </li>
                            <li class=\"mb-10 border-b border-ColorBlack pb-10 last:mb-0 last:border-b-0 last:pb-0\">
                                <div class=\"mb-[15px] text-xl font-semibold text-ColorBlack\">
                                    Q6. Is email marketing still effective?
                                </div>
                                <p>
                                    Definitely! You should never assume that because
                                    social media has a become so hugely popular, that it’s
                                    enough to solely focus your digital marketing strategy
                                    on social platforms.
                                </p>
                            </li>
                        </ul>
                        <!-- FAQ List -->
                    </div>
                </div>
                <!-- FAQ Area -->

                <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                    <a href=\"{{ path('contact') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                </div>
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

<!-- Brand Section Start -->
<div class=\"section-brand\">
    <div class=\"jos\">
        <div class=\"bg-ColorOffWhite\">
            <!-- Section Space -->
            <div class=\"py-[60px] md:py-20 lg:py-[100px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                        From start-ups to Fortune 500, we partner with brands of all
                        sizes
                    </div>
                    <!-- Brand Slider -->
                    <div class=\"swiper brand-slider\">
                        <!-- Additional required wrapper -->
                        <div class=\"swiper-wrapper\">
                            <!-- Slides -->
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                            <div class=\"swiper-slide\">
                                <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                            </div>
                        </div>
                    </div>
                    <!-- Brand Slider -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </div>
</div>
<!-- Brand Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/faq2.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\faq2.html.twig");
    }
}
