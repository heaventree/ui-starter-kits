<template>
    <section id="hero-13" class="hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO TEXT -->
                <div class="col-md-5">
                    <div class="hero-13-txt wow fadeInRight">
                        <!-- Section ID -->
                        <span class="section-id">Strategies That Work</span>
                        <!-- Title -->
                        <h2 class="s-54 w-700">Right SEO strategies for your success</h2>
                        <!-- Text -->
                        <p class="p-lg">Mauris ligula ociis ipsum congue neque undo laoreet sagittis sapien diam tempor</p>
                        <!-- Button -->
                        <a href="#banner-13" class="btn r-04 btn--theme hover--tra-black">Get started for free</a>
                        <p class="p-sm btn-txt ico-15"><span class="flaticon-check"></span> No credit card needed, free 14-day trial</p>
                    </div>
                </div>
                <!-- END HERO TEXT -->
                <!-- HERO IMAGE -->
                <div class="col-md-7">
                    <div class="hero-13-img wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/hero-13-img.png" alt="hero-image" />
                    </div>
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
