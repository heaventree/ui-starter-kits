<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* OnePage/indexOnePage1.html.twig */
class __TwigTemplate_a55e015d101cee047ca2994e476aaaae extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout2.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "OnePage/indexOnePage1.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout2.html.twig", "OnePage/indexOnePage1.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue sm:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden sm:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 28
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 29
        yield "
  <!-- Hero Section Start -->
  <section class=\"section-hero\">
    <div class=\"relative z-10 overflow-hidden bg-[#FAF9F5]\">
        <!-- Section Space -->
        <div class=\"pb-[60px] pt-28 md:pb-20 md:pt-36 lg:pb-[100px] lg:pt-[150px] xxl:pb-[120px] xxl:pt-[185px]\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Hero Area -->
                <div class=\"grid gap-10 lg:grid-cols-2 xxl:grid-cols-[1.1fr_minmax(0,_1fr)]\">
                    <!-- Hero Content Block -->
                    <div class=\"jos\">
                        <div class=\"has-container-custom\">
                            <h1 class=\"mb-6\">
                                We focus on growing your brand online
                            </h1>
                            <p>
                                Build world-class digital products with a team of
                                design, development & strategy experts. All in one
                                place. We can provide your business with a variety of
                                digital solutions.
                            </p>
                            <form action=\"#\" method=\"post\" class=\"relative mx-auto flex w-full items-center sm:w-[80%] lg:mx-0 lg:mt-5 lg:max-w-md\">
                                <input type=\"email\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack bg-white px-5 py-[15px] pr-40 text-base font-semibold text-opacity-50 outline-none\" />
                                <button type=\"submit\" class=\"btn is-blue is-rounded absolute right-[5px] py-[10px]\">
                                    Subscribe
                                </button>
                            </form>
                            <div class=\"mt-5 text-sm leading-6 md:justify-normal\">
                                <span class=\"mr-2 inline-block text-lg text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                <span class=\"opacity-50\">No credit card is required. You can cancel
                                    anytime</span>
                            </div>
                        </div>
                    </div>
                    <!-- Hero Content Block -->

                    <!-- Hero Image Block -->
                    <div class=\"jos\">
                        <div class=\"relative flex items-center justify-center\">
                            <img src=\"";
        // line 69
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/hero-img.jpg"), "html", null, true);
        yield "\" alt=\"hero image\" width=\"600\" height=\"579\" class=\"h-auto w-full\" />
                            <a data-fslightbox=\"gallery\" href=\"https://www.youtube.com/watch?v=3nQNiWdeH2Q\" class=\"group group absolute flex h-[100px] w-[100px] items-center justify-center rounded-[50%] bg-white text-ColorBlue\" aria-label=\"video-play\">
                                <span class=\"text-2xl transition-all duration-300 ease-linear group-hover:scale-110\"><i class=\"fa-solid fa-play\"></i></span>
                            </a>
                        </div>
                    </div>
                    <!-- Hero Image Block -->
                </div>
                <!-- Hero Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Hero Shape - 1 -->
        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"";
        // line 85
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/hero-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"hero-shape-1\" width=\"607\" height=\"792\" class=\"\" />
        </div>

        <!-- Hero Shape - 2 -->
        <div class=\"absolute bottom-0 right-0 -z-[1]\">
            <img src=\"";
        // line 90
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/hero-1-shape-2.svg"), "html", null, true);
        yield "\" alt=\"hero-shape-2\" width=\"607\" height=\"792\" />
        </div>
    </div>
</section>
<!-- Hero Section End -->

<!-- Brand Section Start -->
<div class=\"section-brand\">
    <div class=\"jos\">
        <!-- Section Space -->
        <div class=\"py-[60px] md:py-20 lg:py-[100px]\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                    From start-ups to Fortune 500, we partner with brands of all
                    sizes
                </div>
                <!-- Brand Slider -->
                <div class=\"swiper brand-slider\">
                    <!-- Additional required wrapper -->
                    <div class=\"swiper-wrapper\">
                        <!-- Slides -->
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 113
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 116
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 119
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 122
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 125
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 128
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-1.png"), "html", null, true);
        yield "\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 131
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-2.png"), "html", null, true);
        yield "\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 134
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-3.png"), "html", null, true);
        yield "\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 137
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-4.png"), "html", null, true);
        yield "\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"";
        // line 140
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/brand-5.png"), "html", null, true);
        yield "\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                    </div>
                </div>
                <!-- Brand Slider -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- Brand Section End -->

<!-- Horizontal Line Separator -->
<div class=\"horizontal-line bg-ColorBlack\"></div>
<!-- Horizontal Line Separator -->

<!-- Service Section Start -->
<section class=\"section-service\" id=\"section-services\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[590px]\">
                        <h2 class=\"text-center\">
                            All the digital services that are convenient for you
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->

                <!-- Service List -->
                <div class=\"grid gap-6 sm:grid-cols-2\">
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"";
        // line 183
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-black-service-1.svg"), "html", null, true);
        yield "\" alt=\"icon-service-1\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"";
        // line 184
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-blue-service-1.svg"), "html", null, true);
        yield "\" alt=\"icon-service-1\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Branding & Digital Strategies
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Brand strategy is all about developing a unique
                                        identity that distinguishes your business from
                                    </p>
                                    <a href=\"";
        // line 194
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("serviceDetails");
        yield "\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"";
        // line 209
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-black-service-2.svg"), "html", null, true);
        yield "\" alt=\"icon-service-2\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"";
        // line 210
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-blue-service-2.svg"), "html", null, true);
        yield "\" alt=\"icon-service-2\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Web Design & App Development
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Web design & development is an umbrella term that
                                        describes the process of creating a website
                                    </p>
                                    <a href=\"";
        // line 220
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("serviceDetails");
        yield "\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.6\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"";
        // line 235
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-black-service-3.svg"), "html", null, true);
        yield "\" alt=\"icon-service-3\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"";
        // line 236
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-blue-service-3.svg"), "html", null, true);
        yield "\" alt=\"icon-service-3\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Results-Driven Digital Marketing
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Digital marketing potential customers using the
                                        internet & other forms of digital communication
                                    </p>
                                    <a href=\"";
        // line 246
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("serviceDetails");
        yield "\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.9\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"";
        // line 261
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-black-service-4.svg"), "html", null, true);
        yield "\" alt=\"icon-service-4\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"";
        // line 262
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-blue-service-4.svg"), "html", null, true);
        yield "\" alt=\"icon-service-4\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Custom Software Development
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Custom Software Development is the process of
                                        conceptualizing, designing, building & deploying
                                    </p>
                                    <a href=\"";
        // line 272
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("serviceDetails");
        yield "\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                </div>
                <!-- Service List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Service Shape -->
        <div class=\"absolute bottom-0 left-0 -z-10\">
            <img src=\"";
        // line 291
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/service-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"service-section-shape\" width=\"390\" height=\"507\" />
        </div>
        <!-- Service Shape -->
    </div>
</section>
<!-- Service Section End -->

<!-- Content Section Start -->
<section class=\"section-content\" id=\"section-about\">
    <!-- Section Background -->
    <div class=\"bg-ColorOffWhite\">
        <!-- Section Spacer -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <div class=\"flex flex-col gap-y-20 lg:gap-y-[100px] xl:gap-y-[120px]\">
                    <!-- Content Area Single -->
                    <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-24 xl:grid-cols-[1.2fr_minmax(0,_1fr)] xl:gap-[135px]\">
                        <!-- Content Block Left -->
                        <div class=\"jos\" data-jos_animation=\"fade-right\">
                            <!-- Section Wrapper -->
                            <div>
                                <!-- Section Block -->
                                <div class=\"mb-5\">
                                    <h2>
                                        Boost the effectiveness of your promotions as well
                                        as polish your branding
                                    </h2>
                                </div>
                                <!-- Section Block -->
                            </div>
                            <!-- Section Wrapper -->
                            <p>
                                SINCE 1998, we transform bold business ideas into
                                exceptional digital products. We ideate, design, and
                                develop data-driven digital products made to answer
                                business challenges.
                            </p>
                            <p>
                                We offer 360° services to smoothly guide you on your way
                                to creating a seamless digital masterpiece projects on
                                budget and on time.
                            </p>
                        </div>
                        <!-- Content Block Left -->
                        <!-- Content Block Right -->
                        <div class=\"jos relative\" data-jos_animation=\"fade-left\">
                            <div class=\"rounded-[10px] bg-[#FCEDCF] p-[30px] lg:p-10 xl:p-[50px]\">
                                <!-- Content Image -->
                                <img src=\"";
        // line 340
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/content-img-1.jpg"), "html", null, true);
        yield "\" alt=\"content-img-1\" width=\"426\" height=\"398\" class=\"h-auto w-full rounded-[10px]\" />
                            </div>
                            <!-- Content Shape -->
                            <img src=\"";
        // line 343
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/content-shape-1.svg"), "html", null, true);
        yield "\" alt=\"content-shape-1\" width=\"168\" height=\"61\" class=\"absolute -right-16 -top-16\" />
                        </div>
                        <!-- Content Block Right -->
                    </div>
                    <!-- Content Area Single -->

                    <!-- Content Area Single -->
                    <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-24 xl:grid-cols-[1fr_minmax(0,_1.2fr)] xl:gap-[135px]\">
                        <!-- Content Block Left -->
                        <div class=\"jos lg:order-2\" data-jos_animation=\"fade-left\">
                            <!-- Section Wrapper -->
                            <div>
                                <!-- Section Block -->
                                <div class=\"mb-5\">
                                    <h2>
                                        Discover the latest digital strategies & emerging
                                        ideas for business growth
                                    </h2>
                                </div>
                                <!-- Section Block -->
                            </div>
                            <!-- Section Wrapper -->
                            <p>
                                Our brand tenders and marketing mixologists always serve
                                up unique, design-forward websites coded with today’s
                                modern technologies
                            </p>
                            <ul class=\"flex flex-col gap-5 font-semibold text-ColorBlack\">
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Reach new business opportunities or test your product
                                    ideas.
                                </li>
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Automate your processes and get data-driven business
                                    insights.
                                </li>
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Create lightweight, scalable, and easly accessible
                                    cloud solution.
                                </li>
                            </ul>
                        </div>
                        <!-- Content Block Left -->
                        <!-- Content Block Right -->
                        <div class=\"jos relative lg:order-1\" data-jos_animation=\"fade-right\">
                            <div class=\"rounded-[10px] bg-[#BEF8FC] p-[30px] lg:p-10 xl:p-[50px]\">
                                <!-- Content Image -->
                                <img src=\"";
        // line 393
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/content-img-2.jpg"), "html", null, true);
        yield "\" alt=\"content-img-1\" width=\"426\" height=\"398\" class=\"h-auto w-full rounded-[10px]\" />
                            </div>
                            <!-- Content Shape -->
                            <img src=\"";
        // line 396
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/content-shape-2.svg"), "html", null, true);
        yield "\" alt=\"content-shape-1\" width=\"107\" height=\"105\" class=\"absolute -bottom-1 -left-1\" />
                        </div>
                        <!-- Content Block Right -->
                    </div>
                    <!-- Content Area Single -->
                </div>
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Spacer -->
    </div>
    <!-- Section Background -->
</section>
<!-- Content Section End -->

<!-- Portfolio Section Start -->
<section class=\"section-portfolio\" id=\"section-projects\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Section Wrapper -->
                <div class=\"jos mb-[60px] flex flex-wrap items-end justify-between gap-8 xl:mb-20\">
                    <!-- Section Block -->
                    <div class=\"max-w-[550px]\">
                        <h2>We create world-class web design, & branding</h2>
                    </div>
                    <!-- Section Block -->
                    <a href=\"";
        // line 425
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>See more works</span></a>
                </div>
                <!-- Section Wrapper -->

                <!-- Portfolio List -->
                <div class=\"grid gap-8 md:grid-cols-2 lg:gap-10 xl:gap-[60px]\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 435
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-img-1\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 text-ColorBlack lg:flex-nowrap xl:mb-7\">
                                    <a href=\"";
        // line 439
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue xl:text-2xl\">App — The power of communication</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <a href=\"";
        // line 442
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"";
        // line 452
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-img-2\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 text-ColorBlack lg:flex-nowrap xl:mb-7\">
                                    <a href=\"";
        // line 456
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue xl:text-2xl\">Website — The future lifestyle platform.</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <a href=\"";
        // line 459
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Portfolio Shape - 2 -->
        <div class=\"absolute right-0 top-0 -z-10\">
            <img src=\"";
        // line 474
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/portfolio-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"portfolio-1-shape-1\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
<!-- Portfolio Section End -->

<!-- Testimonial Section Start -->
<section class=\"section-testimonial\" id=\"section-testimonial\">
    <!-- Section Background -->
    <div class=\"bg-ColorOffWhite\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[625px]\">
                        <h2 class=\"text-center\">
                            Most of our satisfied clients leave their feedback
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->

                <!-- Testimonial Area -->
                <div class=\"grid items-center gap-10 lg:grid-cols-2 xl:gap-20 xxl:grid-cols-[1.1fr_minmax(0,_1fr)]\">
                    <img src=\"";
        // line 502
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/testimonial-image-1.jpg"), "html", null, true);
        yield "\" alt=\"testimonial-image-1\" width=\"636\" height=\"446\" class=\"jos h-auto w-full rounded-2xl\" data-jos_animation=\"fade-right\" />
                    <div class=\"jos flex flex-col text-ColorBlack\" data-jos_animation=\"fade-left\">
                        <img src=\"";
        // line 504
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/icons/icon-blue-quote-right-reverse.svg"), "html", null, true);
        yield "\" alt=\"icon-blue-quote-right-reverse\" width=\"90\" height=\"60\" class=\"h-auto w-10 xl:w-[90px]\" />
                        <p class=\"mt-[30px] text-xl font-semibold leading-[1.33] -tracking-[0.5px] lg:text-2xl\">
                            They’re probably one of the easiest vendors I’ve ever
                            worked with in the digital space. They have our best
                            interests in mind. The team went the extra mile in
                            negotiating costs and delivering within a flexible scope.
                            They’re customer focused and strong in terms of
                            development quality.
                        </p>
                        <div class=\"mb-8 lg:mb-[50px]\">
                            <span class=\"block text-xl font-semibold\">Dominika Drońska</span>
                            <span class=\"block\">Senior Digital Marketing Manager, Abbey Road
                                Studios</span>
                        </div>
                        <a href=\"";
        // line 518
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"group text-base font-bold capitalize leading-[1.5] hover:text-ColorBlue\">Read more reviews
                            <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                    </div>
                </div>
                <!-- Testimonial Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
    <!-- Section Background -->
</section>
<!-- Testimonial Section End -->

<!-- FAQ Section Start -->
<section class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[625px]\">
                        <h2 class=\"text-center\">
                            Frequently asked questions about our digital agency
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->
                <!-- FAQ Area -->
                <div class=\"jos\">
                    <!-- Accordion List -->
                    <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                        <!-- Accordion Item -->
                        <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What is a digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What services does a digital agency provide?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Hiring a digital agency vs hiring in-house: What is
                                    the difference?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What questions should you ask when interviewing a
                                    digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                    </ul>
                    <!-- Accordion List -->

                    <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                        <a href=\"";
        // line 685
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                    </div>
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- FAQ Shape - 1 -->
        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"";
        // line 696
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/faq-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"service-section-shape\" width=\"390\" height=\"507\" />
        </div>
        <!-- FAQ Shape - 2 -->
        <div class=\"absolute bottom-0 right-0 -z-10\">
            <img src=\"";
        // line 700
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/faq-1-shape-2.svg"), "html", null, true);
        yield "\" alt=\"service-section-shape\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
<!-- FAQ Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 710
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 711
        yield "<footer class=\"section-footer\">
    <div class=\"bg-ColorBlack\">
        <!-- Footer Area Top -->
        <div class=\"relative z-10\">
            <!-- Footer Top Spacing -->
            <div class=\"pb-[60px] pt-20 lg:pb-20 lg:pt-[100px] xl:pt-[120px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Wrapper -->
                    <div class=\"flex flex-wrap items-center justify-center text-center lg:text-left lg:justify-between gap-8\">
                        <!-- Section Block -->
                        <div class=\"max-w-[400px] md:max-w-[500px] lg:max-w-[550px]\">
                            <h2 class=\"text-white\">
                                Ready to grow your business digitally?
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <a href=\"";
        // line 728
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Let's start the project</span></a>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Top Spacing -->

            <!-- CTA Shape -->
            <div class=\"absolute right-[9%] top-8 -z-10 hidden xxl:block\">
                <img src=\"";
        // line 738
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/cta-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"cta-1-shape-1\" width=\"115\" height=\"130\" />
            </div>
        </div>
        <!-- Footer Area Top -->

        <!-- Horizontal Line Separator -->
        <div class=\"horizontal-line bg-white\"></div>
        <!-- Horizontal Line Separator -->

        <!-- Footer Area Center -->
        <div class=\"text-white\">
            <!-- Footer Center Spacing -->
            <div class=\"py-[60px] lg:py-20\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Footer Widget List -->
                    <div class=\"grid gap-x-16 gap-y-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1fr_repeat(3,_auto)] xl:gap-x-24 xxl:gap-x-[134px]\">
                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-3 lg:col-span-1\">
                            <!-- Footer Logo -->
                            <a href=\"";
        // line 758
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\">
                                <img src=\"";
        // line 759
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-light.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
                            </a>
                            <!-- Footer Content -->
                            <div>
                                <!-- Footer About Text -->
                                <div class=\"lg:max-w-[416px]\">
                                    We are strategic & creative digital agency who are
                                    focused on user experience, mobile, social, data
                                    gathering and promotional offerings.
                                </div>
                                <!-- Footer Mail -->
                                <a href=\"mailto:yourdemo@email.com\" class=\"my-6 block underline-offset-4 transition-all duration-300 hover:underline\">yourdemo@email.com</a>
                                <!-- Footer Social Link -->
                                <div class=\"flex flex-wrap gap-5\">
                                    <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"twitter\">
                                        <i class=\"fa-brands fa-x-twitter\"></i>
                                    </a>
                                    <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"facebook\">
                                        <i class=\"fa-brands fa-facebook-f\"></i>
                                    </a>
                                    <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"instagram\">
                                        <i class=\"fa-brands fa-instagram\"></i>
                                    </a>
                                    <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"github\">
                                        <i class=\"fa-brands fa-github\"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- Footer Content -->
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Widget Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Primary Pages
                            </div>
                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"";
        // line 800
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Home</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 803
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">About Us</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 806
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("services");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Services</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 809
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pricing");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">pricing</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 812
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Utility pages
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"";
        // line 829
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Signup</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 832
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Login</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 835
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("error404");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">404 Not found</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 838
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("resetPassword");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Password Reset</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item-->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Resources
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Support</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Privacy policy</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Terms & Conditions</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Strategic finance</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Video guide</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->
                    </div>
                    <!-- Footer Widget List -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Center Spacing -->
        </div>
        <!-- Footer Area Center -->

        <!-- Footer Bottom -->
        <div class=\"bg-white bg-opacity-5\">
            <!-- Footer Bottom Spacing -->
            <div class=\"py-[18px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"text-center text-white text-opacity-80\">
                        &copy; Copyright 2024, All Rights Reserved by PixcelsThemes
                    </div>
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Bottom Spacing -->
        </div>
        <!-- Footer Bottom -->
    </div>
</footer>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "OnePage/indexOnePage1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  1105 => 838,  1099 => 835,  1093 => 832,  1087 => 829,  1067 => 812,  1061 => 809,  1055 => 806,  1049 => 803,  1043 => 800,  999 => 759,  995 => 758,  972 => 738,  959 => 728,  940 => 711,  933 => 710,  918 => 700,  911 => 696,  897 => 685,  727 => 518,  710 => 504,  705 => 502,  674 => 474,  656 => 459,  650 => 456,  643 => 452,  630 => 442,  624 => 439,  617 => 435,  604 => 425,  572 => 396,  566 => 393,  513 => 343,  507 => 340,  455 => 291,  433 => 272,  420 => 262,  416 => 261,  398 => 246,  385 => 236,  381 => 235,  363 => 220,  350 => 210,  346 => 209,  328 => 194,  315 => 184,  311 => 183,  265 => 140,  259 => 137,  253 => 134,  247 => 131,  241 => 128,  235 => 125,  229 => 122,  223 => 119,  217 => 116,  211 => 113,  185 => 90,  177 => 85,  158 => 69,  116 => 29,  109 => 28,  89 => 13,  85 => 12,  81 => 10,  74 => 9,  63 => 4,  56 => 3,  39 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout2.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue sm:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden sm:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 



{% block content %}

  <!-- Hero Section Start -->
  <section class=\"section-hero\">
    <div class=\"relative z-10 overflow-hidden bg-[#FAF9F5]\">
        <!-- Section Space -->
        <div class=\"pb-[60px] pt-28 md:pb-20 md:pt-36 lg:pb-[100px] lg:pt-[150px] xxl:pb-[120px] xxl:pt-[185px]\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Hero Area -->
                <div class=\"grid gap-10 lg:grid-cols-2 xxl:grid-cols-[1.1fr_minmax(0,_1fr)]\">
                    <!-- Hero Content Block -->
                    <div class=\"jos\">
                        <div class=\"has-container-custom\">
                            <h1 class=\"mb-6\">
                                We focus on growing your brand online
                            </h1>
                            <p>
                                Build world-class digital products with a team of
                                design, development & strategy experts. All in one
                                place. We can provide your business with a variety of
                                digital solutions.
                            </p>
                            <form action=\"#\" method=\"post\" class=\"relative mx-auto flex w-full items-center sm:w-[80%] lg:mx-0 lg:mt-5 lg:max-w-md\">
                                <input type=\"email\" placeholder=\"Enter your email\" class=\"w-full rounded-[50px] border border-ColorBlack bg-white px-5 py-[15px] pr-40 text-base font-semibold text-opacity-50 outline-none\" />
                                <button type=\"submit\" class=\"btn is-blue is-rounded absolute right-[5px] py-[10px]\">
                                    Subscribe
                                </button>
                            </form>
                            <div class=\"mt-5 text-sm leading-6 md:justify-normal\">
                                <span class=\"mr-2 inline-block text-lg text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                <span class=\"opacity-50\">No credit card is required. You can cancel
                                    anytime</span>
                            </div>
                        </div>
                    </div>
                    <!-- Hero Content Block -->

                    <!-- Hero Image Block -->
                    <div class=\"jos\">
                        <div class=\"relative flex items-center justify-center\">
                            <img src=\"{{ asset('assets/img/th-1/hero-img.jpg') }}\" alt=\"hero image\" width=\"600\" height=\"579\" class=\"h-auto w-full\" />
                            <a data-fslightbox=\"gallery\" href=\"https://www.youtube.com/watch?v=3nQNiWdeH2Q\" class=\"group group absolute flex h-[100px] w-[100px] items-center justify-center rounded-[50%] bg-white text-ColorBlue\" aria-label=\"video-play\">
                                <span class=\"text-2xl transition-all duration-300 ease-linear group-hover:scale-110\"><i class=\"fa-solid fa-play\"></i></span>
                            </a>
                        </div>
                    </div>
                    <!-- Hero Image Block -->
                </div>
                <!-- Hero Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Hero Shape - 1 -->
        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/hero-1-shape-1.svg') }}\" alt=\"hero-shape-1\" width=\"607\" height=\"792\" class=\"\" />
        </div>

        <!-- Hero Shape - 2 -->
        <div class=\"absolute bottom-0 right-0 -z-[1]\">
            <img src=\"{{ asset('assets/img/elements/hero-1-shape-2.svg') }}\" alt=\"hero-shape-2\" width=\"607\" height=\"792\" />
        </div>
    </div>
</section>
<!-- Hero Section End -->

<!-- Brand Section Start -->
<div class=\"section-brand\">
    <div class=\"jos\">
        <!-- Section Space -->
        <div class=\"py-[60px] md:py-20 lg:py-[100px]\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <div class=\"mx-auto mb-10 max-w-[80%] text-center text-xl font-semibold leading-[1.4] opacity-70 md:mb-16 lg:mb-20 lg:max-w-2xl\">
                    From start-ups to Fortune 500, we partner with brands of all
                    sizes
                </div>
                <!-- Brand Slider -->
                <div class=\"swiper brand-slider\">
                    <!-- Additional required wrapper -->
                    <div class=\"swiper-wrapper\">
                        <!-- Slides -->
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-1.png') }}\" alt=\"brand-1\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-2.png') }}\" alt=\"brand-2\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-3.png') }}\" alt=\"brand-3\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-4.png') }}\" alt=\"brand-4\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                        <div class=\"swiper-slide\">
                            <img src=\"{{ asset('assets/img/th-1/brand-5.png') }}\" alt=\"brand-5\" width=\"186\" height=\"46\" class=\"h-auto w-fit\" />
                        </div>
                    </div>
                </div>
                <!-- Brand Slider -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- Brand Section End -->

<!-- Horizontal Line Separator -->
<div class=\"horizontal-line bg-ColorBlack\"></div>
<!-- Horizontal Line Separator -->

<!-- Service Section Start -->
<section class=\"section-service\" id=\"section-services\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[590px]\">
                        <h2 class=\"text-center\">
                            All the digital services that are convenient for you
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->

                <!-- Service List -->
                <div class=\"grid gap-6 sm:grid-cols-2\">
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"{{ asset('assets/img/icons/icon-black-service-1.svg') }}\" alt=\"icon-service-1\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"{{ asset('assets/img/icons/icon-blue-service-1.svg') }}\" alt=\"icon-service-1\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Branding & Digital Strategies
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Brand strategy is all about developing a unique
                                        identity that distinguishes your business from
                                    </p>
                                    <a href=\"{{ path('serviceDetails') }}\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"{{ asset('assets/img/icons/icon-black-service-2.svg') }}\" alt=\"icon-service-2\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"{{ asset('assets/img/icons/icon-blue-service-2.svg') }}\" alt=\"icon-service-2\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Web Design & App Development
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Web design & development is an umbrella term that
                                        describes the process of creating a website
                                    </p>
                                    <a href=\"{{ path('serviceDetails') }}\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.6\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"{{ asset('assets/img/icons/icon-black-service-3.svg') }}\" alt=\"icon-service-3\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"{{ asset('assets/img/icons/icon-blue-service-3.svg') }}\" alt=\"icon-service-3\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Results-Driven Digital Marketing
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Digital marketing potential customers using the
                                        internet & other forms of digital communication
                                    </p>
                                    <a href=\"{{ path('serviceDetails') }}\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                    <!-- Service Item -->
                    <div class=\"jos\" data-jos_delay=\"0.9\">
                        <div class=\"group rounded-[10px] border border-[#E6E6E6] bg-white p-8 transition-all duration-300 ease-in-out hover:border-ColorOffWhite hover:bg-ColorOffWhite lg:p-10 h-full\">
                            <div class=\"flex flex-col gap-x-10 gap-y-6 sm:gap-y-8 lg:flex-row\">
                                <div class=\"relative mx-auto flex w-16 items-center justify-center lg:w-[98px]\">
                                    <img src=\"{{ asset('assets/img/icons/icon-black-service-4.svg') }}\" alt=\"icon-service-4\" width=\"98\" height=\"100\" class=\"opcity-100 h-auto w-full transition-all duration-300 ease-in-out group-hover:opacity-0\" />
                                    <img src=\"{{ asset('assets/img/icons/icon-blue-service-4.svg') }}\" alt=\"icon-service-4\" width=\"98\" height=\"100\" class=\"absolute h-auto w-full opacity-0 transition-all duration-300 ease-in-out group-hover:opacity-100\" />
                                </div>
                                <div class=\"flex-1 text-center lg:text-left\">
                                    <div class=\"mb-4 text-xl font-semibold leading-[1.33] -tracking-[0.5px] text-ColorBlack lg:text-2xl\">
                                        Custom Software Development
                                    </div>
                                    <p class=\"mb-5 line-clamp-2 text-ColorBlack/80\">
                                        Custom Software Development is the process of
                                        conceptualizing, designing, building & deploying
                                    </p>
                                    <a href=\"{{ path('serviceDetails') }}\" class=\"inline-flex items-center gap-x-2 text-base font-bold text-ColorBlack group-hover:text-ColorBlue\">Find out more
                                        <span class=\"transition-all duration-300 ease-in-out group-hover:translate-x-2\">
                                            <i class=\"fa-solid fa-arrow-right\"></i>
                                        </span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Service Item -->
                </div>
                <!-- Service List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Service Shape -->
        <div class=\"absolute bottom-0 left-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/service-1-shape-1.svg') }}\" alt=\"service-section-shape\" width=\"390\" height=\"507\" />
        </div>
        <!-- Service Shape -->
    </div>
</section>
<!-- Service Section End -->

<!-- Content Section Start -->
<section class=\"section-content\" id=\"section-about\">
    <!-- Section Background -->
    <div class=\"bg-ColorOffWhite\">
        <!-- Section Spacer -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <div class=\"flex flex-col gap-y-20 lg:gap-y-[100px] xl:gap-y-[120px]\">
                    <!-- Content Area Single -->
                    <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-24 xl:grid-cols-[1.2fr_minmax(0,_1fr)] xl:gap-[135px]\">
                        <!-- Content Block Left -->
                        <div class=\"jos\" data-jos_animation=\"fade-right\">
                            <!-- Section Wrapper -->
                            <div>
                                <!-- Section Block -->
                                <div class=\"mb-5\">
                                    <h2>
                                        Boost the effectiveness of your promotions as well
                                        as polish your branding
                                    </h2>
                                </div>
                                <!-- Section Block -->
                            </div>
                            <!-- Section Wrapper -->
                            <p>
                                SINCE 1998, we transform bold business ideas into
                                exceptional digital products. We ideate, design, and
                                develop data-driven digital products made to answer
                                business challenges.
                            </p>
                            <p>
                                We offer 360° services to smoothly guide you on your way
                                to creating a seamless digital masterpiece projects on
                                budget and on time.
                            </p>
                        </div>
                        <!-- Content Block Left -->
                        <!-- Content Block Right -->
                        <div class=\"jos relative\" data-jos_animation=\"fade-left\">
                            <div class=\"rounded-[10px] bg-[#FCEDCF] p-[30px] lg:p-10 xl:p-[50px]\">
                                <!-- Content Image -->
                                <img src=\"{{ asset('assets/img/th-1/content-img-1.jpg') }}\" alt=\"content-img-1\" width=\"426\" height=\"398\" class=\"h-auto w-full rounded-[10px]\" />
                            </div>
                            <!-- Content Shape -->
                            <img src=\"{{ asset('assets/img/elements/content-shape-1.svg') }}\" alt=\"content-shape-1\" width=\"168\" height=\"61\" class=\"absolute -right-16 -top-16\" />
                        </div>
                        <!-- Content Block Right -->
                    </div>
                    <!-- Content Area Single -->

                    <!-- Content Area Single -->
                    <div class=\"grid items-center gap-10 lg:grid-cols-2 lg:gap-24 xl:grid-cols-[1fr_minmax(0,_1.2fr)] xl:gap-[135px]\">
                        <!-- Content Block Left -->
                        <div class=\"jos lg:order-2\" data-jos_animation=\"fade-left\">
                            <!-- Section Wrapper -->
                            <div>
                                <!-- Section Block -->
                                <div class=\"mb-5\">
                                    <h2>
                                        Discover the latest digital strategies & emerging
                                        ideas for business growth
                                    </h2>
                                </div>
                                <!-- Section Block -->
                            </div>
                            <!-- Section Wrapper -->
                            <p>
                                Our brand tenders and marketing mixologists always serve
                                up unique, design-forward websites coded with today’s
                                modern technologies
                            </p>
                            <ul class=\"flex flex-col gap-5 font-semibold text-ColorBlack\">
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Reach new business opportunities or test your product
                                    ideas.
                                </li>
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Automate your processes and get data-driven business
                                    insights.
                                </li>
                                <li>
                                    <span class=\"mr-3 inline-block text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                    Create lightweight, scalable, and easly accessible
                                    cloud solution.
                                </li>
                            </ul>
                        </div>
                        <!-- Content Block Left -->
                        <!-- Content Block Right -->
                        <div class=\"jos relative lg:order-1\" data-jos_animation=\"fade-right\">
                            <div class=\"rounded-[10px] bg-[#BEF8FC] p-[30px] lg:p-10 xl:p-[50px]\">
                                <!-- Content Image -->
                                <img src=\"{{ asset('assets/img/th-1/content-img-2.jpg') }}\" alt=\"content-img-1\" width=\"426\" height=\"398\" class=\"h-auto w-full rounded-[10px]\" />
                            </div>
                            <!-- Content Shape -->
                            <img src=\"{{ asset('assets/img/elements/content-shape-2.svg') }}\" alt=\"content-shape-1\" width=\"107\" height=\"105\" class=\"absolute -bottom-1 -left-1\" />
                        </div>
                        <!-- Content Block Right -->
                    </div>
                    <!-- Content Area Single -->
                </div>
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Spacer -->
    </div>
    <!-- Section Background -->
</section>
<!-- Content Section End -->

<!-- Portfolio Section Start -->
<section class=\"section-portfolio\" id=\"section-projects\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Section Wrapper -->
                <div class=\"jos mb-[60px] flex flex-wrap items-end justify-between gap-8 xl:mb-20\">
                    <!-- Section Block -->
                    <div class=\"max-w-[550px]\">
                        <h2>We create world-class web design, & branding</h2>
                    </div>
                    <!-- Section Block -->
                    <a href=\"{{ path('portfolio') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>See more works</span></a>
                </div>
                <!-- Section Wrapper -->

                <!-- Portfolio List -->
                <div class=\"grid gap-8 md:grid-cols-2 lg:gap-10 xl:gap-[60px]\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\" data-jos_delay=\"0\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-img-1.jpg') }}\" alt=\"portfolio-img-1\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 text-ColorBlack lg:flex-nowrap xl:mb-7\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue xl:text-2xl\">App — The power of communication</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <a href=\"{{ path('portfolioDetails') }}\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\" data-jos_delay=\"0.3\">
                        <div class=\"group\">
                            <div class=\"overflow-hidden rounded-[10px]\">
                                <img src=\"{{ asset('assets/img/th-1/portfolio-img-2.jpg') }}\" alt=\"portfolio-img-2\" width=\"617\" height=\"450\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                            </div>
                            <div class=\"mt-6\">
                                <div class=\"mb-5 flex flex-wrap justify-between gap-5 text-ColorBlack lg:flex-nowrap xl:mb-7\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"text-xl font-semibold leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue xl:text-2xl\">Website — The future lifestyle platform.</a>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <a href=\"{{ path('portfolioDetails') }}\" class=\"text-base font-bold capitalize leading-[1.5] group-hover:text-ColorBlue\">View work
                                    <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- Portfolio Shape - 2 -->
        <div class=\"absolute right-0 top-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/portfolio-1-shape-1.svg') }}\" alt=\"portfolio-1-shape-1\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
<!-- Portfolio Section End -->

<!-- Testimonial Section Start -->
<section class=\"section-testimonial\" id=\"section-testimonial\">
    <!-- Section Background -->
    <div class=\"bg-ColorOffWhite\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-custom\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[625px]\">
                        <h2 class=\"text-center\">
                            Most of our satisfied clients leave their feedback
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->

                <!-- Testimonial Area -->
                <div class=\"grid items-center gap-10 lg:grid-cols-2 xl:gap-20 xxl:grid-cols-[1.1fr_minmax(0,_1fr)]\">
                    <img src=\"{{ asset('assets/img/th-1/testimonial-image-1.jpg') }}\" alt=\"testimonial-image-1\" width=\"636\" height=\"446\" class=\"jos h-auto w-full rounded-2xl\" data-jos_animation=\"fade-right\" />
                    <div class=\"jos flex flex-col text-ColorBlack\" data-jos_animation=\"fade-left\">
                        <img src=\"{{ asset('assets/img/icons/icon-blue-quote-right-reverse.svg') }}\" alt=\"icon-blue-quote-right-reverse\" width=\"90\" height=\"60\" class=\"h-auto w-10 xl:w-[90px]\" />
                        <p class=\"mt-[30px] text-xl font-semibold leading-[1.33] -tracking-[0.5px] lg:text-2xl\">
                            They’re probably one of the easiest vendors I’ve ever
                            worked with in the digital space. They have our best
                            interests in mind. The team went the extra mile in
                            negotiating costs and delivering within a flexible scope.
                            They’re customer focused and strong in terms of
                            development quality.
                        </p>
                        <div class=\"mb-8 lg:mb-[50px]\">
                            <span class=\"block text-xl font-semibold\">Dominika Drońska</span>
                            <span class=\"block\">Senior Digital Marketing Manager, Abbey Road
                                Studios</span>
                        </div>
                        <a href=\"{{ path('portfolioDetails') }}\" class=\"group text-base font-bold capitalize leading-[1.5] hover:text-ColorBlue\">Read more reviews
                            <span class=\"inline-block transition-all duration-150 group-hover:translate-x-2\"><i class=\"fa-solid fa-arrow-right\"></i></span></a>
                    </div>
                </div>
                <!-- Testimonial Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
    <!-- Section Background -->
</section>
<!-- Testimonial Section End -->

<!-- FAQ Section Start -->
<section class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Section Content Wrapper -->
                <div class=\"jos mb-[60px] xl:mb-20\">
                    <!-- Section Content Block -->
                    <div class=\"mx-auto max-w-[625px]\">
                        <h2 class=\"text-center\">
                            Frequently asked questions about our digital agency
                        </h2>
                    </div>
                    <!-- Section Content Block -->
                </div>
                <!-- Section Content Wrapper -->
                <!-- FAQ Area -->
                <div class=\"jos\">
                    <!-- Accordion List -->
                    <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                        <!-- Accordion Item -->
                        <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What is a digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What services does a digital agency provide?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Hiring a digital agency vs hiring in-house: What is
                                    the difference?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What questions should you ask when interviewing a
                                    digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                    </ul>
                    <!-- Accordion List -->

                    <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                        <a href=\"{{ path('contact') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                    </div>
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->

        <!-- FAQ Shape - 1 -->
        <div class=\"absolute left-0 top-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/faq-1-shape-1.svg') }}\" alt=\"service-section-shape\" width=\"390\" height=\"507\" />
        </div>
        <!-- FAQ Shape - 2 -->
        <div class=\"absolute bottom-0 right-0 -z-10\">
            <img src=\"{{ asset('assets/img/elements/faq-1-shape-2.svg') }}\" alt=\"service-section-shape\" width=\"467\" height=\"609\" />
        </div>
    </div>
</section>
<!-- FAQ Section End -->

{% endblock %} 



{% block footer %}
<footer class=\"section-footer\">
    <div class=\"bg-ColorBlack\">
        <!-- Footer Area Top -->
        <div class=\"relative z-10\">
            <!-- Footer Top Spacing -->
            <div class=\"pb-[60px] pt-20 lg:pb-20 lg:pt-[100px] xl:pt-[120px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Wrapper -->
                    <div class=\"flex flex-wrap items-center justify-center text-center lg:text-left lg:justify-between gap-8\">
                        <!-- Section Block -->
                        <div class=\"max-w-[400px] md:max-w-[500px] lg:max-w-[550px]\">
                            <h2 class=\"text-white\">
                                Ready to grow your business digitally?
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <a href=\"{{ path('portfolio') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Let's start the project</span></a>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Top Spacing -->

            <!-- CTA Shape -->
            <div class=\"absolute right-[9%] top-8 -z-10 hidden xxl:block\">
                <img src=\"{{ asset('assets/img/elements/cta-1-shape-1.svg') }}\" alt=\"cta-1-shape-1\" width=\"115\" height=\"130\" />
            </div>
        </div>
        <!-- Footer Area Top -->

        <!-- Horizontal Line Separator -->
        <div class=\"horizontal-line bg-white\"></div>
        <!-- Horizontal Line Separator -->

        <!-- Footer Area Center -->
        <div class=\"text-white\">
            <!-- Footer Center Spacing -->
            <div class=\"py-[60px] lg:py-20\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Footer Widget List -->
                    <div class=\"grid gap-x-16 gap-y-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1fr_repeat(3,_auto)] xl:gap-x-24 xxl:gap-x-[134px]\">
                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-3 lg:col-span-1\">
                            <!-- Footer Logo -->
                            <a href=\"{{ path('home') }}\">
                                <img src=\"{{ asset('assets/img/logo-blue-light.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
                            </a>
                            <!-- Footer Content -->
                            <div>
                                <!-- Footer About Text -->
                                <div class=\"lg:max-w-[416px]\">
                                    We are strategic & creative digital agency who are
                                    focused on user experience, mobile, social, data
                                    gathering and promotional offerings.
                                </div>
                                <!-- Footer Mail -->
                                <a href=\"mailto:yourdemo@email.com\" class=\"my-6 block underline-offset-4 transition-all duration-300 hover:underline\">yourdemo@email.com</a>
                                <!-- Footer Social Link -->
                                <div class=\"flex flex-wrap gap-5\">
                                    <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"twitter\">
                                        <i class=\"fa-brands fa-x-twitter\"></i>
                                    </a>
                                    <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"facebook\">
                                        <i class=\"fa-brands fa-facebook-f\"></i>
                                    </a>
                                    <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"instagram\">
                                        <i class=\"fa-brands fa-instagram\"></i>
                                    </a>
                                    <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"github\">
                                        <i class=\"fa-brands fa-github\"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- Footer Content -->
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Widget Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Primary Pages
                            </div>
                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"{{ path('home') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Home</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('about') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">About Us</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('services') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Services</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('pricing') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">pricing</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('contact') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Utility pages
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"{{ path('signup') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Signup</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('login') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Login</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('error404') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">404 Not found</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('resetPassword') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Password Reset</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item-->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Resources
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Support</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Privacy policy</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Terms & Conditions</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Strategic finance</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Video guide</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->
                    </div>
                    <!-- Footer Widget List -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Center Spacing -->
        </div>
        <!-- Footer Area Center -->

        <!-- Footer Bottom -->
        <div class=\"bg-white bg-opacity-5\">
            <!-- Footer Bottom Spacing -->
            <div class=\"py-[18px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"text-center text-white text-opacity-80\">
                        &copy; Copyright 2024, All Rights Reserved by PixcelsThemes
                    </div>
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Bottom Spacing -->
        </div>
        <!-- Footer Bottom -->
    </div>
</footer>
{% endblock %} ", "OnePage/indexOnePage1.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\OnePage\\indexOnePage1.html.twig");
    }
}
