<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/footer.html.twig */
class __TwigTemplate_6c8e3cf465b5e22267a453b9c74adc56 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/footer.html.twig"));

        // line 1
        yield "<footer class=\"section-footer\">
    <div class=\"bg-ColorBlack\">
        <!-- Footer Area Top -->
        <div class=\"relative z-10\">
            <!-- Footer Top Spacing -->
            <div class=\"pb-[60px] pt-20 lg:pb-20 lg:pt-[100px] xl:pt-[120px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Wrapper -->
                    <div class=\"flex flex-wrap items-center justify-center text-center lg:text-left lg:justify-between gap-8\">
                        <!-- Section Block -->
                        <div class=\"max-w-[400px] md:max-w-[500px] lg:max-w-[550px]\">
                            <h2 class=\"text-white\">
                                Ready to grow your business digitally?
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <a href=\"";
        // line 18
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Let's start the project</span></a>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Top Spacing -->

            <!-- CTA Shape -->
            <div class=\"absolute right-[9%] top-8 -z-10 hidden xxl:block\">
                <img src=\"";
        // line 28
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/elements/cta-1-shape-1.svg"), "html", null, true);
        yield "\" alt=\"cta-1-shape-1\" width=\"115\" height=\"130\" />
            </div>
        </div>
        <!-- Footer Area Top -->

        <!-- Horizontal Line Separator -->
        <div class=\"horizontal-line bg-white\"></div>
        <!-- Horizontal Line Separator -->

        <!-- Footer Area Center -->
        <div class=\"text-white\">
            <!-- Footer Center Spacing -->
            <div class=\"py-[60px] lg:py-20\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Footer Widget List -->
                    <div class=\"grid gap-x-16 gap-y-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1fr_repeat(3,_auto)] xl:gap-x-24 xxl:gap-x-[134px]\">
                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-3 lg:col-span-1\">
                            <!-- Footer Logo -->
                            <a href=\"";
        // line 48
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\">
                                <img src=\"";
        // line 49
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-light.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
                            </a>
                            <!-- Footer Content -->
                            <div>
                                <!-- Footer About Text -->
                                <div class=\"lg:max-w-[416px]\">
                                    We are strategic & creative digital agency who are
                                    focused on user experience, mobile, social, data
                                    gathering and promotional offerings.
                                </div>
                                <!-- Footer Mail -->
                                <a href=\"mailto:yourdemo@email.com\" class=\"my-6 block underline-offset-4 transition-all duration-300 hover:underline\">yourdemo@email.com</a>
                                <!-- Footer Social Link -->
                                <div class=\"flex flex-wrap gap-5\">
                                    <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"twitter\">
                                        <i class=\"fa-brands fa-x-twitter\"></i>
                                    </a>
                                    <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"facebook\">
                                        <i class=\"fa-brands fa-facebook-f\"></i>
                                    </a>
                                    <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"instagram\">
                                        <i class=\"fa-brands fa-instagram\"></i>
                                    </a>
                                    <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"github\">
                                        <i class=\"fa-brands fa-github\"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- Footer Content -->
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Widget Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Primary Pages
                            </div>
                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"";
        // line 90
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Home</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 93
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">About Us</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 96
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("services");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Services</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 99
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pricing");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">pricing</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 102
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Utility pages
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"";
        // line 119
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Signup</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 122
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Login</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 125
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("error404");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">404 Not found</a>
                                </li>
                                <li>
                                    <a href=\"";
        // line 128
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("resetPassword");
        yield "\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Password Reset</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item-->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Resources
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Support</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Privacy policy</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Terms & Conditions</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Strategic finance</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Video guide</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->
                    </div>
                    <!-- Footer Widget List -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Center Spacing -->
        </div>
        <!-- Footer Area Center -->

        <!-- Footer Bottom -->
        <div class=\"bg-white bg-opacity-5\">
            <!-- Footer Bottom Spacing -->
            <div class=\"py-[18px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"text-center text-white text-opacity-80\">
                        &copy; Copyright 2024, All Rights Reserved by Pixcels Themes
                    </div>
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Bottom Spacing -->
        </div>
        <!-- Footer Bottom -->
    </div>
</footer>";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "partials/footer.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  206 => 128,  200 => 125,  194 => 122,  188 => 119,  168 => 102,  162 => 99,  156 => 96,  150 => 93,  144 => 90,  100 => 49,  96 => 48,  73 => 28,  60 => 18,  41 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<footer class=\"section-footer\">
    <div class=\"bg-ColorBlack\">
        <!-- Footer Area Top -->
        <div class=\"relative z-10\">
            <!-- Footer Top Spacing -->
            <div class=\"pb-[60px] pt-20 lg:pb-20 lg:pt-[100px] xl:pt-[120px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Wrapper -->
                    <div class=\"flex flex-wrap items-center justify-center text-center lg:text-left lg:justify-between gap-8\">
                        <!-- Section Block -->
                        <div class=\"max-w-[400px] md:max-w-[500px] lg:max-w-[550px]\">
                            <h2 class=\"text-white\">
                                Ready to grow your business digitally?
                            </h2>
                        </div>
                        <!-- Section Block -->
                        <a href=\"{{ path('portfolio') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Let's start the project</span></a>
                    </div>
                    <!-- Section Wrapper -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Top Spacing -->

            <!-- CTA Shape -->
            <div class=\"absolute right-[9%] top-8 -z-10 hidden xxl:block\">
                <img src=\"{{ asset('assets/img/elements/cta-1-shape-1.svg') }}\" alt=\"cta-1-shape-1\" width=\"115\" height=\"130\" />
            </div>
        </div>
        <!-- Footer Area Top -->

        <!-- Horizontal Line Separator -->
        <div class=\"horizontal-line bg-white\"></div>
        <!-- Horizontal Line Separator -->

        <!-- Footer Area Center -->
        <div class=\"text-white\">
            <!-- Footer Center Spacing -->
            <div class=\"py-[60px] lg:py-20\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Footer Widget List -->
                    <div class=\"grid gap-x-16 gap-y-10 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-[1fr_repeat(3,_auto)] xl:gap-x-24 xxl:gap-x-[134px]\">
                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-3 lg:col-span-1\">
                            <!-- Footer Logo -->
                            <a href=\"{{ path('home') }}\">
                                <img src=\"{{ asset('assets/img/logo-blue-light.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
                            </a>
                            <!-- Footer Content -->
                            <div>
                                <!-- Footer About Text -->
                                <div class=\"lg:max-w-[416px]\">
                                    We are strategic & creative digital agency who are
                                    focused on user experience, mobile, social, data
                                    gathering and promotional offerings.
                                </div>
                                <!-- Footer Mail -->
                                <a href=\"mailto:yourdemo@email.com\" class=\"my-6 block underline-offset-4 transition-all duration-300 hover:underline\">yourdemo@email.com</a>
                                <!-- Footer Social Link -->
                                <div class=\"flex flex-wrap gap-5\">
                                    <a href=\"https://twitter.com\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"twitter\">
                                        <i class=\"fa-brands fa-x-twitter\"></i>
                                    </a>
                                    <a href=\"https://www.facebook.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"facebook\">
                                        <i class=\"fa-brands fa-facebook-f\"></i>
                                    </a>
                                    <a href=\"https://www.instagram.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"instagram\">
                                        <i class=\"fa-brands fa-instagram\"></i>
                                    </a>
                                    <a href=\"https://www.github.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"flex h-[30px] w-[30px] items-center justify-center rounded-[50%] bg-white bg-opacity-5 text-sm text-white transition-all duration-300 hover:bg-ColorBlue\" aria-label=\"github\">
                                        <i class=\"fa-brands fa-github\"></i>
                                    </a>
                                </div>
                            </div>
                            <!-- Footer Content -->
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-7 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Widget Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Primary Pages
                            </div>
                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"{{ path('home') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Home</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('about') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">About Us</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('services') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Services</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('pricing') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">pricing</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('contact') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Contact</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Utility pages
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"{{ path('signup') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Signup</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('login') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Login</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('error404') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">404 Not found</a>
                                </li>
                                <li>
                                    <a href=\"{{ path('resetPassword') }}\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Password Reset</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item-->

                        <!-- Footer Widget Item -->
                        <div class=\"flex flex-col gap-y-6 md:col-span-1 lg:col-span-1\">
                            <!-- Footer Title -->
                            <div class=\"text-xl font-semibold capitalize\">
                                Resources
                            </div>
                            <!-- Footer Title -->

                            <!-- Footer Navbar -->
                            <ul class=\"flex flex-col gap-y-[10px] capitalize\">
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Support</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Privacy policy</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Terms & Conditions</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Strategic finance</a>
                                </li>
                                <li>
                                    <a href=\"https://www.example.com/\" target=\"_blank\" rel=\"noopener noreferrer\" class=\"hover:opcity-100 underline-offset-4 opacity-80 transition-all duration-300 ease-linear hover:underline\">Video guide</a>
                                </li>
                            </ul>
                        </div>
                        <!-- Footer Widget Item -->
                    </div>
                    <!-- Footer Widget List -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Center Spacing -->
        </div>
        <!-- Footer Area Center -->

        <!-- Footer Bottom -->
        <div class=\"bg-white bg-opacity-5\">
            <!-- Footer Bottom Spacing -->
            <div class=\"py-[18px]\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <div class=\"text-center text-white text-opacity-80\">
                        &copy; Copyright 2024, All Rights Reserved by Pixcels Themes
                    </div>
                </div>
                <!-- Section Container -->
            </div>
            <!-- Footer Bottom Spacing -->
        </div>
        <!-- Footer Bottom -->
    </div>
</footer>", "partials/footer.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\partials\\footer.html.twig");
    }
}
