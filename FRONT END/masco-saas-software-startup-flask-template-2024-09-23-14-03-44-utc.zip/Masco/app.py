from __init__ import app
from home import *
from pages import *
from onePage import *


if __name__ == '__main__':
    app.run(debug=True)
