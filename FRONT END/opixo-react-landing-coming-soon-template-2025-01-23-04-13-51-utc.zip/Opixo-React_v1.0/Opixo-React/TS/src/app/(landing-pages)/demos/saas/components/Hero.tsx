

import saas1 from '@/assets/images/landing/saas/saas1.png'
import IconifyIcon from '@/components/wrappers/IconifyIcon'

const Hero = () => {
  return (
    <>
      <section id="home" className="relative overflow-hidden bg-opacity-50 bg-gradient-to-r from-blue-100 to-blue-50 pb-96 pt-40">
        <div className="container relative">
          <div className="text-center">
            <div className="mt-6 flex justify-center">
              <div className="max-w-2xl">
                <h1 className="mb-10 text-5xl/tight font-bold text-gray-800">Unlimited Platform to monitor your best workflow.</h1>
                <p className="mx-auto text-base text-gray-700 lg:max-w-md">
                  Et harum quidem rerum facilis est et expedita distinctio nam libero tempore est nihil.
                </p>
              </div>
            </div>
            <div>
              <button
                className="relative mx-auto mt-10 flex items-center justify-center rounded-full bg-primary px-6 py-3.5 text-base font-medium text-white"
                data-hs-overlay="#watchvideomodal">
                <IconifyIcon icon="uil:play" className="pe-2.5 text-2xl/none" />
                Watch Video
              </button>
            </div>
          </div>
        </div>
        <div className="shape absolute -bottom-[1px] end-0 start-0 overflow-hidden text-white sm:-bottom-px">
          <svg className="h-auto w-full origin-top scale-[2.0]" viewBox="0 0 2880 48" fill="none" xmlns="http://www.w3.org/2000/svg">
            <path d="M0 48H1437.5H2880V0H2160C1442.5 52 720 0 720 0H0V48Z" fill="currentColor" />
          </svg>
        </div>
      </section>
      <div className="pb-24">
        <div className="relative z-10 mx-auto -mt-80 max-w-3xl px-6">
          <div className="hidden lg:block">
            <div className="absolute -end-5 -top-10 -z-[1] h-24 w-24 bg-[url('../images/other/dot.svg')]" />
            <div className="absolute -bottom-10 -start-5 -z-[1] h-24 w-24 bg-[url('../images/other/dot2.svg')]" />
          </div>
          <img src={saas1} alt="saas" className="h-full w-full rounded-md" />
        </div>
      </div>

      <div
        id="watchvideomodal"
        className="hs-overlay fc-modal fixed left-0 top-0 z-[60] hidden h-full min-h-full w-full items-center transition-all duration-500 hs-overlay-open:flex">
        <div className="group relative flex-col overflow-hidden rounded-md bg-white opacity-0 shadow-sm transition-[opacity] duration-500 ease-out hs-overlay-open:opacity-100 sm:mx-auto sm:w-full sm:max-w-2xl">
          <video id="VisaChipCardVideo" className="w-full" controls>
            <source src="https://www.w3schools.com/html/mov_bbb.mp4" type="video/mp4" />
            {/*Browser does not support <video> tag */}
          </video>
        </div>
      </div>
    </>
  )
}

export default Hero
