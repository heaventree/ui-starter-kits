<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/faq4.html.twig */
class __TwigTemplate_e0abcc97b44a42668d6bb92b57fc924d extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/faq4.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/faq4.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/faq4.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "

<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"grid gap-[30px] md:grid-cols-[minmax(0,0.5fr)_1fr] lg:grid-cols-[minmax(0,0.4fr)_1fr] xxl:grid-cols-[minmax(0,0.33fr)_1fr]\">
                    <div>
                        <!-- Career Tab Button Block-->
                        <div class=\"flex flex-row flex-wrap justify-center gap-3 text-ColorBlack md:flex-col md:justify-start md:gap-6\">
                            <button class=\"active tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"general-question\">
                                General Question
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"account-support\">
                                Account & Support
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"purchasing-online\">
                                Purchasing Online
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"technical-methods\">
                                Technical Methods
                            </button>
                        </div>
                        <!-- Career Tab Button Block-->
                    </div>
                    <!-- FAQ Block -->
                    <div>
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid gap-[34px]\" id=\"general-question\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"account-support\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"purchasing-online\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"technical-methods\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                    </div>
                    <!-- FAQ Block -->
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 770
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 771
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/faq4.html.twig", 771)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/faq4.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  883 => 771,  876 => 770,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}


<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"grid gap-[30px] md:grid-cols-[minmax(0,0.5fr)_1fr] lg:grid-cols-[minmax(0,0.4fr)_1fr] xxl:grid-cols-[minmax(0,0.33fr)_1fr]\">
                    <div>
                        <!-- Career Tab Button Block-->
                        <div class=\"flex flex-row flex-wrap justify-center gap-3 text-ColorBlack md:flex-col md:justify-start md:gap-6\">
                            <button class=\"active tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"general-question\">
                                General Question
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"account-support\">
                                Account & Support
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"purchasing-online\">
                                Purchasing Online
                            </button>
                            <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"technical-methods\">
                                Technical Methods
                            </button>
                        </div>
                        <!-- Career Tab Button Block-->
                    </div>
                    <!-- FAQ Block -->
                    <div>
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid gap-[34px]\" id=\"general-question\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"account-support\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"purchasing-online\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                        <!-- Accordion List -->
                        <ul class=\"tab-content grid hidden gap-[34px]\" id=\"technical-methods\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow active\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Do I have a promotional or discount code?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What kind of support do I get from any plan?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What is a digital agency?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. What services does a digital agency provide?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item accordion-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px] border-2 border-ColorBlack bg-white p-[30px]\">
                                    <!-- Accordion Header -->
                                    <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                        <button class=\"flex-1 text-left\">
                                            Q. Hiring a digital agency vs hiring in-house:
                                            What is the difference?
                                        </button>
                                        <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                            <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                            <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                        </div>
                                    </div>
                                    <!-- Accordion Header -->
                                    <!-- Accordion Body -->
                                    <div class=\"accordion-body max-w-[826px] opacity-80\">
                                        <p class=\"pt-5\">
                                            A digital agency is a company that leverages
                                            digital channels to grow their clients’ brands
                                            online. ls and technologies such as web design,
                                            digital marketing, creative design and app
                                            development.
                                        </p>
                                    </div>
                                    <!-- Accordion Body -->
                                </div>
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->
                    </div>
                    <!-- FAQ Block -->
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/faq4.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\faq4.html.twig");
    }
}
