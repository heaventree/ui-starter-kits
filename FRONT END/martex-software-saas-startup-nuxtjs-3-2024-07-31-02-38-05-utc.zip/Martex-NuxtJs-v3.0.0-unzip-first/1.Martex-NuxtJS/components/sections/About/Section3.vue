<template>
    <div id="statistic-5" class="py-100 statistic-section division">
        <div class="container">
            <!-- STATISTIC-1 WRAPPER -->
            <div class="statistic-5-wrapper">
                <div class="row row-cols-1 row-cols-md-3">
                    <!-- STATISTIC BLOCK #1 -->
                    <div class="col">
                        <div id="sb-5-1" class="wow fadeInUp">
                            <div class="statistic-block">
                                <!-- Digit -->
                                <div class="statistic-digit">
                                    <h2 class="s-44 w-700">
                                        <span class="count-element d-flex"> <ElementsCounterUp :start="0" :end="93" :duration="2000" /> k </span>
                                    </h2>
                                </div>
                                <!-- Text -->
                                <div class="statistic-txt">
                                    <h5 class="s-19 w-700">Happy Customers</h5>
                                    <p>Porta justo integer and velna vitae auctor and magna quaerat ligula</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END STATISTIC BLOCK #1 -->
                    <!-- STATISTIC BLOCK #2 -->
                    <div class="col">
                        <div id="sb-5-2" class="wow fadeInUp">
                            <div class="statistic-block">
                                <!-- Digit -->
                                <div class="statistic-digit">
                                    <h2 class="s-44 w-700">
                                        <span class="count-element d-flex"> <ElementsCounterUp :start="0" :end="13" :duration="2000" />K </span>
                                    </h2>
                                </div>
                                <!-- Text -->
                                <div class="statistic-txt">
                                    <h5 class="s-19 w-700">Positive Ratings</h5>
                                    <p>Porta justo integer and velna vitae auctor and magna quaerat ligula</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END STATISTIC BLOCK #2 -->
                    <!-- STATISTIC BLOCK #3 -->
                    <div class="col">
                        <div id="sb-5-3" class="wow fadeInUp">
                            <div class="statistic-block">
                                <!-- Digit -->
                                <div class="statistic-digit">
                                    <h2 class="s-44 w-700">
                                        <span class="count-element d-flex">
                                            <ElementsCounterUp :start="0" :end="4" :duration="2000" />
                                            /5
                                        </span>
                                    </h2>
                                </div>
                                <!-- Text -->
                                <div class="statistic-txt">
                                    <h5 class="s-19 w-700">Rating</h5>
                                    <p>Porta justo integer and velna vitae auctor and magna quaerat ligula</p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- END STATISTIC BLOCK #3 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END STATISTIC-5 WRAPPER -->
        </div>
        <!-- End container -->
    </div>
</template>
