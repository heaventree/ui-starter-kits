import { cn } from '@/helpers/cn';
import { services } from '../data';
const Services = () => {
  return <section id="service" className="py-24">
      <div className="container">
        <div className="mb-14 flex items-center justify-center">
          <div className="max-w-2xl text-center">
            <h5 className="mb-2 text-lg font-medium capitalize text-gray-800">
              Customer <span className="font-semibold text-primary">Service</span>
            </h5>
            <h2 className="mb-1 text-3xl/snug font-bold capitalize text-gray-800">Choose dashboard for every stage of your Customer journey</h2>
            <p className="text-base text-gray-600">Nemo enim ipsam voluptatem that quia voluptas aut fugit </p>
          </div>
        </div>
        <div className="grid grid-cols-1 gap-8 sm:grid-cols-2 lg:grid-cols-3">
          {services.map((service, idx) => <div className="bg-white p-6" key={idx}>
              <span className={cn('relative z-0 mb-6 inline-flex h-14 w-14', service.variant)} style={{
            borderRadius: '30% 70% 70% 30%/30% 30% 70% 70%'
          }}>
                <div className="absolute bottom-0 left-5 right-0 top-5 -z-20">{service.icon}</div>
              </span>
              <h5 className="mt-5 text-xl font-medium text-gray-800">{service.title}</h5>
              <p className="mt-4 text-base text-slate-600">{service.description}</p>
            </div>)}
        </div>
      </div>
    </section>;
};
export default Services;