<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/portfolio3.html.twig */
class __TwigTemplate_8e51eadeb9b8366385260f75021ef4eb extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/portfolio3.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/portfolio3.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/portfolio3.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Tab Button Menu -->
            <div class=\"flex flex-wrap justify-center gap-3 md:gap-6\">
                <button class=\"active tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"show-all\">
                    Show All
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"website\">
                    Website
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"branding\">
                    Branding
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"commercial\">
                    Commercial
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"digital-art\">
                    Digital Art
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"ui-ux-design\">
                    UI/UX Design
                </button>
            </div>
            <!-- Tab Button Menu -->

            <!-- Portfolio Area -->
            <div class=\"my-10 lg:my-[60xp] xl:my-20\">
                <!-- Portfolio List -->
                <div class=\"tab-content grid gap-8 sm:grid-cols-2 lg:grid-cols-3\" id=\"show-all\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 70
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-1\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 75
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 93
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-2\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 98
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 116
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-3\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 121
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 139
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-4.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-4\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 144
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Journal
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Commercial</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 162
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-5.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-5\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 167
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Book
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 185
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-6.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-6\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 190
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Strategic
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 208
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-7.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-7\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 213
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Ad Campaign
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 231
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-8.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-8\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 236
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Marketing
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"";
        // line 254
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-modern-img-9.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-modern-img-9\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"";
        // line 259
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Digital Art
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Commercial</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Portfolio Area -->

            <div class=\"flex justify-center\">
                <button class=\"btn is-blue is-rounded is-large group\">
                    View more
                </button>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 293
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 294
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/portfolio3.html.twig", 294)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/portfolio3.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  460 => 294,  453 => 293,  414 => 259,  406 => 254,  385 => 236,  377 => 231,  356 => 213,  348 => 208,  327 => 190,  319 => 185,  298 => 167,  290 => 162,  269 => 144,  261 => 139,  240 => 121,  232 => 116,  211 => 98,  203 => 93,  182 => 75,  174 => 70,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <!-- Tab Button Menu -->
            <div class=\"flex flex-wrap justify-center gap-3 md:gap-6\">
                <button class=\"active tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"show-all\">
                    Show All
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"website\">
                    Website
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"branding\">
                    Branding
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"commercial\">
                    Commercial
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"digital-art\">
                    Digital Art
                </button>
                <button class=\"tab-button btn tab-btn-blue is-rounded h-[50px]\" data-tab=\"ui-ux-design\">
                    UI/UX Design
                </button>
            </div>
            <!-- Tab Button Menu -->

            <!-- Portfolio Area -->
            <div class=\"my-10 lg:my-[60xp] xl:my-20\">
                <!-- Portfolio List -->
                <div class=\"tab-content grid gap-8 sm:grid-cols-2 lg:grid-cols-3\" id=\"show-all\">
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-1.jpg') }}\" alt=\"portfolio-modern-img-1\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-2.jpg') }}\" alt=\"portfolio-modern-img-2\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-3.jpg') }}\" alt=\"portfolio-modern-img-3\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-4.jpg') }}\" alt=\"portfolio-modern-img-4\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Journal
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Commercial</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-5.jpg') }}\" alt=\"portfolio-modern-img-5\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Book
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-6.jpg') }}\" alt=\"portfolio-modern-img-6\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Strategic
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-7.jpg') }}\" alt=\"portfolio-modern-img-7\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Ad Campaign
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-8.jpg') }}\" alt=\"portfolio-modern-img-8\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Marketing
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                    <!-- Portfolio Item -->
                    <div class=\"jos\">
                        <div class=\"group\">
                            <div class=\"hover-solid-shadow\">
                                <div class=\"overflow-hidden rounded-[10px]\">
                                    <img src=\"{{ asset('assets/img/th-1/portfolio-modern-img-9.jpg') }}\" alt=\"portfolio-modern-img-9\" width=\"406\" height=\"350\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                </div>
                            </div>
                            <div class=\"mt-8\">
                                <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] text-ColorBlack group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                    <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Digital Art
                                    </a>
                                    <span>—</span>
                                    <a href=\"#\" class=\"hover:text-ColorBlue\">Commercial</a>
                                </div>
                                <p class=\"line-clamp-2 text-base sm:max-w-[350px]\">
                                    Lectus faucibus ac sollicitudin feugiat sit. Ac tellus
                                    sit commodo duis mi interdum
                                </p>
                            </div>
                        </div>
                    </div>
                    <!-- Portfolio Item -->
                </div>
                <!-- Portfolio List -->
            </div>
            <!-- Portfolio Area -->

            <div class=\"flex justify-center\">
                <button class=\"btn is-blue is-rounded is-large group\">
                    View more
                </button>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/portfolio3.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\portfolio3.html.twig");
    }
}
