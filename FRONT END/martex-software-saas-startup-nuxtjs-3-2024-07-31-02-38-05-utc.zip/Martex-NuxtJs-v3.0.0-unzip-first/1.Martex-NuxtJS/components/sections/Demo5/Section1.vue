<template>
    <section id="hero-5" class="bg--scroll hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO TEXT -->
                <div class="col-md-6">
                    <div class="hero-5-txt wow fadeInRight">
                        <!-- Title -->
                        <h2 class="s-58 w-700">The growth accelerator for your startup</h2>
                        <!-- Text -->
                        <p class="p-lg">Mauris donec turpis suscipit sapien ociis sagittis sapien tempor a volute ligula and aliquet tortor</p>
                        <!-- Button -->
                        <a href="#banner-7" class="btn r-04 btn--theme hover--theme">Get started for free</a>
                    </div>
                </div>
                <!-- END HERO TEXT -->
                <!-- HERO IMAGE -->
                <div class="col-md-6">
                    <div class="hero-5-img wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/img-18.png" alt="hero-image" />
                    </div>
                </div>
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
        <!-- WAVE SHAPE BOTTOM -->
        <div class="wave-shape-bottom">
            <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 1440 170">
                <path fill-opacity="1" d="M0,160L120,160C240,160,480,160,720,138.7C960,117,1200,75,1320,53.3L1440,32L1440,320L1320,320C1200,320,960,320,720,320C480,320,240,320,120,320L0,320Z"></path>
            </svg>
        </div>
    </section>
    <hr class="divider" />
</template>
