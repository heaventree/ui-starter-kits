<template>
    <section class="bg--white-400 py-100 ct-04 content-section division">
        <div class="container">
            <!-- SECTION CONTENT (ROW) -->
            <div class="row d-flex align-items-center">
                <!-- TEXT BLOCK -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="txt-block left-column wow fadeInRight">
                        <!-- CONTENT BOX #1 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">1</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Simplify. Optimize. Automate</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #1 -->
                        <!-- CONTENT BOX #2 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">2</div>
                                <span class="cbox-2-line"></span>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">Enhanced Security Features</h5>
                                <p>Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #2 -->
                        <!-- CONTENT BOX #3 -->
                        <div class="cbox-2 process-step">
                            <!-- Icon -->
                            <div class="ico-wrap">
                                <div class="cbox-2-ico bg--theme color--white">3</div>
                            </div>
                            <!-- Text -->
                            <div class="cbox-2-txt">
                                <h5 class="s-22 w-700">No Personal Data Collected</h5>
                                <p class="mb-0">Ligula risus auctor tempus feugiat dolor lacinia nemo purus in lipsum purus sapien quaerat a primis viverra tellus vitae luctus dolor ipsum neque ligula quaerat</p>
                            </div>
                        </div>
                        <!-- END CONTENT BOX #3 -->
                    </div>
                </div>
                <!-- END TEXT BLOCK -->
                <!-- IMAGE BLOCK -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="img-block wow fadeInLeft">
                        <img class="img-fluid" src="/assets/images/tablet-01.png" alt="content-image" />
                    </div>
                </div>
            </div>
            <!-- END SECTION CONTENT (ROW) -->
        </div>
        <!-- End container -->
    </section>
</template>
