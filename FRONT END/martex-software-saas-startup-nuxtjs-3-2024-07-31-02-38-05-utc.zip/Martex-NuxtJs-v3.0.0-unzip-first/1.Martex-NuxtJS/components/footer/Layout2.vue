<template>
    <footer id="footer-3" class="pt-100 footer">
        <div class="container">
            <!-- FOOTER CONTENT -->
            <div class="row">
                <!-- FOOTER LOGO -->
                <div class="col-xl-3">
                    <div class="footer-info">
                        <img class="footer-logo" src="/assets/images/logo-purple.png" alt="footer-logo" />
                    </div>
                </div>
                <!-- FOOTER LINKS -->
                <div class="col-sm-4 col-md-3 col-xl-2">
                    <div class="footer-links fl-1">
                        <!-- Title -->
                        <h6 class="s-17 w-700">Company</h6>
                        <!-- Links -->
                        <ul class="foo-links clearfix">
                            <li>
                                <p><NuxtLink to="/about">About Us</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/careers">Careers</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/blog-listing">About Us</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/contacts">Contact Us</NuxtLink></p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END FOOTER LINKS -->
                <!-- FOOTER LINKS -->
                <div class="col-sm-4 col-md-3 col-xl-2">
                    <div class="footer-links fl-2">
                        <!-- Title -->
                        <h6 class="s-17 w-700">Product</h6>
                        <!-- Links -->
                        <ul class="foo-links clearfix">
                            <li>
                                <p><NuxtLink to="/features">Integration</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/reviews">Customers</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/pricing-1">Pricing</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/help-center">Help Center</NuxtLink></p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END FOOTER LINKS -->
                <!-- FOOTER LINKS -->
                <div class="col-sm-4 col-md-3 col-xl-2">
                    <div class="footer-links fl-3">
                        <!-- Title -->
                        <h6 class="s-17 w-700">Legal</h6>
                        <!-- Links -->
                        <ul class="foo-links clearfix">
                            <li>
                                <p><NuxtLink to="/terms">Terms of Use</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/privacy">Privacy Policy</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/cookies">Cookie Policy</NuxtLink></p>
                            </li>
                            <li>
                                <p><NuxtLink to="/cookies">Site Map</NuxtLink></p>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END FOOTER LINKS -->
                <!-- FOOTER LINKS -->
                <div class="col-sm-6 col-md-3">
                    <div class="footer-links fl-4">
                        <!-- Title -->
                        <h6 class="s-17 w-700">Connect With Us</h6>
                        <!-- Mail Link -->
                        <p class="footer-mail-link ico-25">
                            <a href="mailto:yourdomain@mail.com">hello@yourdomain.com</a>
                        </p>
                        <!-- Social Links -->
                        <ul class="footer-socials ico-25 text-center clearfix">
                            <li>
                                <a href="#"><span class="flaticon-facebook"></span></a>
                            </li>
                            <li>
                                <a href="#"><span class="flaticon-twitter"></span></a>
                            </li>
                            <li>
                                <a href="#"><span class="flaticon-github"></span></a>
                            </li>
                            <li>
                                <a href="#"><span class="flaticon-dribbble"></span></a>
                            </li>
                        </ul>
                    </div>
                </div>
                <!-- END FOOTER LINKS -->
            </div>
            <!-- END FOOTER CONTENT -->
            <hr />
            <!-- FOOTER DIVIDER LINE -->
            <!-- BOTTOM FOOTER -->
            <div class="bottom-footer">
                <div class="row row-cols-1 row-cols-md-2 d-flex align-items-center">
                    <!-- FOOTER COPYRIGHT -->
                    <div class="col">
                        <div class="footer-copyright">
                            <p class="p-sm">&copy; 2024 Martex. <span>All Rights Reserved</span></p>
                        </div>
                    </div>
                    <!-- FOOTER SECONDARY LINK -->
                    <div class="col">
                        <div class="bottom-secondary-link ico-15 text-end">
                            <p class="p-sm">
                                <a href="https://themeforest.net/user/dsathemes/portfolio">Made with <span class="flaticon-heart color--pink-400"></span> by @AliThemes</a>
                            </p>
                        </div>
                    </div>
                </div>
                <!-- End row -->
            </div>
            <!-- END BOTTOM FOOTER -->
        </div>
    </footer>
    <FooterGoToTop />
</template>
