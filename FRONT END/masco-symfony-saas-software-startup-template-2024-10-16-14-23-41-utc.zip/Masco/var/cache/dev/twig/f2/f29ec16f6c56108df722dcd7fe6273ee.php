<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/serviceDetails.html.twig */
class __TwigTemplate_6cb048f69378b1947d12ed27b6a3901f extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/serviceDetails.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/serviceDetails.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 11
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 25
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 26
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/serviceDetails.html.twig", 26)->unwrap()->yield(CoreExtension::merge($context, ["links" => (("<li><a href=\"" . $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("services")) . "\">Service</a></li>")]));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 29
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 30
        yield "
    <!-- Service Details Section Start -->
    <section class=\"section-service-details\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Service Details Area -->
                <div class=\"mx-auto max-w-[1080px]\">
                    <!-- Service main Image -->
                    <img src=\"";
        // line 40
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/service-main-img.jpg"), "html", null, true);
        yield "\" alt=\"service-main-img\" class=\"mb-10 h-auto w-full rounded-[10px]\" />
                    <!-- Service Rich Text -->
                    <div class=\"rich-text\">
                        <h5>What is Digital Brand Strategy?</h5>
                        <p>
                            A comprehensive plan that helps you communicate your
                            company's identity to consumers online to increase customer
                            loyalty and sales. A digital brand strategy also defines how
                            your organization wishes to be perceived by consumers.
                        </p>
                        <p>
                            What makes it unique? What do you want people to think about
                            your product or service? By creating guidelines for your
                            brand, you can ensure every interaction with consumers
                            remains consistent.
                        </p>

                        <h5>
                            How Do You Create an Effective Digital Brand Strategy?
                        </h5>
                        <p>
                            Creating an effective digital brand takes time, effort, and
                            due diligence. It's not as simple as making a logo, showing
                            up with a few dozen hashtags, and calling. Let's dive into
                            the roadmap for building a digital brand strategy with a few
                            detailed examples.
                        </p>

                        <ul class=\"font-semibold text-ColorBlack\">
                            <li class=\"mb-4 flex gap-x-3 last:mb-0\">
                                <span class=\"text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                Digital Branding – Creating your brand image through logo,
                                website design, and social media design to produce a solid
                                brand identity through digital platforms.
                            </li>
                            <li class=\"mb-4 flex gap-x-3 last:mb-0\">
                                <span class=\"text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                Digital Marketing – Promoting your existing brand image
                                through content marketing and advertising techniques to
                                impact consumers.
                            </li>
                        </ul>

                        <div class=\"my-6 grid grid-cols-1 md:grid-cols-2 gap-5\">
                            <img src=\"";
        // line 84
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/service-inner-1-img.jpg"), "html", null, true);
        yield "\" alt=\"service-inner-1-img\" width=\"532\" height=\"355\" class=\"w-full h-auto rounded-[10px]\" />
                            <img src=\"";
        // line 85
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/service-inner-2-img.jpg"), "html", null, true);
        yield "\" alt=\"service-inner-2-img\" width=\"532\" height=\"355\" class=\"w-full h-auto rounded-[10px]\" />
                        </div>

                        <h5>Digital Branding vs. Digital Marketing</h5>
                        <p>
                            It is a common misconception to confuse digital marketing
                            and digital branding. While you may think that these phrases
                            are interchangeable, there is a distinct difference.
                            Creating an effective digital brand takes time, effort, and
                            due diligence. It's not as simple as making a logo, showing
                            up with a few dozen hashtags, and calling it a day.
                        </p>

                        <h5>Are You Ready to Digitize Your Business Brand?</h5>
                        <p>
                            Now it is clear what digital branding is and what are the
                            strategies. That means it’s time for you to put it into
                            practice. There are nine ways that you can use for maximum
                            the results.
                        </p>

                        <p>
                            However, you can also try some of the strategies that you
                            think are the easiest and most important. For example, you
                            can start by creating a logo, using social media, or
                            creating a website. Keep the spirit and see you on the next
                            article!
                        </p>
                    </div>
                </div>
                <!-- Service Details Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </section>
    <!-- Service Details Section End -->

    <!-- FAQ Section Start -->
    <section class=\"section-faq\">
        <div class=\"relative z-10 overflow-hidden bg-ColorOffWhite\">
            <!-- Section Space -->
            <div class=\"section-space\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Content Wrapper -->
                    <div class=\"jos mb-[60px] xl:mb-20\">
                        <!-- Section Content Block -->
                        <div class=\"mx-auto max-w-[625px]\">
                            <h2 class=\"text-center\">
                                Frequently asked questions about our digital agency
                            </h2>
                        </div>
                        <!-- Section Content Block -->
                    </div>
                    <!-- Section Content Wrapper -->
                    <!-- FAQ Area -->
                    <div class=\"jos\">
                        <!-- Accordion List -->
                        <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack text-ColorBlack\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What is a digital agency?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What services does a digital agency provide?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. Hiring a digital agency vs hiring in-house: What is
                                        the difference?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What questions should you ask when interviewing a
                                        digital agency?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. How do digital agencies charge for their services?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->

                        <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                            <a href=\"";
        // line 276
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                        </div>
                    </div>
                    <!-- FAQ Area -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </section>
    <!-- FAQ Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 292
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 293
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/serviceDetails.html.twig", 293)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/serviceDetails.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  417 => 293,  410 => 292,  389 => 276,  195 => 85,  191 => 84,  144 => 40,  132 => 30,  125 => 29,  116 => 26,  109 => 25,  89 => 12,  85 => 11,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}
<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' with {'links': '<li><a href=\"' ~ path(\"services\") ~ '\">Service</a></li>'} %}
{% endblock %}

{% block content %}

    <!-- Service Details Section Start -->
    <section class=\"section-service-details\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- Service Details Area -->
                <div class=\"mx-auto max-w-[1080px]\">
                    <!-- Service main Image -->
                    <img src=\"{{ asset('assets/img/th-1/service-main-img.jpg') }}\" alt=\"service-main-img\" class=\"mb-10 h-auto w-full rounded-[10px]\" />
                    <!-- Service Rich Text -->
                    <div class=\"rich-text\">
                        <h5>What is Digital Brand Strategy?</h5>
                        <p>
                            A comprehensive plan that helps you communicate your
                            company's identity to consumers online to increase customer
                            loyalty and sales. A digital brand strategy also defines how
                            your organization wishes to be perceived by consumers.
                        </p>
                        <p>
                            What makes it unique? What do you want people to think about
                            your product or service? By creating guidelines for your
                            brand, you can ensure every interaction with consumers
                            remains consistent.
                        </p>

                        <h5>
                            How Do You Create an Effective Digital Brand Strategy?
                        </h5>
                        <p>
                            Creating an effective digital brand takes time, effort, and
                            due diligence. It's not as simple as making a logo, showing
                            up with a few dozen hashtags, and calling. Let's dive into
                            the roadmap for building a digital brand strategy with a few
                            detailed examples.
                        </p>

                        <ul class=\"font-semibold text-ColorBlack\">
                            <li class=\"mb-4 flex gap-x-3 last:mb-0\">
                                <span class=\"text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                Digital Branding – Creating your brand image through logo,
                                website design, and social media design to produce a solid
                                brand identity through digital platforms.
                            </li>
                            <li class=\"mb-4 flex gap-x-3 last:mb-0\">
                                <span class=\"text-xl text-ColorBlue\"><i class=\"fa-solid fa-badge-check\"></i></span>
                                Digital Marketing – Promoting your existing brand image
                                through content marketing and advertising techniques to
                                impact consumers.
                            </li>
                        </ul>

                        <div class=\"my-6 grid grid-cols-1 md:grid-cols-2 gap-5\">
                            <img src=\"{{ asset('assets/img/th-1/service-inner-1-img.jpg') }}\" alt=\"service-inner-1-img\" width=\"532\" height=\"355\" class=\"w-full h-auto rounded-[10px]\" />
                            <img src=\"{{ asset('assets/img/th-1/service-inner-2-img.jpg') }}\" alt=\"service-inner-2-img\" width=\"532\" height=\"355\" class=\"w-full h-auto rounded-[10px]\" />
                        </div>

                        <h5>Digital Branding vs. Digital Marketing</h5>
                        <p>
                            It is a common misconception to confuse digital marketing
                            and digital branding. While you may think that these phrases
                            are interchangeable, there is a distinct difference.
                            Creating an effective digital brand takes time, effort, and
                            due diligence. It's not as simple as making a logo, showing
                            up with a few dozen hashtags, and calling it a day.
                        </p>

                        <h5>Are You Ready to Digitize Your Business Brand?</h5>
                        <p>
                            Now it is clear what digital branding is and what are the
                            strategies. That means it’s time for you to put it into
                            practice. There are nine ways that you can use for maximum
                            the results.
                        </p>

                        <p>
                            However, you can also try some of the strategies that you
                            think are the easiest and most important. For example, you
                            can start by creating a logo, using social media, or
                            creating a website. Keep the spirit and see you on the next
                            article!
                        </p>
                    </div>
                </div>
                <!-- Service Details Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </section>
    <!-- Service Details Section End -->

    <!-- FAQ Section Start -->
    <section class=\"section-faq\">
        <div class=\"relative z-10 overflow-hidden bg-ColorOffWhite\">
            <!-- Section Space -->
            <div class=\"section-space\">
                <!-- Section Container -->
                <div class=\"container-default\">
                    <!-- Section Content Wrapper -->
                    <div class=\"jos mb-[60px] xl:mb-20\">
                        <!-- Section Content Block -->
                        <div class=\"mx-auto max-w-[625px]\">
                            <h2 class=\"text-center\">
                                Frequently asked questions about our digital agency
                            </h2>
                        </div>
                        <!-- Section Content Block -->
                    </div>
                    <!-- Section Content Wrapper -->
                    <!-- FAQ Area -->
                    <div class=\"jos\">
                        <!-- Accordion List -->
                        <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack text-ColorBlack\">
                            <!-- Accordion Item -->
                            <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What is a digital agency?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What services does a digital agency provide?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. Hiring a digital agency vs hiring in-house: What is
                                        the difference?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. What questions should you ask when interviewing a
                                        digital agency?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                            <!-- Accordion Item -->
                            <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                                <!-- Accordion Header -->
                                <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold\">
                                    <button class=\"flex-1 text-left\">
                                        Q. How do digital agencies charge for their services?
                                    </button>
                                    <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                        <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                        <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                    </div>
                                </div>
                                <!-- Accordion Header -->
                                <!-- Accordion Body -->
                                <div class=\"accordion-body max-w-[826px] opacity-80\">
                                    <p class=\"pt-5\">
                                        A digital agency is a company that leverages digital
                                        channels to grow their clients’ brands online. ls and
                                        technologies such as web design, digital marketing,
                                        creative design and app development.
                                    </p>
                                </div>
                                <!-- Accordion Body -->
                            </li>
                            <!-- Accordion Item -->
                        </ul>
                        <!-- Accordion List -->

                        <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                            <a href=\"{{ path('contact') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                        </div>
                    </div>
                    <!-- FAQ Area -->
                </div>
                <!-- Section Container -->
            </div>
            <!-- Section Space -->
        </div>
    </section>
    <!-- FAQ Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/serviceDetails.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\serviceDetails.html.twig");
    }
}
