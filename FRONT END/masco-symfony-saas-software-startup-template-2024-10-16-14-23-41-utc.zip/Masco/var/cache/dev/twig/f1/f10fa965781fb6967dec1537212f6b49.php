<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/faq.html.twig */
class __TwigTemplate_98abeb9e9345176666d90adf90fa6eee extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/faq.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/faq.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 8
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 9
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 11
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 25
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 26
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/faq.html.twig", 26)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 29
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 30
        yield "

<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"jos\">
                    <!-- Accordion List -->
                    <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                        <!-- Accordion Item -->
                        <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What is a digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What services does a digital agency provide?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Hiring a digital agency vs hiring in-house: What is
                                    the difference?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What questions should you ask when interviewing a
                                    digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How often should I post a blog or post on social
                                    media?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Which social media channels should my business be
                                    using?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                    </ul>
                    <!-- Accordion List -->

                    <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                        <a href=\"";
        // line 251
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                    </div>
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 267
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 268
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/faq.html.twig", 268)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/faq.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  384 => 268,  377 => 267,  356 => 251,  133 => 30,  126 => 29,  117 => 26,  110 => 25,  90 => 12,  86 => 11,  82 => 9,  75 => 8,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 


{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}


<!-- FAQ Section Start -->
<div class=\"section-faq\">
    <div class=\"relative z-10 overflow-hidden\">
        <!-- Section Space -->
        <div class=\"section-space\">
            <!-- Section Container -->
            <div class=\"container-default\">
                <!-- FAQ Area -->
                <div class=\"jos\">
                    <!-- Accordion List -->
                    <ul class=\"mx-auto max-w-[1076px] rounded-[10px] border border-ColorBlack\">
                        <!-- Accordion Item -->
                        <li class=\"accordion-item active overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What is a digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What services does a digital agency provide?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Hiring a digital agency vs hiring in-house: What is
                                    the difference?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. What questions should you ask when interviewing a
                                    digital agency?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How often should I post a blog or post on social
                                    media?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. Which social media channels should my business be
                                    using?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                        <!-- Accordion Item -->
                        <li class=\"accordion-item overflow-hidden border-b border-ColorBlack p-[30px] last:border-b-0\">
                            <!-- Accordion Header -->
                            <div class=\"accordion-header flex justify-between gap-6 text-xl font-semibold text-ColorBlack\">
                                <button class=\"flex-1 text-left\">
                                    Q. How do digital agencies charge for their services?
                                </button>
                                <div class=\"accordion-icon-1 relative flex h-5 w-5 items-center justify-center rounded-[50%] bg-ColorBlue\">
                                    <span class=\"inline-block h-0.5 w-[10px] rounded-sm bg-white\"></span>
                                    <span class=\"absolute inline-block h-[10px] w-0.5 rotate-0 rounded-sm bg-white\"></span>
                                </div>
                            </div>
                            <!-- Accordion Header -->
                            <!-- Accordion Body -->
                            <div class=\"accordion-body max-w-[826px] opacity-80\">
                                <p class=\"pt-5\">
                                    A digital agency is a company that leverages digital
                                    channels to grow their clients’ brands online. ls and
                                    technologies such as web design, digital marketing,
                                    creative design and app development.
                                </p>
                            </div>
                            <!-- Accordion Body -->
                        </li>
                        <!-- Accordion Item -->
                    </ul>
                    <!-- Accordion List -->

                    <div class=\"jos mt-[60px] flex justify-center xl:mt-20\">
                        <a href=\"{{ path('contact') }}\" class=\"btn is-blue is-rounded btn-animation is-large group\"><span>Still, have any questions? Contact us</span></a>
                    </div>
                </div>
                <!-- FAQ Area -->
            </div>
            <!-- Section Container -->
        </div>
        <!-- Section Space -->
    </div>
</div>
<!-- FAQ Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/faq.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\faq.html.twig");
    }
}
