import TopNavbar from '@/components/TopNavbar';
import { navLinks } from './data';
import Hero from './components/Hero';
import Services from './components/Services';
import Features from './components/Features';
import Pricing from './components/Pricing';
import Team from './components/Team';
import Faqs from '@/components/common/Faqs';
import Footer2 from '@/components/Footer2';
const Saas = () => {
  return <>
      <TopNavbar navLinks={navLinks} isDark />
      <Hero />
      <Services />
      <Features />
      <Pricing />
      <Team />
      <Faqs />
      <Footer2 />
    </>;
};
export default Saas;