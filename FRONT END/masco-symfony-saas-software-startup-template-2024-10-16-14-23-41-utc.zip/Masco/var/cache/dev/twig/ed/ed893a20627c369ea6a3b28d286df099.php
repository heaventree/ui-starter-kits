<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* partials/layout/layout1.html.twig */
class __TwigTemplate_e5453cc7cbfad5c2d98dd89d12dc18a5 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->parent = false;

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footerSection' => [$this, 'block_footerSection'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "partials/layout/layout1.html.twig"));

        // line 1
        yield "<!doctype html>
<html lang=\"en\">

";
        // line 4
        yield from         $this->loadTemplate("partials/head.html.twig", "partials/layout/layout1.html.twig", 4)->unwrap()->yield($context);
        // line 5
        yield "<body>
    <div class=\"page-wrapper relative z-[1] ";
        // line 6
        ((array_key_exists("bgColor", $context)) ? (yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape((isset($context["bgColor"]) || array_key_exists("bgColor", $context) ? $context["bgColor"] : (function () { throw new RuntimeError('Variable "bgColor" does not exist.', 6, $this->source); })()), "html", null, true)) : (yield "bg-white"));
        yield "\">
        <!-- Header Start -->
        
        <header class=\"site-header site-header--absolute is--white py-3\" id=\"sticky-menu\">
            <div class=\"container-default\">
                <div class=\"flex items-center justify-between gap-x-8\">
                    <!-- Header Logo -->
                    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\" class=\"\">
                    
                    ";
        // line 15
        yield from $this->unwrap()->yieldBlock('headerLogo', $context, $blocks);
        // line 17
        yield " 
                    </a>
                    <!-- Header Logo -->
        
                    <!-- Header Navigation -->
                    <div class=\"menu-block-wrapper\">
                        <div class=\"menu-overlay\"></div>
                        <nav class=\"menu-block\" id=\"append-menu-header\">
                            <div class=\"mobile-menu-head\">
                                <div class=\"go-back\">
                                    <i class=\"fa-solid fa-angle-left\"></i>
                                </div>
                                <div class=\"current-menu-title\"></div>
                                <div class=\"mobile-menu-close\">&times;</div>
                            </div>
                            <ul class=\"site-menu-main\">
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Demo <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-1\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 38
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("home");
        yield "\">Digital agency</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 41
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index2");
        yield "\">Chat software</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 44
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index3");
        yield "\">Fitness App</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 47
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index4");
        yield "\">Online Courses</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 50
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index5");
        yield "\">SEO Agency</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 53
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index6");
        yield "\">Cold Email</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 56
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index7");
        yield "\">Web Hosting</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 59
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index8");
        yield "\">Startup</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 62
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index9");
        yield "\">Tracking Software</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 65
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index10");
        yield "\">AI Writing Tool</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 68
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index11");
        yield "\">Website Builder</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 71
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index12");
        yield "\">AI Photo Editor</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 74
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index13");
        yield "\">initial coin offering (ICO)</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 77
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index14");
        yield "\">AI Content Generator</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 80
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("index15");
        yield "\">IT Service</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item\">
                                    <a href=\"";
        // line 85
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("about");
        yield "\" class=\"nav-link-item\">About</a>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Services
                                        <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-2\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 93
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("services");
        yield "\">Services</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 96
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("serviceDetails");
        yield "\">Service Details</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Pages <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-3\">
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">blogs <i class=\"fa-solid fa-angle-right\"></i></a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-4\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 108
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("blog");
        yield "\">blogs</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 111
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("blogDetails");
        yield "\">blog details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Team
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-5\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 121
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("teams");
        yield "\">Teams</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">FAQ
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-6\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 131
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("faq");
        yield "\">FAQ-1</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 134
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("faq2");
        yield "\">FAQ-2</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 137
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("faq3");
        yield "\">FAQ-3</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 140
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("faq4");
        yield "\">FAQ-4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Portfolio
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-7\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 150
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio");
        yield "\">Portfolio Classic</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 153
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio2");
        yield "\">Portfolio Masonry</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 156
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio3");
        yield "\">Portfolio Modern</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 159
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolio4");
        yield "\">Portfolio Minimal</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 162
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\">Portfolio Details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Pricing
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-8\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 172
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pricing");
        yield "\">Pricing-1</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 175
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("pricing2");
        yield "\">Pricing-2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Careers
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-9\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 185
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("careers");
        yield "\">Career</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 188
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("careerDetails");
        yield "\">Career Details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Utilities
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-10\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 198
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\">Login</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 201
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\">Signup</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 204
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("resetPassword");
        yield "\">Reset Password</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 207
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("comingsoon");
        yield "\">Coming Soon</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"";
        // line 210
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("error404");
        yield "\">Error 404</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Contact
                                        <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-11\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 222
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact");
        yield "\">Contact-1</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 225
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact2");
        yield "\">Contact-2</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"";
        // line 228
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("contact3");
        yield "\">Contact-3</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Header Navigation -->
        
                    <!-- Header User Event -->
                    ";
        // line 238
        yield from $this->unwrap()->yieldBlock('headButtons', $context, $blocks);
        // line 240
        yield " 
                    <!-- Header User Event -->
                </div>
            </div>
        </header>
        <!-- Header End -->

        <main class=\"main-wrapper relative overflow-hidden\">

            ";
        // line 249
        yield from $this->unwrap()->yieldBlock('breadcrumb', $context, $blocks);
        // line 251
        yield " 
            ";
        // line 252
        yield from $this->unwrap()->yieldBlock('content', $context, $blocks);
        // line 254
        yield " 
        </main>

        ";
        // line 257
        yield from $this->unwrap()->yieldBlock('footerSection', $context, $blocks);
        // line 259
        yield " 

        ";
        // line 261
        yield from $this->unwrap()->yieldBlock('footer', $context, $blocks);
        // line 263
        yield " 
        

    </div>
    ";
        // line 267
        yield from         $this->loadTemplate("partials/scripts.html.twig", "partials/layout/layout1.html.twig", 267)->unwrap()->yield($context);
        // line 268
        yield "
</body>

</html>
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 15
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 16
        yield "
                    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 238
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 239
        yield "
                    ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 249
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 250
        yield "
            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 252
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 253
        yield "
            ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 257
    public function block_footerSection($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footerSection"));

        // line 258
        yield "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 261
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 262
        yield "
        ";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "partials/layout/layout1.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  563 => 262,  556 => 261,  547 => 258,  540 => 257,  531 => 253,  524 => 252,  515 => 250,  508 => 249,  499 => 239,  492 => 238,  483 => 16,  476 => 15,  464 => 268,  462 => 267,  456 => 263,  454 => 261,  450 => 259,  448 => 257,  443 => 254,  441 => 252,  438 => 251,  436 => 249,  425 => 240,  423 => 238,  410 => 228,  404 => 225,  398 => 222,  383 => 210,  377 => 207,  371 => 204,  365 => 201,  359 => 198,  346 => 188,  340 => 185,  327 => 175,  321 => 172,  308 => 162,  302 => 159,  296 => 156,  290 => 153,  284 => 150,  271 => 140,  265 => 137,  259 => 134,  253 => 131,  240 => 121,  227 => 111,  221 => 108,  206 => 96,  200 => 93,  189 => 85,  181 => 80,  175 => 77,  169 => 74,  163 => 71,  157 => 68,  151 => 65,  145 => 62,  139 => 59,  133 => 56,  127 => 53,  121 => 50,  115 => 47,  109 => 44,  103 => 41,  97 => 38,  74 => 17,  72 => 15,  67 => 13,  57 => 6,  54 => 5,  52 => 4,  47 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("<!doctype html>
<html lang=\"en\">

{% include 'partials/head.html.twig' %}
<body>
    <div class=\"page-wrapper relative z-[1] {{ bgColor is defined ? bgColor : 'bg-white' }}\">
        <!-- Header Start -->
        
        <header class=\"site-header site-header--absolute is--white py-3\" id=\"sticky-menu\">
            <div class=\"container-default\">
                <div class=\"flex items-center justify-between gap-x-8\">
                    <!-- Header Logo -->
                    <a href=\"{{ path('home') }}\" class=\"\">
                    
                    {% block headerLogo %}

                    {% endblock %} 
                    </a>
                    <!-- Header Logo -->
        
                    <!-- Header Navigation -->
                    <div class=\"menu-block-wrapper\">
                        <div class=\"menu-overlay\"></div>
                        <nav class=\"menu-block\" id=\"append-menu-header\">
                            <div class=\"mobile-menu-head\">
                                <div class=\"go-back\">
                                    <i class=\"fa-solid fa-angle-left\"></i>
                                </div>
                                <div class=\"current-menu-title\"></div>
                                <div class=\"mobile-menu-close\">&times;</div>
                            </div>
                            <ul class=\"site-menu-main\">
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Demo <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-1\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('home') }}\">Digital agency</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index2') }}\">Chat software</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index3') }}\">Fitness App</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index4') }}\">Online Courses</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index5') }}\">SEO Agency</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index6') }}\">Cold Email</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index7') }}\">Web Hosting</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index8') }}\">Startup</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index9') }}\">Tracking Software</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index10') }}\">AI Writing Tool</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index11') }}\">Website Builder</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index12') }}\">AI Photo Editor</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index13') }}\">initial coin offering (ICO)</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index14') }}\">AI Content Generator</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('index15') }}\">IT Service</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item\">
                                    <a href=\"{{ path('about') }}\" class=\"nav-link-item\">About</a>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Services
                                        <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-2\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('services') }}\">Services</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('serviceDetails') }}\">Service Details</a>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Pages <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-3\">
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">blogs <i class=\"fa-solid fa-angle-right\"></i></a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-4\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('blog') }}\">blogs</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('blogDetails') }}\">blog details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Team
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-5\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('teams') }}\">Teams</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">FAQ
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-6\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('faq') }}\">FAQ-1</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('faq2') }}\">FAQ-2</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('faq3') }}\">FAQ-3</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('faq4') }}\">FAQ-4</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Portfolio
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-7\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('portfolio') }}\">Portfolio Classic</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('portfolio2') }}\">Portfolio Masonry</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('portfolio3') }}\">Portfolio Modern</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('portfolio4') }}\">Portfolio Minimal</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('portfolioDetails') }}\">Portfolio Details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Pricing
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-8\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('pricing') }}\">Pricing-1</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('pricing2') }}\">Pricing-2</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Careers
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-9\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('careers') }}\">Career</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('careerDetails') }}\">Career Details</a>
                                                </li>
                                            </ul>
                                        </li>
                                        <li class=\"sub-menu--item nav-item-has-children\">
                                            <a href=\"#\" data-menu-get=\"h3\" class=\"drop-trigger\">Utilities
                                                <i class=\"fa-solid fa-angle-right\"></i>
                                            </a>
                                            <ul class=\"sub-menu shape-none\" id=\"submenu-10\">
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('login') }}\">Login</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('signup') }}\">Signup</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('resetPassword') }}\">Reset Password</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('comingsoon') }}\">Coming Soon</a>
                                                </li>
                                                <li class=\"sub-menu--item\">
                                                    <a href=\"{{ path('error404') }}\">Error 404</a>
                                                </li>
                                            </ul>
                                        </li>
                                    </ul>
                                </li>
                                <li class=\"nav-item nav-item-has-children\">
                                    <a href=\"#\" class=\"nav-link-item drop-trigger\">Contact
                                        <i class=\"fa-solid fa-angle-down\"></i>
                                    </a>
                                    <ul class=\"sub-menu\" id=\"submenu-11\">
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('contact') }}\">Contact-1</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('contact2') }}\">Contact-2</a>
                                        </li>
                                        <li class=\"sub-menu--item\">
                                            <a href=\"{{ path('contact3') }}\">Contact-3</a>
                                        </li>
                                    </ul>
                                </li>
                            </ul>
                        </nav>
                    </div>
                    <!-- Header Navigation -->
        
                    <!-- Header User Event -->
                    {% block headButtons %}

                    {% endblock %} 
                    <!-- Header User Event -->
                </div>
            </div>
        </header>
        <!-- Header End -->

        <main class=\"main-wrapper relative overflow-hidden\">

            {% block breadcrumb %}

            {% endblock %} 
            {% block content %}

            {% endblock %} 
        </main>

        {% block footerSection %}

        {% endblock %} 

        {% block footer %}

        {% endblock %} 
        

    </div>
    {% include 'partials/scripts.html.twig' %}

</body>

</html>
", "partials/layout/layout1.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\partials\\layout\\layout1.html.twig");
    }
}
