type CurrencyType = '₹' | '$' | '€'

export const currency: CurrencyType = '$'

export const currentYear = new Date().getFullYear()

export const developedByLink = ''

export const developedBy = 'Coderthemes'

export const contactUs = ''

export const buyLink = ''

export const basePath = ''

export const DEFAULT_PAGE_TITLE = 'Opixo | Tailwind CSS Multipurpose Landing Page Template'
