<template>
    <div id="brands-1" class="py-100 brands-section">
        <div class="container">
            <!-- BRANDS CAROUSEL -->
            <div class="row">
                <div class="col text-center">
                    <SlidersBrandLogos />
                </div>
            </div>
            <!-- END BRANDS CAROUSEL -->
        </div>
        <!-- End container -->
    </div>
    <hr class="divider" />
</template>
