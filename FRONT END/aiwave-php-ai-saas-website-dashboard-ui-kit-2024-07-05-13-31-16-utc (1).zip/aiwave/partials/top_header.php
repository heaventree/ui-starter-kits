<div class="header-top-news bg-image1">
            <div class="wrapper">
                <div class="container">
                    <div class="row">
                        <div class="col-lg-12">
                            <div class="inner">
                                <div class="content">
                                    <span class="rainbow-badge">Limited Time Offer</span>
                                    <span class="news-text">Intro price. Get AiWave for Big Sale -95% off.</span>
                                </div>
                                <div class="right-button">
                                    <a class="btn-read-more" target="_blank" href="https://themeforest.net/user/pixcelsthemes">
                                        <span>Purchase Now <i class="fa-sharp fa-regular fa-arrow-right"></i></span>
                                    </a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="icon-close">
                <button class="close-button bgsection-activation">
                    <i class="fa-sharp fa-regular fa-x"></i>
                </button>
            </div>
        </div>