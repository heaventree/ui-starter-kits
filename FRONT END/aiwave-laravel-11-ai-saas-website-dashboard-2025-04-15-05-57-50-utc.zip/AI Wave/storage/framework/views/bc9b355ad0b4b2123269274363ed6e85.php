<!DOCTYPE html>
<html lang="en">

<head>
    <?php if (isset($component)) { $__componentOriginal0f509fab02c45445826003a1e50db506 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal0f509fab02c45445826003a1e50db506 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.head','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('head'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $attributes = $__attributesOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__attributesOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal0f509fab02c45445826003a1e50db506)): ?>
<?php $component = $__componentOriginal0f509fab02c45445826003a1e50db506; ?>
<?php unset($__componentOriginal0f509fab02c45445826003a1e50db506); ?>
<?php endif; ?>
</head>

<body>
    <main class="page-wrapper rbt-dashboard-page">
        <?php if (isset($component)) { $__componentOriginalccfc328cc58d381c26488acd71d872f7 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalccfc328cc58d381c26488acd71d872f7 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.header2','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('header2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalccfc328cc58d381c26488acd71d872f7)): ?>
<?php $attributes = $__attributesOriginalccfc328cc58d381c26488acd71d872f7; ?>
<?php unset($__attributesOriginalccfc328cc58d381c26488acd71d872f7); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalccfc328cc58d381c26488acd71d872f7)): ?>
<?php $component = $__componentOriginalccfc328cc58d381c26488acd71d872f7; ?>
<?php unset($__componentOriginalccfc328cc58d381c26488acd71d872f7); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginalc1443404be39e174b2909b2637f25c68 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalc1443404be39e174b2909b2637f25c68 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.mobileNav','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('mobileNav'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalc1443404be39e174b2909b2637f25c68)): ?>
<?php $attributes = $__attributesOriginalc1443404be39e174b2909b2637f25c68; ?>
<?php unset($__attributesOriginalc1443404be39e174b2909b2637f25c68); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalc1443404be39e174b2909b2637f25c68)): ?>
<?php $component = $__componentOriginalc1443404be39e174b2909b2637f25c68; ?>
<?php unset($__componentOriginalc1443404be39e174b2909b2637f25c68); ?>
<?php endif; ?>
        <?php if (isset($component)) { $__componentOriginal36665f0dc0e45320e21db1e20a989acf = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal36665f0dc0e45320e21db1e20a989acf = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.panel','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('panel'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $attributes = $__attributesOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__attributesOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal36665f0dc0e45320e21db1e20a989acf)): ?>
<?php $component = $__componentOriginal36665f0dc0e45320e21db1e20a989acf; ?>
<?php unset($__componentOriginal36665f0dc0e45320e21db1e20a989acf); ?>
<?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
        <?php if (isset($component)) { $__componentOriginalca6092bc3aec087244b6a2e249eaa9bd = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalca6092bc3aec087244b6a2e249eaa9bd = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.comman2','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('comman2'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalca6092bc3aec087244b6a2e249eaa9bd)): ?>
<?php $attributes = $__attributesOriginalca6092bc3aec087244b6a2e249eaa9bd; ?>
<?php unset($__attributesOriginalca6092bc3aec087244b6a2e249eaa9bd); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalca6092bc3aec087244b6a2e249eaa9bd)): ?>
<?php $component = $__componentOriginalca6092bc3aec087244b6a2e249eaa9bd; ?>
<?php unset($__componentOriginalca6092bc3aec087244b6a2e249eaa9bd); ?>
<?php endif; ?>
    </main>
    <div class="rbt-progress-parent">
    <svg class="rbt-back-circle svg-inner" width="100%" height="100%" viewBox="-1 -1 102 102">
        <path d="M50,1 a49,49 0 0,1 0,98 a49,49 0 0,1 0,-98" />
    </svg>
</div>
    <?php if (isset($component)) { $__componentOriginal2a2e30ee7946b5afacadfde3b701b26e = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2a2e30ee7946b5afacadfde3b701b26e = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.script','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('script'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2a2e30ee7946b5afacadfde3b701b26e)): ?>
<?php $attributes = $__attributesOriginal2a2e30ee7946b5afacadfde3b701b26e; ?>
<?php unset($__attributesOriginal2a2e30ee7946b5afacadfde3b701b26e); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2a2e30ee7946b5afacadfde3b701b26e)): ?>
<?php $component = $__componentOriginal2a2e30ee7946b5afacadfde3b701b26e; ?>
<?php unset($__componentOriginal2a2e30ee7946b5afacadfde3b701b26e); ?>
<?php endif; ?>
</body>

</html>
<?php /**PATH E:\Theme\Rainbow-Themes\AI-wave\Laravel\AI Wave\resources\views/layouts/app2.blade.php ENDPATH**/ ?>