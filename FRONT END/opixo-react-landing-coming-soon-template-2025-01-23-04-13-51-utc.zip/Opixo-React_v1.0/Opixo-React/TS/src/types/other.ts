import type { ReactNode } from 'react'

export type ChildrenType = Readonly<{ children: ReactNode }>
