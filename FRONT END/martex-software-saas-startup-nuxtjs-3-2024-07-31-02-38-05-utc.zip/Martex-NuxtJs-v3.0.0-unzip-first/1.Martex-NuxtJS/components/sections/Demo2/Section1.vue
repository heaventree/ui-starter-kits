<template>
    <section id="hero-2" class="bg--scroll hero-section">
        <div class="container">
            <div class="row d-flex align-items-center">
                <!-- HERO IMAGE -->
                <div class="col-md-6 order-last order-md-2">
                    <div class="hero-2-img wow fadeInRight">
                        <img class="img-fluid" src="/assets/images/hero-2-img.png" alt="hero-image" />
                    </div>
                </div>
                <!-- HERO TEXT -->
                <div class="col-md-6 order-first order-md-2">
                    <div class="hero-2-txt wow fadeInLeft">
                        <!-- Title -->
                        <h2 class="s-56 w-700 color--black">Realize your digital potential with Martex</h2>
                        <!-- Text -->
                        <p class="p-lg">Tempor sapien sodales quaerat ipsum congue ipsum laoreet turpis neque auctor turpis a vitae dolor luctus placerat magna and ligula cursus purus ipsum</p>
                        <!-- HERO DIGITS -->
                        <div class="hero-digits">
                            <!-- DIGIT BLOCK #1 -->
                            <div id="hd-1-1" class="wow fadeInUp">
                                <div class="hero-digits-block">
                                    <!-- Digit -->
                                    <div class="block-digit">
                                        <h2 class="s-46 statistic-number color--black">2<span>x</span></h2>
                                    </div>
                                    <!-- Text -->
                                    <div class="block-txt">
                                        <p class="p-sm">Tempor sapien and quaerat placerat</p>
                                    </div>
                                </div>
                            </div>
                            <!-- END DIGIT BLOCK #1 -->
                            <!-- DIGIT BLOCK #2 -->
                            <div id="hd-1-2" class="wow fadeInUp">
                                <div class="hero-digits-block">
                                    <!-- Digit -->
                                    <div class="block-digit">
                                        <h2 class="s-46 statistic-number color--black">63<span>%</span></h2>
                                    </div>
                                    <!-- Text -->
                                    <div class="block-txt">
                                        <p class="p-sm">Ligula suscipit vitae and rutrum turpis</p>
                                    </div>
                                </div>
                            </div>
                            <!-- END DIGIT BLOCK #2 -->
                        </div>
                        <!-- END HERO DIGITS -->
                    </div>
                </div>
                <!-- END HERO TEXT -->
            </div>
            <!-- End row -->
        </div>
        <!-- End container -->
    </section>
</template>
