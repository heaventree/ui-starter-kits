

export type NavbarLinkProps = {
  label: string
  link: string
}

export type pageType = {
  name: string
  url: string
  image: string
}

export type FaqType = {
  question: string
  answer: string
}

export type FooterLinkType = {
  title: string
  links: string[]
}

export type BlogType = {
  title: string
  description: string
  price: number
  avatar: string
  name: string
  image: string
  rating: number
}
