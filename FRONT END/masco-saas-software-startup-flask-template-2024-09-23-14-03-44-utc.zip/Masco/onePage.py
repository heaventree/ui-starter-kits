from flask import render_template
from app import app


@app.route('/indexonepage1')
def indexonepage1():
    return render_template('/onePage/indexonepage1.html')

@app.route('/indexonepage2')
def indexonepage2():
    return render_template('/onePage/indexonepage2.html')

@app.route('/indexonepage3')
def indexonepage3():
    return render_template('/onePage/indexonepage3.html')

@app.route('/indexonepage4')
def indexonepage4():
    return render_template('/onePage/indexonepage4.html')

@app.route('/indexonepage5')
def indexonepage5():
    return render_template('/onePage/indexonepage5.html')

@app.route('/indexonepage6')
def indexonepage6():
    return render_template('/onePage/indexonepage6.html')

@app.route('/indexonepage7')
def indexonepage7():
    return render_template('/onePage/indexonepage7.html')

@app.route('/indexonepage8')
def indexonepage8():
    return render_template('/onePage/indexonepage8.html')

@app.route('/indexonepage9')
def indexonepage9():
    return render_template('/onePage/indexonepage9.html')

@app.route('/indexonepage10')
def indexonepage10():
    return render_template('/onePage/indexonepage10.html   ')

@app.route('/indexonepage11')
def indexonepage11():
    return render_template('/onePage/indexonepage11.html   ')

@app.route('/indexonepage12')
def indexonepage12():
    return render_template('/onePage/indexonepage12.html   ')

@app.route('/indexonepage13')
def indexonepage13():
    return render_template('/onePage/indexonepage13.html   ')

@app.route('/indexonepage14')
def indexonepage14():
    return render_template('/onePage/indexonepage14.html   ')

@app.route('/indexonepage15')
def indexonepage15():
    return render_template('/onePage/indexonepage15.html   ')
