<?php

use Twig\Environment;
use Twig\Error\LoaderError;
use Twig\Error\RuntimeError;
use Twig\Extension\CoreExtension;
use Twig\Extension\SandboxExtension;
use Twig\Markup;
use Twig\Sandbox\SecurityError;
use Twig\Sandbox\SecurityNotAllowedTagError;
use Twig\Sandbox\SecurityNotAllowedFilterError;
use Twig\Sandbox\SecurityNotAllowedFunctionError;
use Twig\Source;
use Twig\Template;

/* home/portfolio4.html.twig */
class __TwigTemplate_bc72da78b424a597e47774b30aaa11b4 extends Template
{
    private $source;
    private $macros = [];

    public function __construct(Environment $env)
    {
        parent::__construct($env);

        $this->source = $this->getSourceContext();

        $this->blocks = [
            'headerLogo' => [$this, 'block_headerLogo'],
            'headButtons' => [$this, 'block_headButtons'],
            'breadcrumb' => [$this, 'block_breadcrumb'],
            'content' => [$this, 'block_content'],
            'footer' => [$this, 'block_footer'],
        ];
    }

    protected function doGetParent(array $context)
    {
        // line 1
        return "partials/layout/layout1.html.twig";
    }

    protected function doDisplay(array $context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "template", "home/portfolio4.html.twig"));

        $this->parent = $this->loadTemplate("partials/layout/layout1.html.twig", "home/portfolio4.html.twig", 1);
        yield from $this->parent->unwrap()->yield($context, array_merge($this->blocks, $blocks));
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

    }

    // line 3
    public function block_headerLogo($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headerLogo"));

        // line 4
        yield "<img src=\"";
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/logo-blue-dark.png"), "html", null, true);
        yield "\" alt=\"Masco\" width=\"109\" height=\"24\" />
";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 9
    public function block_headButtons($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "headButtons"));

        // line 10
        yield "
<div class=\"flex items-center gap-6\">
    <a href=\"";
        // line 12
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("login");
        yield "\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"";
        // line 13
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("signup");
        yield "\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 26
    public function block_breadcrumb($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "breadcrumb"));

        // line 27
        yield "    ";
        yield from         $this->loadTemplate("partials/breadcrumb.html.twig", "home/portfolio4.html.twig", 27)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 30
    public function block_content($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "content"));

        // line 31
        yield "
<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"grid gap-[134px] md:grid-cols-[minmax(0,0.5fr)_1fr] lg:grid-cols-[minmax(0,0.4fr)_1fr] xxl:grid-cols-[minmax(0,0.4fr)_1fr]\">
                <!-- Tab Button Menu -->
                <div class=\"flex flex-row flex-wrap justify-center gap-3 text-ColorBlack md:flex-col md:justify-start md:gap-6\">
                    <button class=\"active tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"show-all\">
                        Show All
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"website\">
                        Website
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"branding\">
                        Branding
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"commercial\">
                        Commercial
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"digital-art\">
                        Digital Art
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"ui-ux-design\">
                        UI/UX Design
                    </button>
                </div>
                <!-- Tab Button Menu -->

                <div>
                    <!-- Portfolio Area -->
                    <div>
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid\" id=\"show-all\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 72
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 77
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 97
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 102
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 122
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 127
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"website\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 151
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 156
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 176
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 181
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 201
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 206
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"branding\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 230
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 235
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 255
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 260
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 280
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 285
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"commercial\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 309
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 314
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 334
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 339
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 359
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 364
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"digital-art\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 388
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 393
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 413
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 418
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 438
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 443
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"ui-ux-design\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 467
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-1.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 472
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 492
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-2.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 497
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"";
        // line 517
        yield $this->env->getRuntime('Twig\Runtime\EscaperRuntime')->escape($this->extensions['Symfony\Bridge\Twig\Extension\AssetExtension']->getAssetUrl("assets/img/th-1/portfolio-minimal-img-3.jpg"), "html", null, true);
        yield "\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"";
        // line 522
        yield $this->extensions['Symfony\Bridge\Twig\Extension\RoutingExtension']->getPath("portfolioDetails");
        yield "\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                    </div>
                    <!-- Portfolio Area -->

                    <div class=\"mt-10 flex lg:mt-20\">
                        <button class=\"btn is-blue is-rounded is-large group\">
                            View more
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

";
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    // line 560
    public function block_footer($context, array $blocks = [])
    {
        $macros = $this->macros;
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f = $this->extensions["Symfony\\Bridge\\Twig\\Extension\\ProfilerExtension"];
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->enter($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof = new \Twig\Profiler\Profile($this->getTemplateName(), "block", "footer"));

        // line 561
        yield "    ";
        yield from         $this->loadTemplate("partials/footer.html.twig", "home/portfolio4.html.twig", 561)->unwrap()->yield($context);
        
        $__internal_6f47bbe9983af81f1e7450e9a3e3768f->leave($__internal_6f47bbe9983af81f1e7450e9a3e3768f_prof);

        return; yield '';
    }

    /**
     * @codeCoverageIgnore
     */
    public function getTemplateName()
    {
        return "home/portfolio4.html.twig";
    }

    /**
     * @codeCoverageIgnore
     */
    public function isTraitable()
    {
        return false;
    }

    /**
     * @codeCoverageIgnore
     */
    public function getDebugInfo()
    {
        return array (  781 => 561,  774 => 560,  731 => 522,  723 => 517,  700 => 497,  692 => 492,  669 => 472,  661 => 467,  634 => 443,  626 => 438,  603 => 418,  595 => 413,  572 => 393,  564 => 388,  537 => 364,  529 => 359,  506 => 339,  498 => 334,  475 => 314,  467 => 309,  440 => 285,  432 => 280,  409 => 260,  401 => 255,  378 => 235,  370 => 230,  343 => 206,  335 => 201,  312 => 181,  304 => 176,  281 => 156,  273 => 151,  246 => 127,  238 => 122,  215 => 102,  207 => 97,  184 => 77,  176 => 72,  133 => 31,  126 => 30,  117 => 27,  110 => 26,  90 => 13,  86 => 12,  82 => 10,  75 => 9,  64 => 4,  57 => 3,  40 => 1,);
    }

    public function getSourceContext()
    {
        return new Source("{% extends 'partials/layout/layout1.html.twig' %}

{% block headerLogo %}
<img src=\"{{ asset('assets/img/logo-blue-dark.png') }}\" alt=\"Masco\" width=\"109\" height=\"24\" />
{% endblock %} 



{% block headButtons %}

<div class=\"flex items-center gap-6\">
    <a href=\"{{ path('login') }}\" class=\"btn-text hidden hover:text-ColorBlue md:inline-block\">Login</a>
    <a href=\"{{ path('signup') }}\" class=\"btn is-blue is-rounded btn-animation group hidden md:inline-block\"><span>Sign up free</span></a>
    <!-- Responsive Offcanvas Menu Button -->
    <div class=\"block lg:hidden\">
        <button id=\"openBtn\" class=\"hamburger-menu mobile-menu-trigger\">
            <span></span>
            <span></span>
            <span></span>
        </button>
    </div>
</div>

{% endblock %} 

{% block breadcrumb %}
    {% include 'partials/breadcrumb.html.twig' %}
{% endblock %}

{% block content %}

<!-- Portfolio Section Start -->
<div class=\"section-portfolio\">
    <!-- Section Space -->
    <div class=\"section-space\">
        <!-- Section Container -->
        <div class=\"container-default\">
            <div class=\"grid gap-[134px] md:grid-cols-[minmax(0,0.5fr)_1fr] lg:grid-cols-[minmax(0,0.4fr)_1fr] xxl:grid-cols-[minmax(0,0.4fr)_1fr]\">
                <!-- Tab Button Menu -->
                <div class=\"flex flex-row flex-wrap justify-center gap-3 text-ColorBlack md:flex-col md:justify-start md:gap-6\">
                    <button class=\"active tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"show-all\">
                        Show All
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"website\">
                        Website
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"branding\">
                        Branding
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"commercial\">
                        Commercial
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"digital-art\">
                        Digital Art
                    </button>
                    <button class=\"tab-button tab-text text-left text-2xl font-semibold leading-[1.4] -tracking-[1px] xl:text-3xl\" data-tab=\"ui-ux-design\">
                        UI/UX Design
                    </button>
                </div>
                <!-- Tab Button Menu -->

                <div>
                    <!-- Portfolio Area -->
                    <div>
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid\" id=\"show-all\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"website\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"branding\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"commercial\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"digital-art\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                        <!-- Portfolio List -->
                        <div class=\"tab-content grid hidden\" id=\"ui-ux-design\">
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-1.jpg') }}\" alt=\"portfolio-minimal-img-1\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">App
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">UI/UX Design</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-2.jpg') }}\" alt=\"portfolio-minimal-img-2\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Website
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Branding</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                            <!-- Portfolio Item -->
                            <div class=\"jos mb-[30px] border-b border-ColorBlack/10 pb-[30px] last:mb-0 last:border-none last:pb-0\">
                                <div class=\"group\">
                                    <div class=\"hover-solid-shadow\">
                                        <div class=\"overflow-hidden rounded-[10px]\">
                                            <img src=\"{{ asset('assets/img/th-1/portfolio-minimal-img-3.jpg') }}\" alt=\"portfolio-minimal-img-3\" width=\"840\" height=\"533\" class=\"h-full w-full object-cover transition-all duration-300 ease-in-out group-hover:scale-105\" />
                                        </div>
                                    </div>
                                    <div class=\"mt-8\">
                                        <div class=\"mb-3 flex flex-wrap gap-2 text-xl leading-[1.33] -tracking-[0.5px] group-hover:text-ColorBlue lg:flex-nowrap xl:text-2xl\">
                                            <a href=\"{{ path('portfolioDetails') }}\" class=\"font-semibold\">Campaign
                                            </a>
                                            <span>—</span>
                                            <a href=\"#\" class=\"hover:text-ColorBlue\">Marketing</a>
                                        </div>
                                        <p class=\"line-clamp-2 text-base sm:max-w-[636px]\">
                                            Branding is the process of creating a distinct
                                            identity for a business in the mind of your target
                                            audience and consumers. At the the most basic
                                            level.
                                        </p>
                                    </div>
                                </div>
                            </div>
                            <!-- Portfolio Item -->
                        </div>
                        <!-- Portfolio List -->
                    </div>
                    <!-- Portfolio Area -->

                    <div class=\"mt-10 flex lg:mt-20\">
                        <button class=\"btn is-blue is-rounded is-large group\">
                            View more
                        </button>
                    </div>
                </div>
            </div>
        </div>
        <!-- Section Container -->
    </div>
    <!-- Section Space -->
</div>
<!-- Portfolio Section End -->

{% endblock %} 



{% block footer %}
    {% include 'partials/footer.html.twig' %}
{% endblock %} ", "home/portfolio4.html.twig", "E:\\Theme\\Mthemeus-FavDves\\Masco\\Symfony\\Masco\\templates\\home\\portfolio4.html.twig");
    }
}
