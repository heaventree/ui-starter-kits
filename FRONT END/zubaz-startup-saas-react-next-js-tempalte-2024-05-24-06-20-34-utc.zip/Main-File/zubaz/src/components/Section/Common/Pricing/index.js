export { default } from "./Pricing";
