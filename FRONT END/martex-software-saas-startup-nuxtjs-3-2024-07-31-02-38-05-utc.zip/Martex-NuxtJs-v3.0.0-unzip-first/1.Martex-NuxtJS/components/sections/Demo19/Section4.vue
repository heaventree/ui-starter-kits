<template>
    <section class="pt-100 ws-wrapper content-section">
        <div class="container">
            <div class="bc-1-wrapper bg--white-400 bg--fixed r-16">
                <div class="section-overlay">
                    <div class="row d-flex align-items-center">
                        <!-- TEXT BLOCK -->
                        <div class="col-md-6 order-last order-md-2">
                            <div class="txt-block left-column wow fadeInRight">
                                <!-- Section ID -->
                                <span class="section-id">One-Stop Solution</span>
                                <!-- Title -->
                                <h2 class="s-46 w-700">Smart solutions, real-time results</h2>
                                <!-- List -->
                                <ul class="simple-list">
                                    <li class="list-item">
                                        <p>Cursus purus suscipit vitae cubilia magnis volute egestas vitae sapien turpis sodales magna</p>
                                    </li>
                                    <li class="list-item">
                                        <p class="mb-0">Tempor sapien quaerat an ipsum laoreet purus and sapien dolor an ultrice ipsum aliquam congue</p>
                                    </li>
                                </ul>
                                <!-- Button -->
                                <a href="#features-2" class="btn btn-sm r-04 btn--theme hover--tra-black"> Best solutions </a>
                            </div>
                        </div>
                        <!-- END TEXT BLOCK -->
                        <!-- IMAGE BLOCK -->
                        <div class="col-md-6 order-first order-md-2">
                            <div class="img-block right-column wow fadeInLeft">
                                <img class="img-fluid" src="/assets/images/img-09.png" alt="content-image" />
                            </div>
                        </div>
                    </div>
                    <!-- End row -->
                </div>
                <!-- End section overlay -->
            </div>
            <!-- End content wrapper -->
        </div>
        <!-- End container -->
    </section>
</template>
