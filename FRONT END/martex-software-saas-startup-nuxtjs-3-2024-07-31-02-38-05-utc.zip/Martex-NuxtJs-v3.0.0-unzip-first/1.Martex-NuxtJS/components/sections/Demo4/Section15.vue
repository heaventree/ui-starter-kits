<template>
    <section id="reviews-3" class="pt-100 reviews-section">
        <div class="container">
            <!-- SECTION TITLE -->
            <div class="row justify-content-center">
                <div class="col-md-8">
                    <div class="section-title mb-70">
                        <!-- Title -->
                        <h2 class="s-50 w-700">Read what our users have to say about us</h2>
                        <!-- Text -->
                        <p class="s-21 color--grey">Ligula risus auctor tempus magna feugiat lacinia.</p>
                    </div>
                </div>
            </div>
            <!-- TESTIMONIALS-3 WRAPPER -->
            <div class="reviews-3-wrapper rel shape--02 shape--whitesmoke r-24">
                <div class="row align-items-center">
                    <!-- TESTIMONIAL #1 -->
                    <div class="col-md-5">
                        <div id="rw-3-1" class="review-3 bg--white-100 block-border block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Title -->
                                <h6 class="s-20 w-700">This is crazy...</h6>
                                <!-- Text -->
                                <p class="p-md">At sagittis congue an augue magna ipsum vitae a purus suscipit ipsum primis diam a cubilia laoreet augue ultrice ligula magna a lectus gestas augue cubilia turpis dolores aliquam undo quaerat sodales euismod</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-2.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Joel Peterson</h6>
                                        <p class="p-sm">Internet Surfer</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                    </div>
                    <!-- END TESTIMONIAL #2 -->
                    <!-- TESTIMONIALS #2-3 -->
                    <div class="col-md-7">
                        <!-- TESTIMONIAL #2 -->
                        <div id="rw-3-2" class="review-3 bg--white-100 block-border block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Title -->
                                <h6 class="s-20 w-700">Great Flexibility!</h6>
                                <!-- Text -->
                                <p class="p-md">An augue cubilia laoreet magna undo suscipit egestas ipsum and lectus purus ipsum a primis gestas impedit ultrice ligula egestas a sapien lectus gestas tempus</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-5.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Jennifer Harper</h6>
                                        <p class="p-sm">App Developer</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                        <!-- END TESTIMONIAL #2 -->
                        <!-- TESTIMONIAL #3 -->
                        <div id="rw-3-3" class="review-3 bg--white-100 block-border block-shadow r-08">
                            <!-- Quote Icon -->
                            <div class="review-ico ico-65"><span class="flaticon-quote"></span></div>
                            <!-- Text -->
                            <div class="review-txt">
                                <!-- Title -->
                                <h6 class="s-20 w-700">Simple and Useful!</h6>
                                <!-- Text -->
                                <p class="p-md">Augue at vitae purus tempus egestas volutpat augue magnis cubilia laoreet magna and suscipit luctus dolor blandit purus tempus feugiat impedit laoreet augue</p>
                                <!-- Author -->
                                <div class="author-data clearfix">
                                    <!-- Avatar -->
                                    <div class="review-avatar">
                                        <img src="/assets/images/review-author-8.jpg" alt="review-avatar" />
                                    </div>
                                    <!-- Data -->
                                    <div class="review-author">
                                        <h6 class="s-18 w-700">Evelyn Martinez</h6>
                                        <p class="p-sm">WordPress Consultant</p>
                                    </div>
                                </div>
                                <!-- End Author -->
                            </div>
                            <!-- End Text -->
                        </div>
                        <!-- END TESTIMONIAL #3 -->
                    </div>
                    <!-- END TESTIMONIALS #2-3 -->
                </div>
                <!-- End row -->
            </div>
            <!-- END TESTIMONIALS-3 WRAPPER -->
        </div>
        <!-- End container -->
    </section>
</template>
