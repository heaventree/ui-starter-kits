import { currentYear, developedBy } from '@/common/constants';
import FallbackLoading from '@/components/FallbackLoading';
import { Suspense, useEffect } from 'react';
import { Link } from 'react-router-dom';
const AuthLayout = ({
  children
}) => {
  useEffect(() => {
    document.body.classList.add('relative', 'h-full');
    return () => {
      document.body.classList.add('relative', 'h-full');
    };
  }, []);
  return <>
      <section className="flex h-screen w-full items-center bg-[url(../images/auth-bg.jpg)] bg-cover bg-right-bottom bg-no-repeat p-6">
        <div className="absolute inset-0 h-full w-full bg-black/60" />
        <div className="container">
          <div className="mx-auto max-w-5xl overflow-hidden rounded-lg bg-black/40 backdrop-blur-2xl">
            <Suspense fallback={<FallbackLoading />}>
              {children}
            </Suspense>
          </div>
        </div>
      </section>
      <footer className="fixed bottom-0 end-0 start-0 py-3">
        <div className="container">
          <p className="text-center text-base font-medium text-gray-400">
            {currentYear} © Opixo -{' '}
            <Link to="">
              Design crafted{' '}
              <svg xmlns="http://www.w3.org/2000/svg" width={24} height={24} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth={2} strokeLinecap="round" strokeLinejoin="round" data-lucide="heart" className="lucide lucide-heart inline h-4 w-4 fill-red-500 text-red-500">
                {' '}
                <path d="M19 14c1.49-1.46 3-3.21 3-5.5A5.5 5.5 0 0 0 16.5 3c-1.76 0-3 .5-4.5 2-1.5-1.5-2.74-2-4.5-2A5.5 5.5 0 0 0 2 8.5c0 2.3 1.5 4.05 3 5.5l7 7Z">
                  {' '}
                </path>{' '}
              </svg>{' '}
              by {developedBy}.com
            </Link>
          </p>
        </div>
      </footer>
    </>;
};
export default AuthLayout;